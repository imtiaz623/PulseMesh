import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

// =====================================================================
//  EDIT THESE LINES
// =====================================================================
/// Google Apps Script web app (Google Sheets payment backend). No trailing slash or spaces.
const kBackendUrl =
    'https://script.google.com/macros/s/AKfycbyBQ8Pr9PRgcj4pz4JDeG-Q7MR2AFeIcDZtuJMzzm2J1CxZpRn60F9ZWj7xXwcp_8C0/exec';

/// Plan ids – must match the backend exactly.
const kMonthly = 'monthly';
const kYearly = 'yearly';
const kLifetime = 'lifetime';
const kPlans = [kMonthly, kYearly, kLifetime];

const kPlanPrice = {kMonthly: 200, kYearly: 1500, kLifetime: 4000};
const kPlanName = {kMonthly: 'Monthly', kYearly: 'Yearly', kLifetime: 'Lifetime'};

/// Easypaisa payment details + support.
const kPayMethod = 'Easypaisa';
const kPayNumber = '03708431602';
const kPayTitle = 'Imtiaz Ali';
const kSupportUrl = 'https://wa.me/923708431602';

/// Developer details.
const kDeveloperName = 'Imtiaz Ali Qumbrani';
const kDeveloperFather = 'Muhammad Ismail';
const kDeveloperEmail = 'imtiazalee02@gmail.com';
const kSupportWhatsapp = '+923708431602';

/// Optional: HTTPS link to announcements.json in your GitHub repo, e.g.
/// https://raw.githubusercontent.com/USER/REPO/main/announcements.json
const kAnnounceUrl = '';
const kAppVersion = '1.0.1';

/// Virtual author id of the official "OffChat" status (exactly 8 chars).
const kOfficialId = 'pulsemsh';
// =====================================================================

enum Feature { screenshotAlerts, screenshotBlock, deleteForEveryone, seeDeleted }

String planTitle(String plan) => kPlanName[plan] ?? (plan.isEmpty ? '' : plan);

/// Premium = a manually verified Easypaisa payment.
///
/// Flow: the user pays by Easypaisa, submits the transaction id ([submitPayment]) and the
/// developer approves it in the Google Sheet. The app then learns about the approval by asking the
/// backend ([refresh]) with a persistent device id.
class Premium extends ChangeNotifier {
  static const _native = MethodChannel('pulsemesh/native');
  late SharedPreferences _prefs;

  // ---- UI state
  bool busy = false; // submitting a payment
  bool checking = false; // running a status check
  String? message;
  bool secureOn = false; // "block screenshots" switch

  // ---- persisted state
  String deviceUuid = '';
  bool _isPremium = false;
  String _plan = ''; // premium_plan
  int _expiresAt = 0; // premium_expires_at (ms since epoch), 0 = lifetime / none
  bool _expired = false; // server said "Expired"
  bool paymentPending = false;
  String pendingPlan = '';
  int _maxSeen = 0;

  Future<void> init(SharedPreferences p) async {
    _prefs = p;
    _isPremium = p.getBool('is_premium') ?? false;
    _plan = p.getString('premium_plan') ?? '';
    _expiresAt = p.getInt('premium_expires_at') ?? 0;
    _expired = p.getBool('premium_expired') ?? false;
    paymentPending = p.getBool('payment_pending') ?? false;
    pendingPlan = p.getString('pending_plan') ?? '';
    _maxSeen = p.getInt('pm_seen') ?? 0;
    secureOn = p.getBool('pm_secure') ?? false;
    tick();
    await _loadDeviceId();
    unawaited(refresh()); // on every app start; never delay the app launch
  }

  // ===================================================== persistent device id
  /// Android ID survives reinstall and app updates (it only changes on factory reset or when the
  /// signing key changes). It is saved locally as well, and a random UUID is the last resort.
  Future<void> _loadDeviceId() async {
    String? id;
    try {
      final v = await _native.invokeMethod<String>('deviceId').timeout(const Duration(seconds: 3));
      if (v != null && v.trim().length >= 8 && v != '9774d56d682e549c') id = 'aid-${v.trim()}';
    } catch (_) {}
    id ??= _prefs.getString('device_uuid');
    if (id == null || id.isEmpty) id = const Uuid().v4();
    deviceUuid = id;
    if (_prefs.getString('device_uuid') != id) await _prefs.setString('device_uuid', id);
  }

  // ===================================================== clock protection
  /// Remember the latest time we saw, so turning the phone clock back cannot stretch a plan.
  void tick() {
    final n = DateTime.now().millisecondsSinceEpoch;
    if (n > _maxSeen) {
      _maxSeen = n;
      _prefs.setInt('pm_seen', n);
    }
  }

  int get _now {
    final n = DateTime.now().millisecondsSinceEpoch;
    return n > _maxSeen ? n : _maxSeen;
  }

  // ===================================================== public state
  /// Premium is on when the backend approved it and (for timed plans) the expiry date is ahead.
  bool get active {
    if (!_isPremium) return false;
    if (_plan == kLifetime || _expiresAt <= 0) return true;
    return _now < _expiresAt;
  }

  /// A paid plan that has run out (reported by the server, or its date has passed while offline).
  bool get expired => !active && _plan.isNotEmpty && (_expired || (_isPremium && _expiresAt > 0));

  String get expiredNotice => 'Your ${planTitle(_plan)} plan has expired. Renew to continue.';

  bool get isLifetime => _plan == kLifetime;
  String get plan => _plan;
  String get planLabel => '${planTitle(_plan)} plan';
  DateTime? get expiresAt => _expiresAt > 0 ? DateTime.fromMillisecondsSinceEpoch(_expiresAt) : null;

  /// "Lifetime" or "Expires on 12 Nov 2026".
  String get expiryLabel {
    if (_plan == kLifetime || _expiresAt <= 0) return 'Lifetime';
    final d = DateTime.fromMillisecondsSinceEpoch(_expiresAt);
    const m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return 'Expires on ${d.day} ${m[d.month - 1]} ${d.year}';
  }

  /// One tier today; the switch keeps room for more later.
  bool has(Feature f) => active;

  // ===================================================== backend calls
  /// GET BASE_URL?device_uuid=... – updates the local premium state. If the phone is offline the
  /// last saved state is kept (an expiry date in the past still ends Premium).
  Future<void> refresh() async {
    if (checking || deviceUuid.isEmpty) return;
    checking = true;
    notifyListeners();
    try {
      final j = await _http('GET', Uri.parse('$kBackendUrl?device_uuid=${Uri.encodeQueryComponent(deviceUuid)}'));
      await _applyStatus(j);
    } catch (_) {
      // no internet / server problem: keep the saved state
    }
    checking = false;
    notifyListeners();
  }

  /// Manual "Check Status" button: like [refresh] but tells the user what happened.
  Future<void> checkStatus() async {
    message = null;
    final before = active;
    var failed = false;
    checking = true;
    notifyListeners();
    try {
      final j = await _http('GET', Uri.parse('$kBackendUrl?device_uuid=${Uri.encodeQueryComponent(deviceUuid)}'));
      await _applyStatus(j);
    } catch (_) {
      failed = true;
    }
    checking = false;
    if (failed) {
      message = 'Could not reach the server. Check your internet and try again.';
    } else if (active) {
      message = before ? null : 'Payment approved. Premium is now active!';
    } else if (expired) {
      message = expiredNotice;
    } else if (paymentPending) {
      message = 'Your payment is still being verified. Please check again later.';
    } else {
      message = 'No active Premium found for this device.';
    }
    notifyListeners();
  }

  Future<void> _applyStatus(Map<String, dynamic> j) async {
    final isPrem = j['isPremium'] == true;
    final status = (j['status'] ?? '').toString();
    final plan = (j['plan'] ?? '').toString().toLowerCase();
    if (isPrem) {
      _isPremium = true;
      _expired = false;
      if (plan.isNotEmpty) _plan = plan;
      final e = j['expiresAt'];
      if (_plan == kLifetime || e == null || e.toString().isEmpty) {
        _expiresAt = 0;
      } else {
        final d = DateTime.tryParse(e.toString());
        _expiresAt = d == null ? 0 : d.millisecondsSinceEpoch;
      }
      paymentPending = false;
      pendingPlan = '';
    } else {
      _isPremium = false;
      if (status == 'Expired') {
        _expired = true;
        if (plan.isNotEmpty) _plan = plan;
      } else {
        _expired = false;
        _expiresAt = 0;
        _plan = '';
      }
    }
    await _prefs.setBool('is_premium', _isPremium);
    await _prefs.setString('premium_plan', _plan);
    await _prefs.setInt('premium_expires_at', _expiresAt);
    await _prefs.setBool('premium_expired', _expired);
    await _prefs.setBool('payment_pending', paymentPending);
    await _prefs.setString('pending_plan', pendingPlan);
  }

  /// POST BASE_URL with device_uuid, trx_id and plan. Does NOT unlock Premium.
  Future<bool> submitPayment(String plan, String trxId) async {
    if (busy) return false;
    final trx = trxId.trim();
    if (!kPlans.contains(plan) || trx.length < 6) return false;
    busy = true;
    message = null;
    notifyListeners();
    var ok = false;
    try {
      final body = 'device_uuid=${Uri.encodeQueryComponent(deviceUuid)}'
          '&trx_id=${Uri.encodeQueryComponent(trx)}&plan=${Uri.encodeQueryComponent(plan)}'
          '&amount=${kPlanPrice[plan]}';
      final j = await _http('POST', Uri.parse(kBackendUrl), body: body);
      if (j['success'] == true) {
        ok = true;
        paymentPending = true;
        pendingPlan = plan;
        await _prefs.setBool('payment_pending', true);
        await _prefs.setString('pending_plan', plan);
        message = 'Request received for ${planTitle(plan)} plan. Verification may take a few hours. '
            'Premium will unlock automatically once approved.';
      } else {
        final m = (j['message'] ?? '').toString();
        message = m.isEmpty ? 'The payment could not be submitted. Please try again.' : m;
      }
    } catch (_) {
      message = 'Could not reach the server. Check your internet and try again.';
    }
    busy = false;
    notifyListeners();
    return ok;
  }

  /// Minimal HTTP client that follows Apps Script's 302 redirect by hand. The answer of a POST
  /// lives at the redirected address and must be fetched with GET.
  Future<Map<String, dynamic>> _http(String method, Uri uri, {String? body}) async {
    final c = HttpClient()..connectionTimeout = const Duration(seconds: 15);
    try {
      var u = uri;
      var m = method;
      var b = body;
      for (var i = 0; i < 8; i++) {
        final req = m == 'POST' ? await c.postUrl(u) : await c.getUrl(u);
        req.followRedirects = false;
        if (m == 'POST' && b != null) {
          req.headers.contentType = ContentType('application', 'x-www-form-urlencoded', charset: 'utf-8');
          req.write(b);
        }
        final res = await req.close().timeout(const Duration(seconds: 25));
        final code = res.statusCode;
        if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
          final loc = res.headers.value(HttpHeaders.locationHeader);
          await res.drain<void>();
          if (loc == null) throw const HttpException('redirect without location');
          u = u.resolve(loc);
          if (code != 307 && code != 308) {
            m = 'GET';
            b = null;
          }
          continue;
        }
        final text = await res.transform(utf8.decoder).join().timeout(const Duration(seconds: 25));
        if (code != 200) throw HttpException('HTTP $code');
        final j = jsonDecode(text);
        if (j is! Map<String, dynamic>) throw const FormatException('unexpected response');
        return j;
      }
      throw const HttpException('too many redirects');
    } finally {
      c.close(force: true);
    }
  }

  // ===================================================== misc
  Future<void> openSupport() async {
    try {
      await _native.invokeMethod('openUrl', {'url': kSupportUrl});
    } catch (_) {}
  }

  Future<void> setSecure(bool v) async {
    secureOn = v;
    await _prefs.setBool('pm_secure', v);
    notifyListeners();
  }
}
