import 'dart:io';

import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';

import 'mesh_service.dart';
import 'models.dart';
import 'theme.dart';

String hm(int ts) {
  final d = DateTime.fromMillisecondsSinceEpoch(ts);
  return '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
}

/// "today at 14:32", "yesterday at 09:10", "12 Oct at 18:45"
String lastSeenText(int ts) {
  if (ts <= 0) return 'a while ago';
  final d = DateTime.fromMillisecondsSinceEpoch(ts), n = DateTime.now();
  final days = DateTime(n.year, n.month, n.day).difference(DateTime(d.year, d.month, d.day)).inDays;
  if (days <= 0) return 'today at ${hm(ts)}';
  if (days == 1) return 'yesterday at ${hm(ts)}';
  const m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return '${d.day} ${m[d.month - 1]} at ${hm(ts)}';
}

/// Gradient avatar with an optional presence dot (green = in range & connected).
class PeerAvatar extends StatelessWidget {
  const PeerAvatar({super.key, required this.name, required this.color, this.online, this.size = 46, this.heroTag, this.photo});
  final String? photo; // path of a profile picture, if the person has one
  final String name;
  final int color;
  final bool? online;
  final double size;
  final String? heroTag;

  @override
  Widget build(BuildContext context) {
    final c = C.avatar(color);
    final dot = size * .28;
    final avatar = Stack(clipBehavior: Clip.none, children: [
      Container(
        width: size, height: size, alignment: Alignment.center,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [c, Color.lerp(c, Colors.black, .38)!]),
        ),
        child: photo != null
            ? ClipOval(
                child: Image.file(File(photo!),
                    width: size, height: size, fit: BoxFit.cover, cacheWidth: (size * 3).round(),
                    errorBuilder: (_, __, ___) => _initial()))
            : _initial(),
      ),
      if (online != null)
        Positioned(
          right: -1, bottom: -1,
          child: Container(
            width: dot, height: dot,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: online! ? C.online : C.muted.withOpacity(.55),
              border: Border.all(color: C.bg, width: 2.5),
            ),
          ),
        ),
    ]);
    return heroTag == null ? avatar : Hero(tag: heroTag!, child: avatar);
  }

  Widget _initial() => Text(
        name.trim().isEmpty ? '?' : String.fromCharCode(name.trim().runes.first).toUpperCase(),
        style: TextStyle(fontSize: size * .42, fontWeight: FontWeight.w700, color: Colors.white, decoration: TextDecoration.none),
      );
}

/// Delivery state: clock = queued, one tick = handed to peer link, two ticks = acked.
class Ticks extends StatelessWidget {
  const Ticks(this.s, {super.key});
  final MsgStatus s;
  @override
  Widget build(BuildContext context) => switch (s) {
        MsgStatus.queued => const Icon(Icons.schedule, size: 14, color: Colors.white70),
        MsgStatus.sent => const Icon(Icons.done, size: 15, color: Colors.white70),
        MsgStatus.delivered => const Icon(Icons.done_all, size: 15, color: Color(0xFFC7D2FE)),
      };
}

/// Link quality from round-trip latency (Nearby Connections exposes no RSSI/dBm).
class LinkBars extends StatelessWidget {
  const LinkBars({super.key, required this.rtt, this.active = true});
  final int? rtt;
  final bool active;
  @override
  Widget build(BuildContext context) {
    final n = !active || rtt == null ? 0 : rtt! < 60 ? 4 : rtt! < 120 ? 3 : rtt! < 250 ? 2 : 1;
    return Row(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.end, children: [
      for (var i = 1; i <= 4; i++)
        Container(
          width: 4, height: 4.0 + i * 3, margin: const EdgeInsets.only(right: 2),
          decoration: BoxDecoration(
            color: i <= n ? C.online : C.line, borderRadius: BorderRadius.circular(1.5)),
        ),
    ]);
  }
}

/// Shows startup problems (permissions / Bluetooth) with one-tap recovery.
class MeshBanner extends StatelessWidget {
  const MeshBanner({super.key});
  @override
  Widget build(BuildContext context) {
    final mesh = context.watch<MeshService>();
    if (mesh.error == null) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 4, 16, 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF3B1D2A), borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF7F1D3A))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.bluetooth_disabled, size: 18, color: Color(0xFFFCA5A5)),
          const SizedBox(width: 8),
          Expanded(child: Text(mesh.error!, style: const TextStyle(fontSize: 13))),
        ]),
        const SizedBox(height: 8),
        Row(children: [
          TextButton(onPressed: mesh.start, child: const Text('Retry')),
          TextButton(onPressed: openAppSettings, child: const Text('App settings')),
        ]),
      ]),
    );
  }
}

/// Header pill: live mesh state.
class MeshChip extends StatelessWidget {
  const MeshChip({super.key});
  @override
  Widget build(BuildContext context) {
    final m = context.watch<MeshService>();
    final (color, text) = !m.running
        ? (C.muted, 'Mesh off')
        : m.onlineCount > 0
            ? (C.online, '${m.onlineCount} connected')
            : (C.indigoSoft, 'Searching…');
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(.14), borderRadius: BorderRadius.circular(99),
        border: Border.all(color: color.withOpacity(.5))),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 8, height: 8, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
        const SizedBox(width: 7),
        Text(text, style: TextStyle(color: color, fontSize: 12.5, fontWeight: FontWeight.w700)),
      ]),
    );
  }
}

String ago(int ts) {
  final d = DateTime.fromMillisecondsSinceEpoch(ts), n = DateTime.now();
  final m = n.difference(d).inMinutes;
  if (m < 1) return 'Just now';
  if (m < 60) return '${m}m ago';
  final sameDay = d.year == n.year && d.month == n.month && d.day == n.day;
  return '${sameDay ? 'Today' : 'Yesterday'}, ${hm(ts)}';
}

/// Subtle dot grid used as the chat wallpaper.
class DotsPainter extends CustomPainter {
  const DotsPainter();
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..color = const Color(0x10FFFFFF);
    var row = 0;
    for (double y = 12; y < size.height; y += 26) {
      for (double x = 12 + (row.isOdd ? 13.0 : 0.0); x < size.width; x += 26) {
        canvas.drawCircle(Offset(x, y), 1.1, p);
      }
      row++;
    }
  }

  @override
  bool shouldRepaint(DotsPainter old) => false;
}
