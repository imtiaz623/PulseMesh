import 'dart:async';
import 'dart:typed_data';

import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';

import 'mesh_service.dart';

enum CallState { idle, calling, incoming, connected, ended }

/// 1-to-1 voice and video calls over the existing Nearby link.
///
/// Signalling: JSON {t:'c', a:'ring'|'acc'|'rej'|'busy'|'end'|'cam', id, v}.
/// Media frames are raw payloads whose first byte is a type (JSON starts with '{' = 123):
///   [1, ...40 ms of mu-law audio]      [2, rotation, ...JPEG frame]
class CallService extends ChangeNotifier {
  CallService(this.mesh) {
    mesh.addListener(_watch);
  }

  final MeshService mesh;
  static const _native = MethodChannel('pulsemesh/native');
  static const _mic = EventChannel('pulsemesh/mic');

  CallState state = CallState.idle;
  String? peerId;
  String? _callId;
  bool video = false, outgoing = false, muted = false, speaker = false;
  bool cameraOff = false, remoteCamOff = false, frontCam = true;
  String endNote = '';
  int seconds = 0, remoteRot = 0, localRot = 0;
  Uint8List? remoteFrame, localFrame;
  DateTime? _connectedAt;

  Timer? _ticker, _ringTimer, _tone;
  StreamSubscription<dynamic>? _micSub;
  CameraController? _cam;
  bool _vBusy = false, _nv21 = true;
  int _lastV = 0, _aInflight = 0, _framesOut = 0, _camTries = 0, _q = 40;
  Timer? _camWatch;
  String camErr = '';

  bool get active => state != CallState.idle;

  // ------------------------------------------------------------ outgoing
  Future<void> start(String pid, {required bool withVideo}) async {
    if (active) return;
    final pr = mesh.peers[pid];
    if (pr == null || !pr.online) {
      _flash(pid, 'Peer is offline');
      return;
    }
    if (!await _perms(withVideo)) {
      _flash(pid, withVideo ? 'Camera and microphone access needed' : 'Microphone access needed');
      return;
    }
    _begin(pid, withVideo, outgoing: true, id: DateTime.now().microsecondsSinceEpoch.toString());
    state = CallState.calling;
    notifyListeners();
    mesh.sendJsonTo(pid, {'t': 'c', 'a': 'ring', 'id': _callId, 'v': withVideo ? 1 : 0});
    _ringTimer = Timer(const Duration(seconds: 40), () => _finish('No answer', why: 'No answer', tell: true));
  }

  // ------------------------------------------------------------ incoming
  void onSignal(String from, Map<String, dynamic> j) {
    final id = j['id'] as String?;
    switch (j['a']) {
      case 'ring':
        if (active) {
          mesh.sendJsonTo(from, {'t': 'c', 'a': 'busy', 'id': id});
          return;
        }
        _begin(from, false, outgoing: false, id: id);
        state = CallState.incoming;
        notifyListeners();
        _ring();
        _ringTimer = Timer(const Duration(seconds: 40), () => _finish('Missed call', why: 'Missed'));
      case 'acc':
        if (id == _callId && state == CallState.calling) _connect();
      case 'rej':
        if (id == _callId) _finish('Declined', why: 'Declined');
      case 'busy':
        if (id == _callId) _finish('Busy', why: 'Busy');
      case 'end':
        if (id == _callId && active) {
          _finish(state == CallState.connected ? 'Call ended' : 'Cancelled',
              why: state == CallState.incoming ? 'Missed' : 'Cancelled');
        }
      case 'cam':
        if (id == _callId) {
          remoteCamOff = j['on'] == 0;
          notifyListeners();
        }
    }
  }

  Future<void> accept() async {
    if (state != CallState.incoming) return;
    if (!await _perms(video)) {
      mesh.sendJsonTo(peerId!, {'t': 'c', 'a': 'rej', 'id': _callId});
      _finish('Permission needed', why: 'Declined');
      return;
    }
    mesh.sendJsonTo(peerId!, {'t': 'c', 'a': 'acc', 'id': _callId});
    await _connect();
  }

  void reject() {
    if (peerId == null) return;
    mesh.sendJsonTo(peerId!, {'t': 'c', 'a': 'rej', 'id': _callId});
    _finish('Declined', why: 'Declined');
  }

  Future<void> end() async {
    if (state == CallState.incoming) {
      reject();
      return;
    }
    await _finish(state == CallState.connected ? 'Call ended' : 'Cancelled', why: 'Cancelled', tell: true);
  }

  // ------------------------------------------------------------ controls
  void toggleMute() {
    muted = !muted;
    notifyListeners();
  }

  void toggleSpeaker() {
    speaker = !speaker;
    _native.invokeMethod('audioSpeaker', {'on': speaker}).catchError((_) {});
    notifyListeners();
  }

  void toggleCamera() {
    cameraOff = !cameraOff;
    if (cameraOff) localFrame = null;
    mesh.sendJsonTo(peerId!, {'t': 'c', 'a': 'cam', 'id': _callId, 'on': cameraOff ? 0 : 1});
    notifyListeners();
  }

  Future<void> flipCamera() async {
    frontCam = !frontCam;
    notifyListeners();
    try {
      await _startCamera();
    } catch (_) {}
  }

  // ------------------------------------------------------------ internals
  void _begin(String pid, bool v, {required bool outgoing, String? id}) {
    peerId = pid;
    video = v;
    this.outgoing = outgoing;
    _callId = id;
    muted = cameraOff = remoteCamOff = false;
    frontCam = true;
    speaker = v;
    seconds = 0;
    _connectedAt = null;
    remoteFrame = localFrame = null;
    endNote = '';
    camErr = '';
    _nv21 = true;
    _camTries = 0;
    _q = 40;
  }

  Future<bool> _perms(bool withVideo) async {
    if (!(await Permission.microphone.request()).isGranted) return false;
    if (withVideo && !(await Permission.camera.request()).isGranted) return false;
    return true;
  }

  void _ring() {
    _tone?.cancel();
    if (outgoing) return;
    HapticFeedback.vibrate();
    _tone = Timer.periodic(const Duration(milliseconds: 1400), (_) {
      HapticFeedback.vibrate();
      SystemSound.play(SystemSoundType.alert);
    });
  }

  Future<void> _connect() async {
    _ringTimer?.cancel();
    _tone?.cancel();
    state = CallState.connected;
    _connectedAt = DateTime.now();
    seconds = 0;
    notifyListeners();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      seconds = DateTime.now().difference(_connectedAt!).inSeconds;
      notifyListeners();
    });
    await _startMedia();
  }

  Future<void> _startMedia() async {
    try {
      await _native.invokeMethod('keepAwake', {'on': true});
      await _native.invokeMethod('audioStart', {'speaker': speaker});
      _micSub = _mic.receiveBroadcastStream().listen(_onMic);
      if (video) await _startCamera();
    } catch (e) {
      _finish('Could not start the call ($e)', why: 'Failed', tell: true);
    }
  }

  Future<void> _stopMedia() async {
    await _micSub?.cancel();
    _micSub = null;
    await _stopCamera();
    try {
      await _native.invokeMethod('audioStop');
      await _native.invokeMethod('keepAwake', {'on': false});
    } catch (_) {}
    remoteFrame = localFrame = null;
  }

  void _onMic(dynamic f) {
    if (muted || f is! Uint8List || peerId == null || state != CallState.connected) return;
    if (_aInflight > 12) return; // link is behind: drop instead of building latency
    _aInflight++;
    final b = Uint8List(f.length + 1)
      ..[0] = 1
      ..setRange(1, f.length + 1, f);
    mesh.sendRawTo(peerId!, b).whenComplete(() => _aInflight--).catchError((_) {});
  }

  void onRaw(String from, Uint8List b) {
    if (state != CallState.connected || from != peerId || b.length < 2) return;
    if (b[0] == 1) {
      _native.invokeMethod('audioPlay', Uint8List.sublistView(b, 1)).catchError((_) {});
    } else if (b[0] == 2 && b.length > 3) {
      remoteRot = b[1];
      remoteFrame = Uint8List.sublistView(b, 2);
      notifyListeners();
    }
  }

  // ---- camera
  Future<void> _startCamera() async {
    await _stopCamera();
    final cams = await availableCameras();
    if (cams.isEmpty) {
      camErr = 'No camera found';
      notifyListeners();
      return;
    }
    final want = frontCam ? CameraLensDirection.front : CameraLensDirection.back;
    final cam = cams.firstWhere((c) => c.lensDirection == want, orElse: () => cams.first);
    final c = CameraController(cam, ResolutionPreset.low,
        enableAudio: false,
        imageFormatGroup: _nv21 ? ImageFormatGroup.nv21 : ImageFormatGroup.yuv420);
    await c.initialize();
    _cam = c;
    _framesOut = 0;
    await c.startImageStream(_onCam);
    // no frame went out within 4 s: this phone prefers the other pixel format, try it
    _camWatch?.cancel();
    _camWatch = Timer(const Duration(seconds: 4), () {
      if (_framesOut == 0 && video && state == CallState.connected && _camTries < 3) {
        _camTries++;
        _nv21 = !_nv21;
        _startCamera().catchError((Object e) {
          camErr = '$e';
          notifyListeners();
        });
      }
    });
  }

  Future<void> _stopCamera() async {
    _camWatch?.cancel();
    final c = _cam;
    _cam = null;
    if (c == null) return;
    try {
      if (c.value.isStreamingImages) await c.stopImageStream();
    } catch (_) {}
    try {
      await c.dispose();
    } catch (_) {}
  }

  Future<void> _onCam(CameraImage img) async {
    final cam = _cam;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (cam == null || _vBusy || cameraOff || peerId == null || now - _lastV < 90) return; // ~11 fps
    _vBusy = true;
    _lastV = now;
    try {
      final jpg = await _native.invokeMethod<Uint8List>(
          'jpeg', {'nv21': _toNv21(img), 'w': img.width, 'h': img.height, 'q': _q});
      if (jpg != null && jpg.length >= 30000) {
        _q = _q > 15 ? _q - 10 : 15; // frame too big for one Nearby payload: lower quality
      }
      if (jpg != null && jpg.length < 30000) {
        final rot = (cam.description.sensorOrientation ~/ 90) % 4;
        localRot = rot;
        localFrame = jpg;
        notifyListeners();
        final b = Uint8List(jpg.length + 2)
          ..[0] = 2
          ..[1] = rot
          ..setRange(2, jpg.length + 2, jpg);
        await mesh.sendRawTo(peerId!, b);
        _framesOut++;
      }
    } catch (e) {
      if (camErr.isEmpty) {
        camErr = '$e';
        notifyListeners();
      }
    } finally {
      _vBusy = false;
    }
  }

  Uint8List _toNv21(CameraImage img) {
    if (img.planes.length == 1) return img.planes[0].bytes; // already NV21
    final w = img.width, h = img.height;
    final y = img.planes[0], u = img.planes[1], v = img.planes[2];
    final out = Uint8List(w * h * 3 ~/ 2);
    var o = 0;
    for (var r = 0; r < h; r++) {
      out.setRange(o, o + w, y.bytes, r * y.bytesPerRow);
      o += w;
    }
    final up = u.bytesPerPixel ?? 1, vp = v.bytesPerPixel ?? 1;
    for (var r = 0; r < h ~/ 2; r++) {
      for (var c = 0; c < w ~/ 2; c++) {
        out[o++] = v.bytes[r * v.bytesPerRow + c * vp];
        out[o++] = u.bytes[r * u.bytesPerRow + c * up];
      }
    }
    return out;
  }

  // ---- finish
  String _mmss(int s) => '${(s ~/ 60).toString().padLeft(2, '0')}:${(s % 60).toString().padLeft(2, '0')}';

  String _logFor(String why) {
    final k = video ? 'Video' : 'Voice';
    if (_connectedAt != null) return '$k call · ${_mmss(seconds)}';
    if (outgoing) return '$k call · ${why.isEmpty ? 'Ended' : why}';
    return why == 'Declined' ? '$k call · Declined' : 'Missed ${k.toLowerCase()} call';
  }

  Future<void> _finish(String note, {String why = '', bool tell = false}) async {
    if (state == CallState.idle || state == CallState.ended) return;
    final pid = peerId;
    if (tell && pid != null) mesh.sendJsonTo(pid, {'t': 'c', 'a': 'end', 'id': _callId});
    final log = _logFor(why);
    _ticker?.cancel();
    _ringTimer?.cancel();
    _tone?.cancel();
    state = CallState.ended;
    endNote = note;
    notifyListeners();
    await _stopMedia();
    if (pid != null) mesh.addCallLog(pid, log, outgoing);
    Timer(const Duration(milliseconds: 1500), () {
      if (state == CallState.ended) {
        state = CallState.idle;
        peerId = null;
        notifyListeners();
      }
    });
  }

  void _flash(String pid, String note) {
    peerId = pid;
    video = false;
    endNote = note;
    state = CallState.ended;
    notifyListeners();
    Timer(const Duration(milliseconds: 1800), () {
      if (state == CallState.ended) {
        state = CallState.idle;
        peerId = null;
        notifyListeners();
      }
    });
  }

  void _watch() {
    if (state == CallState.idle || state == CallState.ended || peerId == null) return;
    final p = mesh.peers[peerId];
    if (p == null || !p.online) {
      _finish('Connection lost', why: state == CallState.incoming ? 'Missed' : 'Lost');
    }
  }

  @override
  void dispose() {
    mesh.removeListener(_watch);
    super.dispose();
  }
}
