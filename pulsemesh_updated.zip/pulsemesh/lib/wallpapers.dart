import 'dart:io';

import 'package:flutter/material.dart';

class Wallpaper {
  const Wallpaper(this.name, this.a, this.b);
  final String name;
  final Color a, b;
}

/// Dark, calm backgrounds that keep message bubbles readable.
const kWallpapers = <Wallpaper>[
  Wallpaper('Forest', Color(0xFF07130D), Color(0xFF123424)),
  Wallpaper('Midnight', Color(0xFF0A1020), Color(0xFF16233F)),
  Wallpaper('Ocean', Color(0xFF05202A), Color(0xFF0C4256)),
  Wallpaper('Plum', Color(0xFF180A22), Color(0xFF34154A)),
  Wallpaper('Ember', Color(0xFF1E0D07), Color(0xFF45200E)),
  Wallpaper('Slate', Color(0xFF0F1113), Color(0xFF23282D)),
  Wallpaper('Rose', Color(0xFF220B14), Color(0xFF4A1830)),
  Wallpaper('Black', Color(0xFF000000), Color(0xFF000000)),
];

LinearGradient wallpaperGradient(Wallpaper w) =>
    LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [w.a, w.b]);

/// spec: '' = default | 'g:N' = preset N | 'f:/path' = a photo the user picked.
Widget wallpaperLayer(String spec, {required Widget fallback}) {
  if (spec.startsWith('g:')) {
    final i = int.tryParse(spec.substring(2)) ?? 0;
    return DecoratedBox(decoration: BoxDecoration(gradient: wallpaperGradient(kWallpapers[i % kWallpapers.length])));
  }
  if (spec.startsWith('f:')) {
    final path = spec.substring(2);
    if (File(path).existsSync()) {
      return Stack(fit: StackFit.expand, children: [
        Image.file(File(path), fit: BoxFit.cover, errorBuilder: (_, __, ___) => fallback),
        Container(color: Colors.black.withOpacity(.38)), // keeps text readable on any photo
      ]);
    }
  }
  return fallback;
}
