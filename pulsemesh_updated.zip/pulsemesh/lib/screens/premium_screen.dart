import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../mesh_service.dart';
import '../premium.dart';
import '../theme.dart';

void openPremium(BuildContext context, {String? reason}) => Navigator.push(
    context, MaterialPageRoute(builder: (_) => PremiumScreen(reason: reason)));

class PremiumScreen extends StatefulWidget {
  const PremiumScreen({super.key, this.reason});
  final String? reason;
  @override
  State<PremiumScreen> createState() => _PremiumScreenState();
}

class _PremiumScreenState extends State<PremiumScreen> {
  String _sel = kYearly;
  final _trx = TextEditingController();

  static const _gold = Color(0xFFFBBF24);

  static const _features = <(IconData, String)>[
    (Icons.block_rounded, 'Ad-free experience'),
    (Icons.chat_bubble_outline_rounded, 'Unlimited messages / offline chats'),
    (Icons.attach_file_rounded, 'Send photos, files and voice notes'),
    (Icons.palette_outlined, 'Custom themes and chat wallpapers'),
    (Icons.backup_outlined, 'Chat backup and restore'),
    (Icons.visibility_off_outlined, 'Hide Chat & Delete Chat features'),
    (Icons.camera_alt_outlined, 'Screenshot alerts and screenshot blocking'),
    (Icons.delete_forever_outlined, 'Delete for everyone and see deleted messages'),
    (Icons.support_agent_rounded, 'Priority support'),
  ];

  @override
  void initState() {
    super.initState();
    // check the status every time this screen opens
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) context.read<MeshService>().premium.refresh();
    });
  }

  @override
  void dispose() {
    _trx.dispose();
    super.dispose();
  }

  bool get _trxOk => _trx.text.trim().length >= 6;

  Future<void> _submit(Premium pr) async {
    FocusScope.of(context).unfocus();
    final ok = await pr.submitPayment(_sel, _trx.text.trim());
    if (ok) _trx.clear();
  }

  @override
  Widget build(BuildContext context) {
    final pr = context.watch<MeshService>().premium;
    return Scaffold(
      appBar: AppBar(title: const Text('OffChat Premium')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        _header(pr),
        if (widget.reason != null && !pr.active) ...[
          const SizedBox(height: 12),
          Text(widget.reason!, style: const TextStyle(color: C.indigoSoft)),
        ],
        const SizedBox(height: 14),
        const Text('Premium benefits', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        const SizedBox(height: 4),
        for (final f in _features)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: Row(children: [
              Icon(f.$1, color: C.indigoSoft, size: 22),
              const SizedBox(width: 12),
              Expanded(child: Text(f.$2, style: const TextStyle(fontSize: 14.5))),
            ]),
          ),
        if (pr.active)
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Block screenshots on this phone'),
            subtitle: const Text('Also hides OffChat in the recent-apps screen.'),
            value: pr.secureOn,
            onChanged: (v) => pr.setSecure(v),
          ),
        const Divider(height: 28),
        if (!pr.active) ...[
          if (pr.expired) _notice(pr.expiredNotice),
          if (pr.paymentPending) ..._pending(pr) else ..._form(pr),
        ],
        if (pr.message != null) ...[
          const SizedBox(height: 12),
          Text(pr.message!, style: const TextStyle(color: _gold, height: 1.4)),
        ],
        const SizedBox(height: 8),
        Center(
          child: TextButton.icon(
            onPressed: pr.openSupport,
            icon: const Icon(Icons.support_agent_rounded, size: 18),
            label: const Text('Need help? Contact support'),
          ),
        ),
        const SizedBox(height: 4),
        const Text(
            'Payments are verified manually, which can take a few hours. Premium is linked to this phone '
            'and stays after an app update or reinstall.',
            style: TextStyle(color: C.muted, fontSize: 12.5, height: 1.4)),
      ]),
    );
  }

  Widget _header(Premium pr) {
    final title = pr.active
        ? 'Premium Active'
        : pr.paymentPending
            ? 'Payment under review'
            : 'Go Premium';
    final sub = pr.active
        ? '${pr.planLabel} · ${pr.expiryLabel}'
        : pr.paymentPending
            ? '${planTitle(pr.pendingPlan)} plan · waiting for approval'
            : 'Pick a plan below';
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: const LinearGradient(colors: [Color(0xFF16A34A), Color(0xFF166534)]),
      ),
      child: Row(children: [
        Icon(pr.active ? Icons.verified_rounded : Icons.workspace_premium_rounded, size: 40, color: Colors.white),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 2),
            Text(sub, style: const TextStyle(color: Colors.white70)),
          ]),
        ),
      ]),
    );
  }

  Widget _notice(String text) => Container(
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: _gold.withOpacity(.12),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _gold.withOpacity(.5)),
        ),
        child: Row(children: [
          const Icon(Icons.info_outline_rounded, color: _gold),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(color: _gold, fontWeight: FontWeight.w600))),
        ]),
      );

  /// Shown while a payment is waiting for approval: the form is replaced by "Check Status".
  List<Widget> _pending(Premium pr) => [
        _notice('Request received for ${planTitle(pr.pendingPlan)} plan. Verification may take a few hours. '
            'Premium will unlock automatically once approved.'),
        FilledButton.icon(
          onPressed: pr.checking ? null : pr.checkStatus,
          icon: pr.checking
              ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.refresh_rounded),
          label: const Text('Check Status'),
        ),
      ];

  List<Widget> _form(Premium pr) => [
        _plan(pr, kYearly, 'Yearly', '365 days', badge: 'SAVE 37%'),
        _plan(pr, kMonthly, 'Monthly', '30 days'),
        _plan(pr, kLifetime, 'Lifetime', 'one payment, no renewals', badge: 'BEST VALUE'),
        const SizedBox(height: 6),
        _payCard(),
        const SizedBox(height: 14),
        const Text('How to pay', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        const SizedBox(height: 6),
        _step(1, 'Select a plan.'),
        _step(2, 'Send the exact amount (Rs ${kPlanPrice[_sel]}) to the Easypaisa number.'),
        _step(3, 'Copy the Transaction ID (TRX ID) from the SMS / receipt.'),
        _step(4, 'Paste the TRX ID below and tap Submit.'),
        const SizedBox(height: 10),
        TextField(
          controller: _trx,
          enabled: !pr.busy,
          onChanged: (_) => setState(() {}),
          textInputAction: TextInputAction.done,
          decoration: InputDecoration(
            labelText: 'Transaction ID (TRX ID)',
            helperText: 'At least 6 characters',
            errorText: _trx.text.isNotEmpty && !_trxOk ? 'TRX ID is too short' : null,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: (pr.busy || !_trxOk) ? null : () => _submit(pr),
          icon: pr.busy
              ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.send_rounded),
          label: Text('Submit Payment · Rs ${kPlanPrice[_sel]}'),
        ),
        const SizedBox(height: 6),
        OutlinedButton.icon(
          onPressed: pr.checking ? null : pr.checkStatus,
          icon: pr.checking
              ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.refresh_rounded),
          label: const Text('Check Status'),
        ),
      ];

  Widget _payCard() => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: C.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: C.line),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Payment details', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          const SizedBox(height: 8),
          _kv('Method', kPayMethod),
          Row(children: [
            Expanded(child: _kv('Account number', kPayNumber)),
            TextButton.icon(
              onPressed: () {
                Clipboard.setData(const ClipboardData(text: kPayNumber));
                ScaffoldMessenger.of(context)
                    .showSnackBar(const SnackBar(content: Text('Account number copied')));
              },
              icon: const Icon(Icons.copy_rounded, size: 16),
              label: const Text('Copy'),
            ),
          ]),
          _kv('Account title', kPayTitle),
          _kv('Amount to send', 'Rs ${kPlanPrice[_sel]} (${planTitle(_sel)})', bold: true),
        ]),
      );

  Widget _kv(String k, String v, {bool bold = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(width: 120, child: Text(k, style: const TextStyle(color: C.muted, fontSize: 13))),
          Expanded(child: Text(v, style: TextStyle(fontWeight: bold ? FontWeight.w800 : FontWeight.w600))),
        ]),
      );

  Widget _step(int n, String t) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          CircleAvatar(radius: 11, backgroundColor: C.indigo, child: Text('$n', style: const TextStyle(fontSize: 12))),
          const SizedBox(width: 10),
          Expanded(child: Text('Step $n: $t', style: const TextStyle(height: 1.3))),
        ]),
      );

  Widget _plan(Premium pr, String id, String title, String sub, {String? badge}) {
    final on = _sel == id;
    return GestureDetector(
      onTap: pr.busy ? null : () => setState(() => _sel = id),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: on ? C.surface2 : C.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: on ? C.indigoSoft : C.line, width: on ? 2 : 1),
        ),
        child: Row(children: [
          Icon(on ? Icons.radio_button_checked : Icons.radio_button_off, color: on ? C.indigoSoft : C.muted),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              if (badge != null)
                Padding(
                    padding: const EdgeInsets.only(bottom: 3),
                    child: Text(badge,
                        style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800, color: _gold))),
              Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              Text(sub, style: const TextStyle(color: C.muted, fontSize: 12.5)),
            ]),
          ),
          Text('Rs ${kPlanPrice[id]}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
        ]),
      ),
    );
  }
}
