import 'package:flutter/material.dart';

import '../theme.dart';

/// Plain-language privacy page. Keep it in sync with PRIVACY_POLICY.md.
class PrivacyScreen extends StatelessWidget {
  const PrivacyScreen({super.key});

  static const _sections = <(String, String)>[
    ('The short version',
        'OffChat has no accounts, no servers, no ads and no analytics. Your chats live on your phone and are sent '
            'only to the people you chat with, directly over Bluetooth / Wi-Fi.'),
    ('What is stored on your phone',
        'Messages, photos, videos, voice notes, statuses, your contacts list, wallpapers and settings. It is kept in '
            'a local database and app files. You can erase it any time with "Clear chats" in Profile, or by uninstalling. '
            'If Android backup is switched on for your phone, Android may keep a copy of your chat history (not the media '
            'files) in your own Google account backup, so chats can come back after a reinstall.'),
    ('What nearby people can see',
        'Your display name, colour, profile photo, cover photo and bio; the statuses you post; whether you are connected '
            'now and when you were last connected ("last seen"); and delete or screenshot notices for chats with them.'),
    ('How messages are protected',
        'Every direct link between two OffChat phones is encrypted and authenticated by Google Nearby Connections. '
            'When a text is relayed through another phone, that phone can technically read it. End-to-end encryption '
            'for relayed messages is planned; OffChat does not claim it today.'),
    ('Why OffChat asks for permissions',
        'Bluetooth / Nearby devices: to find and connect to phones around you.\n'
            'Location: Android requires it for Bluetooth scanning. OffChat does not read, store or send your location.\n'
            'Microphone: voice notes and calls.\n'
            'Camera: photos, videos, calls and statuses.\n'
            'Photos / media: to notice when a screenshot is taken (only the newest screenshot\'s name and time are checked).\n'
            'Notifications: a small ongoing notice keeps you reachable while the app is closed.\n'
            'Internet: only to download official OffChat updates and to verify Premium payments.'),
    ('Screenshots',
        'When you take a screenshot of a chat, your phone tells the other person. Premium members see these alerts and '
            'can block screenshots on their own phone.'),
    ('Deleting messages',
        '"Delete for me" removes a message from your phone. "Delete for everyone" (Premium) asks the other phone to '
            'remove it too; Premium members can still read messages others delete for everyone.'),
    ('Purchases',
        'Premium is paid manually through Easypaisa. When you submit a payment, OffChat sends the transaction ID, '
            'the plan you chose and a random device ID to the developer\'s verification sheet so the payment can be '
            'approved. OffChat never sees your wallet PIN or payment account details.'),
    ('Children',
        'OffChat is not directed to children under 13.'),
    ('Changes',
        'If this page changes in a way that matters, the new version appears in the app update.'),
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Privacy & data')),
        body: ListView(padding: const EdgeInsets.all(18), children: [
          for (final s in _sections) ...[
            Text(s.$1, style: const TextStyle(fontSize: 16.5, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            Text(s.$2, style: const TextStyle(color: C.muted, height: 1.45)),
            const SizedBox(height: 18),
          ],
        ]),
      );
}
