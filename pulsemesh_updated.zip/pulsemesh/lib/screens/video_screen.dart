import 'dart:io';

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

/// Full-screen player for a received or sent video.
class VideoScreen extends StatefulWidget {
  const VideoScreen({super.key, required this.path});
  final String path;
  @override
  State<VideoScreen> createState() => _VideoScreenState();
}

class _VideoScreenState extends State<VideoScreen> {
  late final VideoPlayerController _c;
  bool _ready = false, _failed = false;

  @override
  void initState() {
    super.initState();
    _c = VideoPlayerController.file(File(widget.path));
    _c.addListener(() {
      if (mounted) setState(() {});
    });
    _c.initialize().then((_) {
      if (!mounted) return;
      setState(() => _ready = true);
      _c.play();
    }).catchError((Object _) {
      if (mounted) setState(() => _failed = true);
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final playing = _c.value.isPlaying;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.transparent, elevation: 0),
      body: Center(
        child: _failed
            ? const Text('This video cannot be played on this phone.',
                style: TextStyle(color: Colors.white70))
            : !_ready
                ? const CircularProgressIndicator()
                : Column(mainAxisSize: MainAxisSize.min, children: [
                    AspectRatio(aspectRatio: _c.value.aspectRatio, child: VideoPlayer(_c)),
                    const SizedBox(height: 10),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: VideoProgressIndicator(_c, allowScrubbing: true),
                    ),
                    IconButton(
                      iconSize: 52,
                      color: Colors.white,
                      icon: Icon(playing ? Icons.pause_circle_filled_rounded : Icons.play_circle_fill_rounded),
                      onPressed: () => playing ? _c.pause() : _c.play(),
                    ),
                  ]),
      ),
    );
  }
}
