import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../mesh_service.dart';
import '../theme.dart';
import '../wallpapers.dart';

/// Per-chat wallpaper (peerId given) or the default for every chat (peerId null).
Future<void> showWallpaperPicker(BuildContext context, {String? peerId}) => showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: C.surface,
      builder: (_) => _WallpaperSheet(peerId: peerId),
    );

class _WallpaperSheet extends StatefulWidget {
  const _WallpaperSheet({required this.peerId});
  final String? peerId;
  @override
  State<_WallpaperSheet> createState() => _WallpaperSheetState();
}

class _WallpaperSheetState extends State<_WallpaperSheet> {
  bool _all = false;

  Future<void> _set(String spec) async {
    final mesh = context.read<MeshService>();
    await mesh.setWallpaper(_all ? null : widget.peerId, spec, clearOverrides: _all);
    if (mounted) Navigator.pop(context);
  }

  Future<void> _photo() async {
    final mesh = context.read<MeshService>();
    try {
      final x = await ImagePicker().pickImage(source: ImageSource.gallery);
      if (x == null) return;
      await mesh.setWallpaperPhoto(_all ? null : widget.peerId, x.path, clearOverrides: _all);
      if (mounted) Navigator.pop(context);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not use that photo')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final mesh = context.watch<MeshService>();
    final current = mesh.wallpaperOf(widget.peerId ?? '');
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 10),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(widget.peerId == null ? 'Default wallpaper' : 'Chat wallpaper',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 14),
          Wrap(spacing: 12, runSpacing: 12, children: [
            _swatch(null, 'Default', current.isEmpty),
            for (var i = 0; i < kWallpapers.length; i++) _swatch(i, kWallpapers[i].name, current == 'g:$i'),
          ]),
          const SizedBox(height: 8),
          if (widget.peerId != null)
            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              controlAffinity: ListTileControlAffinity.leading,
              value: _all,
              onChanged: (v) => setState(() => _all = v ?? false),
              title: const Text('Use for all chats'),
            ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.photo_library_outlined),
            title: const Text('Choose a photo'),
            onTap: _photo,
          ),
        ]),
      ),
    );
  }

  Widget _swatch(int? i, String label, bool on) => GestureDetector(
        onTap: () => _set(i == null ? '' : 'g:$i'),
        child: Column(children: [
          Container(
            width: 64, height: 92,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              gradient: i == null ? null : wallpaperGradient(kWallpapers[i]),
              color: i == null ? C.bg : null,
              border: Border.all(color: on ? C.indigoSoft : C.line, width: on ? 2.5 : 1),
            ),
            child: i == null ? const Icon(Icons.blur_on_rounded, color: C.muted) : null,
          ),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(fontSize: 11.5, color: C.muted)),
        ]),
      );
}
