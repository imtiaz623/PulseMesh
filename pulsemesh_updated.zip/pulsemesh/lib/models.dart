enum MsgStatus { queued, sent, delivered }

class Peer {
  Peer({required this.id, required this.name, required this.color, this.lastSeen = 0, this.bio = ''});

  final String id; // stable 8-char device id (survives Nearby endpoint rotation)
  String name;
  int color;
  int lastSeen;
  String bio; // WhatsApp-style "about" line, max 140 chars

  // runtime-only state
  String? endpointId;
  bool online = false;
  bool discovered = false;
  bool connecting = false;
  int? rtt; // round-trip ms, measured by ping/pong
  int hops = 0, hopsTs = 0; // >0: reachable through other phones (mesh relay)
  String? via;
  bool get relayed =>
      !online && hops > 0 && DateTime.now().millisecondsSinceEpoch - hopsTs < 45000;

  Map<String, Object?> toMap() =>
      {'id': id, 'name': name, 'color': color, 'last_seen': lastSeen, 'bio': bio};

  factory Peer.fromMap(Map<String, Object?> m) => Peer(
        id: m['id'] as String,
        name: m['name'] as String,
        color: m['color'] as int,
        lastSeen: m['last_seen'] as int,
        bio: (m['bio'] as String?) ?? '',
      );
}

class Message {
  Message({
    required this.id,
    required this.peerId,
    required this.outgoing,
    required this.type, // 'text' | 'image' | 'voice'
    required this.body,
    this.path,
    required this.ts,
    this.status = MsgStatus.queued,
    this.read = true,
    this.dur = 0,
    this.deleted = false,
    this.hidden = false,
  });

  final String id, peerId;
  String type, body;
  String? path;
  final bool outgoing;
  final int ts, dur; // dur = voice length in ms
  MsgStatus status;
  bool read;
  bool deleted; // sender deleted it for everyone
  bool hidden;  // I deleted it for me

  Map<String, Object?> toMap() => {
        'dur': dur,
        'deleted': hidden ? 2 : (deleted ? 1 : 0),
        'id': id, 'peer_id': peerId, 'outgoing': outgoing ? 1 : 0, 'type': type,
        'body': body, 'path': path, 'ts': ts, 'status': status.index, 'is_read': read ? 1 : 0,
      };

  factory Message.fromMap(Map<String, Object?> m) => Message(
        id: m['id'] as String,
        peerId: m['peer_id'] as String,
        outgoing: (m['outgoing'] as int) == 1,
        type: m['type'] as String,
        body: m['body'] as String,
        path: m['path'] as String?,
        ts: m['ts'] as int,
        status: MsgStatus.values[m['status'] as int],
        read: (m['is_read'] as int) == 1,
        dur: (m['dur'] as int?) ?? 0,
        deleted: ((m['deleted'] as int?) ?? 0) == 1,
        hidden: ((m['deleted'] as int?) ?? 0) == 2,
      );
}

/// A 24-hour status update (image or colored text), like WhatsApp Status.
class StatusItem {
  StatusItem({
    required this.id, required this.authorId, required this.kind, this.path,
    this.text = '', this.color = 0, required this.ts, this.viewed = false, this.reported = false,
    this.ttlH = 24,
  });

  final String id, authorId, kind, text; // kind: 'image' | 'text'
  final String? path;
  final int color, ts, ttlH; // ttlH = hours it stays visible
  bool viewed;   // I have seen it (statuses from others)
  bool reported; // the author has been told I saw it

  bool get expired => DateTime.now().millisecondsSinceEpoch - ts > ttlH * 3600 * 1000;

  Map<String, Object?> toMap() => {
        'id': id, 'author_id': authorId, 'kind': kind, 'path': path, 'text': text,
        'color': color, 'ts': ts, 'viewed': viewed ? 1 : 0, 'reported': reported ? 1 : 0,
      };

  factory StatusItem.fromMap(Map<String, Object?> m) => StatusItem(
        id: m['id'] as String, authorId: m['author_id'] as String, kind: m['kind'] as String,
        path: m['path'] as String?, text: m['text'] as String, color: m['color'] as int,
        ts: m['ts'] as int, viewed: (m['viewed'] as int) == 1, reported: (m['reported'] as int) == 1,
      );
}

/// An emergency alert received over the mesh.
class SosAlert {
  SosAlert({required this.id, required this.fromId, required this.name, required this.text, required this.ts, required this.hops});
  final String id, fromId, name, text;
  final int ts, hops;
}
