package com.pulsemesh.pulsemesh

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Real-time call audio. 16 kHz mono, 40 ms frames, G.711 mu-law (8 bit) on the wire.
 * Capture uses VOICE_COMMUNICATION with echo cancel, noise suppression and auto gain.
 */
class CallAudio(ctx: Context, private val onFrame: (ByteArray) -> Unit) {
    private val rate = 16000
    private val frame = 640 // samples = 40 ms
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var rec: AudioRecord? = null
    private var track: AudioTrack? = null
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null
    private var agc: AutomaticGainControl? = null
    private val queue = LinkedBlockingQueue<ByteArray>(8) // small jitter buffer (320 ms max)
    @Volatile private var running = false
    private var capture: Thread? = null
    private var player: Thread? = null

    @SuppressLint("MissingPermission")
    fun start(speaker: Boolean) {
        if (running) return
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        am.isSpeakerphoneOn = speaker

        val minIn = AudioRecord.getMinBufferSize(
            rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION, rate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minIn, frame * 8))
        if (r.state != AudioRecord.STATE_INITIALIZED) {
            r.release()
            throw IllegalStateException("Microphone is not available")
        }
        rec = r
        val sid = r.audioSessionId
        if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(sid)?.also { it.enabled = true }
        if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(sid)?.also { it.enabled = true }
        if (AutomaticGainControl.isAvailable()) agc = AutomaticGainControl.create(sid)?.also { it.enabled = true }

        val minOut = AudioTrack.getMinBufferSize(
            rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build())
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(rate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build())
            .setBufferSizeInBytes(maxOf(minOut, frame * 2 * 4))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = t

        running = true
        r.startRecording()
        t.play()

        capture = Thread {
            val buf = ShortArray(frame)
            while (running) {
                var n = 0
                while (n < frame && running) {
                    val got = r.read(buf, n, frame - n)
                    if (got < 0) { running = false; break }
                    n += got
                }
                if (n == frame && running) {
                    val out = ByteArray(frame)
                    for (i in 0 until frame) out[i] = enc(buf[i])
                    onFrame(out)
                }
            }
        }.also { it.priority = Thread.MAX_PRIORITY; it.start() }

        player = Thread {
            while (running) {
                val f = queue.poll(100, TimeUnit.MILLISECONDS) ?: continue
                val pcm = ShortArray(f.size) { dec(f[it]) }
                t.write(pcm, 0, pcm.size)
            }
        }.also { it.start() }
    }

    /** Queue a received frame; if we fall behind, drop the oldest so latency stays low. */
    fun play(frameBytes: ByteArray) {
        if (!running) return
        if (!queue.offer(frameBytes)) {
            queue.poll()
            queue.offer(frameBytes)
        }
    }

    fun setSpeaker(on: Boolean) {
        am.isSpeakerphoneOn = on
    }

    fun stop() {
        running = false
        try { capture?.join(300) } catch (_: Exception) {}
        try { player?.join(300) } catch (_: Exception) {}
        try { rec?.stop() } catch (_: Exception) {}
        rec?.release(); rec = null
        try { track?.stop() } catch (_: Exception) {}
        track?.release(); track = null
        aec?.release(); aec = null
        ns?.release(); ns = null
        agc?.release(); agc = null
        queue.clear()
        am.isSpeakerphoneOn = false
        am.mode = AudioManager.MODE_NORMAL
    }

    // ---- G.711 mu-law
    private fun enc(sample: Short): Byte {
        var v = sample.toInt()
        val sign = if (v < 0) { v = -v; 0x80 } else 0
        if (v > 32635) v = 32635
        v += 132
        var exp = 7
        var mask = 0x4000
        while (exp > 0 && (v and mask) == 0) { exp--; mask = mask shr 1 }
        val man = (v shr (exp + 3)) and 0x0F
        return (sign or (exp shl 4) or man).inv().toByte()
    }

    private fun dec(b: Byte): Short {
        val u = b.toInt().inv() and 0xFF
        val sign = u and 0x80
        val exp = (u shr 4) and 7
        val man = u and 0x0F
        var v = ((man shl 3) + 132) shl exp
        v -= 132
        return (if (sign != 0) -v else v).toShort()
    }
}
