package com.pulsemesh.pulsemesh

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.ContentResolver
import android.content.Intent
import android.database.ContentObserver
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.media.ExifInterface
import android.graphics.Rect
import android.graphics.YuvImage
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream

/** Native bridge: Bluetooth prompt, foreground service, call audio, video JPEG encoding. */
class MainActivity : FlutterActivity() {

    private val reqEnableBt = 7301
    private var btResult: MethodChannel.Result? = null
    private var micSink: EventChannel.EventSink? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var audio: CallAudio? = null
    private var shotSink: EventChannel.EventSink? = null
    private var shotObserver: ContentObserver? = null
    private var lastShotMs = 0L

    private fun adapter(): BluetoothAdapter? =
        (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val messenger = flutterEngine.dartExecutor.binaryMessenger

        EventChannel(messenger, "pulsemesh/mic").setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(arguments: Any?, events: EventChannel.EventSink?) { micSink = events }
            override fun onCancel(arguments: Any?) { micSink = null }
        })

        EventChannel(messenger, "pulsemesh/shots").setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(arguments: Any?, events: EventChannel.EventSink?) { shotSink = events }
            override fun onCancel(arguments: Any?) { shotSink = null }
        })

        MethodChannel(messenger, "pulsemesh/native").setMethodCallHandler { call, result ->
            when (call.method) {
                "sdkInt" -> result.success(Build.VERSION.SDK_INT)
                "isBluetoothOn" -> result.success(adapter()?.isEnabled == true)
                "requestEnableBluetooth" -> {
                    val a = adapter()
                    when {
                        a == null -> result.success(false)
                        a.isEnabled -> result.success(true)
                        btResult != null -> result.error("busy", "Request in progress", null)
                        else -> {
                            btResult = result
                            @Suppress("DEPRECATION")
                            startActivityForResult(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), reqEnableBt)
                        }
                    }
                }
                "startService" -> {
                    val i = Intent(this, MeshService::class.java)
                        .putExtra("text", call.argument<String>("text"))
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                    result.success(true)
                }
                "stopService" -> {
                    stopService(Intent(this, MeshService::class.java))
                    result.success(true)
                }
                "audioStart" -> {
                    try {
                        audio?.stop()
                        val a = CallAudio(this) { f -> mainHandler.post { micSink?.success(f) } }
                        audio = a
                        a.start(call.argument<Boolean>("speaker") ?: false)
                        result.success(true)
                    } catch (e: Exception) {
                        audio = null
                        result.error("audio", e.message, null)
                    }
                }
                "audioStop" -> { audio?.stop(); audio = null; result.success(true) }
                "audioPlay" -> {
                    (call.arguments as? ByteArray)?.let { audio?.play(it) }
                    result.success(null)
                }
                "audioSpeaker" -> {
                    audio?.setSpeaker(call.argument<Boolean>("on") ?: false)
                    result.success(null)
                }
                "keepAwake" -> {
                    val on = call.argument<Boolean>("on") ?: false
                    if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    result.success(null)
                }
                "crop" -> {
                    val path = call.argument<String>("path") ?: ""
                    val w = call.argument<Int>("w") ?: 256
                    val h = call.argument<Int>("h") ?: 256
                    val q = call.argument<Int>("q") ?: 80
                    Thread {
                        try {
                            result.success0(mainHandler, cropJpeg(path, w, h, q))
                        } catch (e: Exception) {
                            mainHandler.post { result.error("avatar", e.message, null) }
                        }
                    }.start()
                }
                "secure" -> {
                    val on = call.argument<Boolean>("on") ?: false
                    if (on) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                    else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                    result.success(null)
                }
                "shotWatch" -> {
                    if (call.argument<Boolean>("on") == true) startShotWatch() else stopShotWatch()
                    result.success(null)
                }
                "jpeg" -> {
                    try {
                        val nv21 = call.argument<ByteArray>("nv21")!!
                        val w = call.argument<Int>("w")!!
                        val h = call.argument<Int>("h")!!
                        val q = call.argument<Int>("q") ?: 40
                        val out = ByteArrayOutputStream()
                        YuvImage(nv21, ImageFormat.NV21, w, h, null).compressToJpeg(Rect(0, 0, w, h), q, out)
                        result.success(out.toByteArray())
                    } catch (e: Exception) {
                        result.error("jpeg", e.message, null)
                    }
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun MethodChannel.Result.success0(h: Handler, v: Any?) { h.post { this.success(v) } }

    /** Centre-crops a photo to w:h, fixes its rotation and returns a JPEG (profile photo, cover, wallpaper). */
    private fun cropJpeg(path: String, w: Int, h: Int, quality: Int): ByteArray {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= w * 2 && bounds.outHeight / (sample * 2) >= h * 2) sample *= 2
        var bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: throw IllegalStateException("cannot read image")
        val deg = try {
            when (ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } catch (e: Exception) { 0f }
        if (deg != 0f) {
            val m = Matrix(); m.postRotate(deg)
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        val want = w.toFloat() / h.toFloat()
        val have = bmp.width.toFloat() / bmp.height.toFloat()
        val cw: Int
        val ch: Int
        if (have > want) { ch = bmp.height; cw = (bmp.height * want).toInt() } else { cw = bmp.width; ch = (bmp.width / want).toInt() }
        val cropped = Bitmap.createBitmap(bmp, (bmp.width - cw) / 2, (bmp.height - ch) / 2, cw, ch)
        val out = Bitmap.createScaledBitmap(cropped, w, h, true)
        val bos = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, quality, bos)
        return bos.toByteArray()
    }

    /** Watches the gallery for a fresh file called "Screenshot..." (works on every Android version). */
    private fun startShotWatch() {
        if (shotObserver != null) return
        val obs = object : ContentObserver(mainHandler) {
            override fun onChange(selfChange: Boolean, uri: Uri?) {
                val now = System.currentTimeMillis()
                if (now - lastShotMs < 2500) return
                if (newestIsScreenshot()) {
                    lastShotMs = now
                    shotSink?.success(true)
                }
            }
        }
        contentResolver.registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, obs)
        shotObserver = obs
    }

    private fun stopShotWatch() {
        shotObserver?.let { contentResolver.unregisterContentObserver(it) }
        shotObserver = null
    }

    private fun newestIsScreenshot(): Boolean {
        try {
            val uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val proj = arrayOf(MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.DATE_ADDED)
            val cur = if (Build.VERSION.SDK_INT >= 26) {
                val args = Bundle()
                args.putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(MediaStore.Images.Media.DATE_ADDED))
                args.putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING)
                args.putInt(ContentResolver.QUERY_ARG_LIMIT, 1)
                contentResolver.query(uri, proj, args, null)
            } else {
                contentResolver.query(uri, proj, null, null, MediaStore.Images.Media.DATE_ADDED + " DESC LIMIT 1")
            }
            cur?.use { c ->
                if (c.moveToFirst()) {
                    val name = (c.getString(0) ?: "").lowercase()
                    val fresh = (System.currentTimeMillis() / 1000 - c.getLong(1)) < 15
                    return fresh && (name.contains("screenshot") || name.contains("screen_shot") ||
                        name.contains("screen-shot") || name.contains("screencap"))
                }
            }
        } catch (e: Exception) {
        }
        return false
    }

    override fun onDestroy() {
        stopShotWatch()
        audio?.stop()
        audio = null
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == reqEnableBt) {
            btResult?.success(resultCode == RESULT_OK)
            btResult = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }
}
