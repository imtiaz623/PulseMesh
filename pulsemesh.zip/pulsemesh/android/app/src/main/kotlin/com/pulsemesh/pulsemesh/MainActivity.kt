package com.pulsemesh.pulsemesh

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/** Native bridge: Bluetooth enable prompt, SDK level, foreground service control. */
class MainActivity : FlutterActivity() {

    private val reqEnableBt = 7301
    private var btResult: MethodChannel.Result? = null

    private fun adapter(): BluetoothAdapter? =
        (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "pulsemesh/native")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "sdkInt" -> result.success(Build.VERSION.SDK_INT)
                    "isBluetoothOn" -> result.success(adapter()?.isEnabled == true)
                    "requestEnableBluetooth" -> {
                        // Android 13+ forbids silently enabling Bluetooth: the system
                        // shows an "Allow PulseMesh to turn on Bluetooth?" dialog.
                        val a = adapter()
                        when {
                            a == null -> result.success(false)
                            a.isEnabled -> result.success(true)
                            btResult != null -> result.error("busy", "Request in progress", null)
                            else -> {
                                btResult = result
                                @Suppress("DEPRECATION")
                                startActivityForResult(
                                    Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), reqEnableBt
                                )
                            }
                        }
                    }
                    "startService" -> {
                        val i = Intent(this, MeshService::class.java)
                            .putExtra("text", call.argument<String>("text"))
                        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                        result.success(true)
                    }
                    "stopService" -> {
                        stopService(Intent(this, MeshService::class.java))
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == reqEnableBt) {
            btResult?.success(resultCode == RESULT_OK)
            btResult = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }
}
