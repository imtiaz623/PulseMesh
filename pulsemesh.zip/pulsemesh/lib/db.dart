import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import 'models.dart';

/// SQLite storage: peers, chat history (the offline queue is every outgoing message
/// whose status is not "delivered"), and 24-hour statuses with view receipts.
class Db {
  late Database _db;

  Future<void> open() async {
    final path = p.join(await getDatabasesPath(), 'pulsemesh.db');
    try {
      _db = await _open(path);
    } catch (_) {
      await deleteDatabase(path); // corrupt/old file: start fresh instead of a dead app
      _db = await _open(path);
    }
  }

  Future<Database> _open(String path) {
    return openDatabase(
      path,
      version: 2,
      onUpgrade: (d, o, n) async {
        if (o < 2) {
          await d.execute('ALTER TABLE messages ADD COLUMN deleted INTEGER NOT NULL DEFAULT 0');
        }
      },
      onCreate: (d, v) async {
        await d.execute('CREATE TABLE peers('
            'id TEXT PRIMARY KEY, name TEXT NOT NULL, color INTEGER NOT NULL, last_seen INTEGER NOT NULL)');
        await d.execute('CREATE TABLE messages('
            'id TEXT PRIMARY KEY, peer_id TEXT NOT NULL, outgoing INTEGER NOT NULL, type TEXT NOT NULL, '
            'body TEXT NOT NULL, path TEXT, ts INTEGER NOT NULL, status INTEGER NOT NULL, '
            'is_read INTEGER NOT NULL, dur INTEGER NOT NULL DEFAULT 0, deleted INTEGER NOT NULL DEFAULT 0)');
        await d.execute('CREATE INDEX idx_msg_peer ON messages(peer_id, ts)');
        await d.execute('CREATE TABLE statuses('
            'id TEXT PRIMARY KEY, author_id TEXT NOT NULL, kind TEXT NOT NULL, path TEXT, text TEXT NOT NULL, '
            'color INTEGER NOT NULL, ts INTEGER NOT NULL, viewed INTEGER NOT NULL, reported INTEGER NOT NULL)');
        await d.execute('CREATE TABLE status_views('
            'status_id TEXT NOT NULL, peer_id TEXT NOT NULL, ts INTEGER NOT NULL, PRIMARY KEY(status_id, peer_id))');
        await d.execute('CREATE TABLE status_sent('
            'status_id TEXT NOT NULL, peer_id TEXT NOT NULL, PRIMARY KEY(status_id, peer_id))');
      },
    );
  }

  // ---- peers
  Future<List<Peer>> peers() async => (await _db.query('peers')).map(Peer.fromMap).toList();
  Future<void> upsertPeer(Peer x) =>
      _db.insert('peers', x.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);

  // ---- messages
  Future<List<Message>> messages() async =>
      (await _db.query('messages', orderBy: 'ts ASC')).map(Message.fromMap).toList();
  Future<void> insertMessage(Message m) =>
      _db.insert('messages', m.toMap(), conflictAlgorithm: ConflictAlgorithm.ignore);
  Future<void> setStatus(String id, MsgStatus s) =>
      _db.update('messages', {'status': s.index}, where: 'id = ?', whereArgs: [id]);
  /// deleted for everyone by the sender. wipe = also erase the content (free users).
  Future<void> markDeleted(String id, {required bool wipe}) => _db.update(
      'messages', wipe ? {'deleted': 1, 'body': '', 'path': null} : {'deleted': 1},
      where: 'id = ?', whereArgs: [id]);
  /// deleted for me: keep only the id so a late re-delivery is ignored.
  Future<void> hideMessage(String id) => _db.update(
      'messages', {'deleted': 2, 'body': '', 'path': null}, where: 'id = ?', whereArgs: [id]);
  Future<void> markRead(String peerId) => _db.update('messages', {'is_read': 1},
      where: 'peer_id = ? AND outgoing = 0', whereArgs: [peerId]);

  // ---- statuses
  Future<List<StatusItem>> statuses() async =>
      (await _db.query('statuses', orderBy: 'ts ASC')).map(StatusItem.fromMap).toList();
  Future<void> insertStatus(StatusItem s) =>
      _db.insert('statuses', s.toMap(), conflictAlgorithm: ConflictAlgorithm.ignore);
  Future<void> setViewed(String id) =>
      _db.update('statuses', {'viewed': 1}, where: 'id = ?', whereArgs: [id]);
  Future<void> setReported(String id) =>
      _db.update('statuses', {'reported': 1}, where: 'id = ?', whereArgs: [id]);
  Future<void> deleteStatus(String id) async {
    await _db.delete('statuses', where: 'id = ?', whereArgs: [id]);
    await _db.delete('status_views', where: 'status_id = ?', whereArgs: [id]);
    await _db.delete('status_sent', where: 'status_id = ?', whereArgs: [id]);
  }
  Future<List<Map<String, Object?>>> views() => _db.query('status_views');
  Future<List<Map<String, Object?>>> sent() => _db.query('status_sent');
  Future<void> addView(String sid, String pid, int ts) => _db.insert(
      'status_views', {'status_id': sid, 'peer_id': pid, 'ts': ts},
      conflictAlgorithm: ConflictAlgorithm.ignore);
  Future<void> addSent(String sid, String pid) => _db.insert(
      'status_sent', {'status_id': sid, 'peer_id': pid},
      conflictAlgorithm: ConflictAlgorithm.ignore);

  Future<void> clearAll() async {
    for (final t in ['messages', 'peers', 'statuses', 'status_views', 'status_sent']) {
      await _db.delete(t);
    }
  }
}
