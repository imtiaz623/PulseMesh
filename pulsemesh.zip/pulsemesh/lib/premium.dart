import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:shared_preferences/shared_preferences.dart';

// =====================================================================
//  EDIT THESE LINES
// =====================================================================
/// Subscription product id: create it in Play Console → Monetize → Subscriptions
/// (monthly base plan, price Rs 200) with exactly this id.
const kPremiumProductId = 'offchat_premium_monthly';
const kPriceText = 'Rs 200 / month'; // shown until Google Play returns the real price

/// Optional: HTTPS link to announcements.json in your GitHub repo, e.g.
/// https://raw.githubusercontent.com/USER/REPO/main/announcements.json
const kAnnounceUrl = '';
const kAppVersion = '1.0.0';

/// Virtual author id of the official "OffChat" status (exactly 8 chars).
const kOfficialId = 'pulsemsh';
// =====================================================================

enum Feature { screenshotAlerts, screenshotBlock, deleteForEveryone, seeDeleted }

/// Premium = an active Google Play subscription. Google Play does the billing, the renewal,
/// the receipts and the payout; the app only asks Play "does this account have the subscription?".
///
/// Because OffChat is used offline, a confirmation stays valid for [graceDays] (one billing
/// month plus a few days). Every time the phone is online the app asks Play again, and drops
/// Premium if the subscription is gone.
class Premium extends ChangeNotifier {
  static const graceDays = 35;

  final InAppPurchase _iap = InAppPurchase.instance;
  late SharedPreferences _prefs;
  StreamSubscription<List<PurchaseDetails>>? _sub;

  ProductDetails? product;
  bool storeReady = false;
  bool busy = false;
  String? message;
  bool secureOn = false; // "block screenshots" switch

  int _confirmed = 0; // last time Google Play confirmed an active subscription
  int _maxSeen = 0;
  bool _gotActive = false, _sawError = false;

  Future<void> init(SharedPreferences p) async {
    _prefs = p;
    _confirmed = p.getInt('pm_conf') ?? 0;
    _maxSeen = p.getInt('pm_seen') ?? 0;
    secureOn = p.getBool('pm_secure') ?? false;
    tick();
    _sub = _iap.purchaseStream.listen(_onPurchases, onError: (_) {});
    _setup(); // in the background: never delay the app start
  }

  Future<void> _setup() async {
    try {
      storeReady = await _iap.isAvailable();
      if (!storeReady) return;
      final r = await _iap.queryProductDetails({kPremiumProductId});
      if (r.productDetails.isNotEmpty) product = r.productDetails.first;
      notifyListeners();
      await refresh();
    } catch (_) {}
  }

  /// Remember the latest time we saw, so turning the phone clock back cannot stretch the grace period.
  void tick() {
    final n = DateTime.now().millisecondsSinceEpoch;
    if (n > _maxSeen) {
      _maxSeen = n;
      _prefs.setInt('pm_seen', n);
    }
  }

  int get _now {
    final n = DateTime.now().millisecondsSinceEpoch;
    return n > _maxSeen ? n : _maxSeen;
  }

  bool get active => _confirmed > 0 && _now - _confirmed < graceDays * 86400000;

  /// One plan today; the switch keeps room for tiers later.
  bool has(Feature f) => active;

  String get priceText => product?.price == null ? kPriceText : '${product!.price} / month';

  Future<void> _onPurchases(List<PurchaseDetails> list) async {
    for (final d in list) {
      if (d.productID == kPremiumProductId) {
        switch (d.status) {
          case PurchaseStatus.pending:
            busy = true;
            message = 'Waiting for the payment to finish…';
          case PurchaseStatus.purchased:
          case PurchaseStatus.restored:
            _gotActive = true;
            _confirmed = DateTime.now().millisecondsSinceEpoch;
            await _prefs.setInt('pm_conf', _confirmed);
            busy = false;
            message = null;
          case PurchaseStatus.error:
            _sawError = true;
            busy = false;
            message = d.error?.message ?? 'The purchase could not be completed.';
          case PurchaseStatus.canceled:
            busy = false;
            message = null;
        }
      }
      if (d.pendingCompletePurchase) {
        try {
          await _iap.completePurchase(d); // acknowledges the purchase so Google does not refund it
        } catch (_) {}
      }
    }
    notifyListeners();
  }

  /// Asks Google Play whether this account still has the subscription.
  Future<void> refresh() async {
    if (!storeReady) return;
    _gotActive = false;
    _sawError = false;
    try {
      await _iap.restorePurchases();
    } catch (_) {
      return;
    }
    await Future<void>.delayed(const Duration(seconds: 8));
    if (!_gotActive && !_sawError && _confirmed != 0) {
      _confirmed = 0; // Play answered and there is no active subscription any more
      await _prefs.setInt('pm_conf', 0);
      notifyListeners();
    }
  }

  Future<void> buy() async {
    if (product == null) {
      message = 'Google Play is not reachable. Check your internet and try again.';
      notifyListeners();
      await _setup();
      return;
    }
    busy = true;
    message = null;
    notifyListeners();
    try {
      final started = await _iap.buyNonConsumable(purchaseParam: PurchaseParam(productDetails: product!));
      if (!started) {
        busy = false;
        message = 'Could not open Google Play.';
      }
    } catch (e) {
      busy = false;
      message = 'Could not open Google Play.';
    }
    notifyListeners();
  }

  Future<void> restore() async {
    busy = true;
    message = null;
    notifyListeners();
    await refresh();
    busy = false;
    if (!active) message = 'No active subscription was found on this Google account.';
    notifyListeners();
  }

  Future<void> setSecure(bool v) async {
    secureOn = v;
    await _prefs.setBool('pm_secure', v);
    notifyListeners();
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }
}
