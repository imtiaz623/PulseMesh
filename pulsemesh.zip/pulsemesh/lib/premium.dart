import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:shared_preferences/shared_preferences.dart';

// =====================================================================
//  EDIT THESE LINES
// =====================================================================
/// Create these three in Play Console with EXACTLY these ids:
///  * Monetize → Subscriptions:      offchat_premium_monthly (Rs 200, every month)
///  * Monetize → Subscriptions:      offchat_premium_yearly  (Rs 1,500, every year)
///  * Monetize → In-app products:    offchat_premium_lifetime (one-time, your price)
const kMonthlyId = 'offchat_premium_monthly';
const kYearlyId = 'offchat_premium_yearly';
const kLifetimeId = 'offchat_premium_lifetime';
const kProductIds = {kMonthlyId, kYearlyId, kLifetimeId};

/// Shown only until Google Play returns the real localized prices.
const kFallbackPrice = {kMonthlyId: 'Rs 200', kYearlyId: 'Rs 1,500', kLifetimeId: 'Rs 3,999'};

/// Optional: HTTPS link to announcements.json in your GitHub repo, e.g.
/// https://raw.githubusercontent.com/USER/REPO/main/announcements.json
const kAnnounceUrl = '';
const kAppVersion = '1.0.0';

/// Virtual author id of the official "OffChat" status (exactly 8 chars).
const kOfficialId = 'pulsemsh';
// =====================================================================

enum Feature { screenshotAlerts, screenshotBlock, deleteForEveryone, seeDeleted }

/// Premium = an active Google Play subscription. Google Play does the billing, the renewal,
/// the receipts and the payout; the app only asks Play "does this account have the subscription?".
///
/// Because OffChat is used offline, a confirmation stays valid for [graceDays] (one billing
/// month plus a few days). Every time the phone is online the app asks Play again, and drops
/// Premium if the subscription is gone.
class Premium extends ChangeNotifier {
  final InAppPurchase _iap = InAppPurchase.instance;
  late SharedPreferences _prefs;
  StreamSubscription<List<PurchaseDetails>>? _sub;

  final Map<String, ProductDetails> products = {};
  bool storeReady = false;
  bool busy = false;
  String? message;
  bool secureOn = false; // "block screenshots" switch

  int _confirmed = 0; // last time Google Play confirmed an active subscription
  String _plan = ''; // which subscription that was
  bool _life = false; // lifetime pass
  int _maxSeen = 0;
  bool _gotActive = false, _sawError = false;

  Future<void> init(SharedPreferences p) async {
    _prefs = p;
    _confirmed = p.getInt('pm_conf') ?? 0;
    _plan = p.getString('pm_plan') ?? kMonthlyId;
    _life = p.getBool('pm_life') ?? false;
    _maxSeen = p.getInt('pm_seen') ?? 0;
    secureOn = p.getBool('pm_secure') ?? false;
    tick();
    _sub = _iap.purchaseStream.listen(_onPurchases, onError: (_) {});
    _setup(); // in the background: never delay the app start
  }

  Future<void> _setup() async {
    try {
      storeReady = await _iap.isAvailable();
      if (!storeReady) return;
      final r = await _iap.queryProductDetails(kProductIds);
      for (final d in r.productDetails) {
        products.putIfAbsent(d.id, () => d);
      }
      notifyListeners();
      await refresh();
    } catch (_) {}
  }

  /// Remember the latest time we saw, so turning the phone clock back cannot stretch the grace period.
  void tick() {
    final n = DateTime.now().millisecondsSinceEpoch;
    if (n > _maxSeen) {
      _maxSeen = n;
      _prefs.setInt('pm_seen', n);
    }
  }

  int get _now {
    final n = DateTime.now().millisecondsSinceEpoch;
    return n > _maxSeen ? n : _maxSeen;
  }

  /// OffChat is used offline, so a confirmation from Google Play stays valid for one billing
  /// period plus a few days. Whenever the phone is online the app asks Play again.
  bool get active {
    if (_life) return true;
    if (_confirmed <= 0) return false;
    final grace = _plan == kYearlyId ? 375 : 35;
    return _now - _confirmed < grace * 86400000;
  }

  bool get isLifetime => _life;
  String get planLabel => _life ? 'Lifetime pass' : _plan == kYearlyId ? 'Yearly plan' : 'Monthly plan';

  /// One plan today; the switch keeps room for tiers later.
  bool has(Feature f) => active;

  String price(String id) => products[id]?.price ?? kFallbackPrice[id] ?? '';

  Future<void> _onPurchases(List<PurchaseDetails> list) async {
    for (final d in list) {
      if (kProductIds.contains(d.productID)) {
        switch (d.status) {
          case PurchaseStatus.pending:
            busy = true;
            message = 'Waiting for the payment to finish…';
          case PurchaseStatus.purchased:
          case PurchaseStatus.restored:
            _gotActive = true;
            if (d.productID == kLifetimeId) {
              _life = true;
              await _prefs.setBool('pm_life', true);
            } else {
              _confirmed = DateTime.now().millisecondsSinceEpoch;
              _plan = d.productID;
              await _prefs.setInt('pm_conf', _confirmed);
              await _prefs.setString('pm_plan', _plan);
            }
            busy = false;
            message = null;
          case PurchaseStatus.error:
            _sawError = true;
            busy = false;
            message = d.error?.message ?? 'The purchase could not be completed.';
          case PurchaseStatus.canceled:
            busy = false;
            message = null;
        }
      }
      if (d.pendingCompletePurchase) {
        try {
          await _iap.completePurchase(d); // acknowledges the purchase so Google does not refund it
        } catch (_) {}
      }
    }
    notifyListeners();
  }

  /// Asks Google Play whether this account still owns Premium.
  Future<void> refresh() async {
    if (!storeReady) return;
    _gotActive = false;
    _sawError = false;
    try {
      await _iap.restorePurchases();
    } catch (_) {
      return;
    }
    await Future<void>.delayed(const Duration(seconds: 8));
    if (!_gotActive && !_sawError && (_confirmed != 0 || _life)) {
      _confirmed = 0; // Play answered and nothing is active any more (cancelled / refunded)
      _life = false;
      await _prefs.setInt('pm_conf', 0);
      await _prefs.setBool('pm_life', false);
      notifyListeners();
    }
  }

  Future<void> buy(String id) async {
    final pd = products[id];
    if (pd == null) {
      message = 'Google Play is not reachable. Check your internet and try again.';
      notifyListeners();
      await _setup();
      return;
    }
    busy = true;
    message = null;
    notifyListeners();
    try {
      final started = await _iap.buyNonConsumable(purchaseParam: PurchaseParam(productDetails: pd));
      if (!started) {
        busy = false;
        message = 'Could not open Google Play.';
      }
    } catch (e) {
      busy = false;
      message = 'Could not open Google Play.';
    }
    notifyListeners();
  }

  Future<void> restore() async {
    busy = true;
    message = null;
    notifyListeners();
    await refresh();
    busy = false;
    if (!active) message = 'No active purchase was found on this Google account.';
    notifyListeners();
  }

  Future<void> setSecure(bool v) async {
    secureOn = v;
    await _prefs.setBool('pm_secure', v);
    notifyListeners();
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }
}
