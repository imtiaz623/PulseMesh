import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:nearby_connections/nearby_connections.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

import 'call_service.dart';
import 'db.dart';
import 'models.dart';

class _Found {
  _Found(this.endpointId, this.peerId) : since = DateTime.now();
  final String endpointId, peerId;
  final DateTime since;
}

/// Core engine: permissions, Bluetooth, foreground service, Nearby Connections
/// (P2P_CLUSTER), presence, offline queue, acks, media, voice and statuses.
///
/// Wire format: JSON object per Nearby BYTES payload (<= 32 KB). Media travels as
/// FILE payloads, byte-for-byte (no re-compression), plus a small JSON "meta" frame.
///   {t:'m', id, ts, x}                          text message
///   {t:'f', k:'image'|'voice', id, ts, pid, n, x, d}   file message meta (pid = file payload id)
///   {t:'a', id}                                 message ack
///   {t:'s', k:'text'|'image', id, ts, x, c, pid, n}    status update
///   {t:'sa', id}                                status received ack
///   {t:'sv', id}                                status viewed receipt
///   {t:'p', ts} / {t:'o', ts}                   ping / pong (link latency)
///   {t:'n', x, c}                               profile update
class MeshService extends ChangeNotifier {
  static const _native = MethodChannel('pulsemesh/native');
  static const serviceId = 'com.pulsemesh.mesh';
  static const _uuid = Uuid();

  final Db db = Db();
  late final CallService calls = CallService(this);
  final Nearby _nearby = Nearby();
  late SharedPreferences _prefs;
  late String _mediaDir;

  // ---- identity & settings
  late String myId;
  String myName = '';
  int myColor = 0;
  bool autoBluetooth = true;

  // ---- engine state
  bool wantRunning = true, running = false, _starting = false, _btDropped = false;
  String? error;
  String? openPeerId;
  bool advOk = false, discOk = false;
  int foundTotal = 0, _tickN = 0, _floodN = 0;
  String lastBadName = '', lastConnErr = '';
  Timer? _timer;
  String _lastServiceText = '';

  // ---- data
  final Map<String, Peer> peers = {};
  final Map<String, List<Message>> _threads = {};
  final Set<String> _ids = {};
  final Map<String, List<StatusItem>> _statuses = {}; // authorId -> items
  final Set<String> _statusIds = {};
  final Map<String, Map<String, int>> _views = {}; // statusId -> {peerId: ts}
  final Set<String> _sentSet = {}; // "statusId|peerId" already delivered
  final Map<String, double> progress = {}; // outgoing file progress by message/status id

  // ---- transport bookkeeping
  final Map<String, String> _epToPeer = {};
  final Map<String, _Found> _found = {};
  final Set<String> _pending = {};
  final Set<String> _flushing = {};
  final Set<String> _pushing = {};
  final Map<int, String> _filePaths = {};
  final Set<int> _fileDone = {};
  final Map<int, Map<String, dynamic>> _pendingMeta = {};
  final Map<int, String> _outPid = {};
  final Map<String, int> _handshake = {}; // endpointId -> start ms (to time out stuck handshakes)
  final Map<String, int> _tryTs = {};
  final Set<String> _relaySeen = {};
  final List<String> _relayOrder = [];

  // ======================================================== speed: coalesce UI rebuilds
  Timer? _notifyGate;
  bool _notifyDirty = false;

  /// First call rebuilds at once; calls within the next 90 ms are merged into ONE rebuild.
  /// The engine used to trigger dozens of full-screen rebuilds per second.
  @override
  void notifyListeners() {
    if (_notifyGate != null) {
      _notifyDirty = true;
      return;
    }
    super.notifyListeners();
    _notifyGate = Timer(const Duration(milliseconds: 90), () {
      _notifyGate = null;
      if (_notifyDirty) {
        _notifyDirty = false;
        notifyListeners();
      }
    });
  }

  // ======================================================== lifecycle
  Future<void> init([void Function(String)? step]) async {
    step?.call('Loading settings');
    _prefs = await SharedPreferences.getInstance();
    myId = _prefs.getString('id') ?? _uuid.v4().substring(0, 8);
    await _prefs.setString('id', myId);
    myName = _prefs.getString('name') ?? 'Node-${myId.substring(0, 4)}';
    myColor = _prefs.getInt('color') ?? (myId.codeUnitAt(0) % 8);
    autoBluetooth = _prefs.getBool('auto_bt') ?? true;
    wantRunning = _prefs.getBool('mesh_on') ?? true;

    step?.call('Preparing storage');
    final docs = await getApplicationDocumentsDirectory();
    _mediaDir = p.join(docs.path, 'media');
    await Directory(_mediaDir).create(recursive: true);

    step?.call('Opening database');
    await db.open();
    step?.call('Loading chats');
    for (final pr in await db.peers()) {
      peers[pr.id] = pr;
    }
    for (final m in await db.messages()) {
      (_threads[m.peerId] ??= []).add(m);
      _ids.add(m.id);
    }
    for (final s in await db.statuses()) {
      (_statuses[s.authorId] ??= []).add(s);
      _statusIds.add(s.id);
    }
    for (final r in await db.views()) {
      (_views[r['status_id'] as String] ??= {})[r['peer_id'] as String] = r['ts'] as int;
    }
    for (final r in await db.sent()) {
      _sentSet.add('${r['status_id']}|${r['peer_id']}');
    }
    await _purgeStatuses();
  }

  Future<void> start() async {
    wantRunning = true;
    await _prefs.setBool('mesh_on', true);
    if (running || _starting) return;
    _starting = true;
    error = null;
    notifyListeners();
    try {
      if (!await _ensurePermissions()) {
        error = 'OffChat needs Bluetooth, Nearby devices and notification permissions.';
        return;
      }
      if (!await _ensureBluetooth()) return;
      if (!(await Permission.locationWhenInUse.serviceStatus).isEnabled) {
        error = 'Turn ON Location (GPS) in phone settings. Bluetooth discovery needs it.';
      }
      await Future.wait([
        _native.invokeMethod('startService', {'text': _serviceText()}),
        _startNearby(),
      ]);
      running = true;
      _btDropped = false;
      _timer ??= Timer.periodic(const Duration(seconds: 2), (_) => _maintenance());
    } catch (e) {
      error = 'Could not start the mesh: $e';
    } finally {
      _starting = false;
      notifyListeners();
    }
  }

  Future<void> stop() async {
    wantRunning = false;
    await _prefs.setBool('mesh_on', false);
    await _stopNearby();
    running = false;
    _lastServiceText = '';
    await _safe(() => _native.invokeMethod('stopService'));
    notifyListeners();
  }

  Future<void> onResume() async {
    if (!wantRunning) return;
    if (!running) {
      await start();
    } else if (!(await _btOn())) {
      await _maintenance();
    }
  }

  Future<bool> _ensurePermissions() async {
    final sdk = await _native.invokeMethod<int>('sdkInt') ?? 0;
    final req = <Permission>[
      Permission.bluetoothScan,
      Permission.bluetoothAdvertise,
      Permission.bluetoothConnect,
      Permission.notification,
      Permission.locationWhenInUse, // Nearby needs location on every Android version
      if (sdk >= 33) Permission.nearbyWifiDevices,
    ];
    final res = await req.request();
    return res.entries
        .where((e) => e.key != Permission.notification)
        .every((e) => e.value.isGranted || e.value.isLimited);
  }

  Future<bool> _btOn() async => await _native.invokeMethod<bool>('isBluetoothOn') ?? false;

  Future<bool> _ensureBluetooth() async {
    if (await _btOn()) return true;
    if (!autoBluetooth) {
      error = 'Bluetooth is off. Turn it on, or enable Auto-Bluetooth in Settings.';
      return false;
    }
    final ok = await _native.invokeMethod<bool>('requestEnableBluetooth') ?? false;
    if (!ok) error = 'Bluetooth must be on for OffChat to find nearby peers.';
    return ok;
  }

  Future<void> _maintenance() async {
    _tickN++;
    final now = DateTime.now();
    final nowMs = now.millisecondsSinceEpoch;
    final slow = _tickN % 5 == 0; // ~10 s
    if (slow) await _purgeStatuses();
    final bt = (slow || !running) ? await _btOn() : true;
    if (running && !bt) {
      await _stopNearby();
      running = false;
      _btDropped = true;
      error = 'Bluetooth turned off. OffChat resumes when it is back on.';
      notifyListeners();
      return;
    }
    if (!running && _btDropped && wantRunning && bt && !_starting) {
      await start();
      return;
    }
    if (!running) return;

    // handshakes that hang forever: drop them so the next try can start fresh
    for (final e in _handshake.entries.toList()) {
      if (nowMs - e.value > 12000) {
        _handshake.remove(e.key);
        _pending.remove(e.key);
        final pid = _epToPeer[e.key];
        final pr = pid == null ? null : peers[pid];
        if (pr != null && pr.endpointId != e.key) {
          pr.connecting = false;
          _epToPeer.remove(e.key);
        }
        _safe(() => _nearby.disconnectFromEndpoint(e.key));
        notifyListeners();
      }
    }

    if (_tickN % 15 == 0 && onlineCount == 0 && _found.isEmpty) await _restartDiscovery();

    for (final f in _found.values.toList()) {
      final pr = peers[f.peerId];
      if (pr == null || pr.online || _pending.contains(f.endpointId)) continue;
      // lower id dials at once; the other side waits only 4 s, then dials too
      if (myId.compareTo(f.peerId) < 0 || now.difference(f.since).inSeconds >= 4) _request(f);
    }
    if (_tickN % 4 == 0) {
      for (final pr in _neighbours) {
        _safe(() => _send(pr.endpointId!, {'t': 'p', 'ts': nowMs}));
      }
    }
    if (slow) {
      _gossip();
      _pushAll();
      _retryQueued();
      _reflood();
      final e = error;
      if (e != null && e.startsWith('Turn ON Location') &&
          (await Permission.locationWhenInUse.serviceStatus).isEnabled) {
        error = null;
        notifyListeners();
      }
    }
    _updateService();
  }

  // ======================================================== Nearby: advertise + discover
  String get _nick => '${myName.replaceAll('|', '')}|$myId|$myColor';

  ({String name, String id, int color})? _parse(String s) {
    final a = s.split('|');
    if (a.length != 3 || a[1].length != 8) return null;
    return (name: a[0].isEmpty ? 'Unknown' : a[0], id: a[1], color: int.tryParse(a[2]) ?? 0);
  }

  Future<void> _startNearby() async {
    advOk = discOk = false;
    try {
      await _nearby.startAdvertising(_nick, Strategy.P2P_CLUSTER,
          onConnectionInitiated: _onInit, onConnectionResult: _onResult,
          onDisconnected: _onDisc, serviceId: serviceId);
      advOk = true;
    } on PlatformException catch (e) {
      if (!'${e.code} ${e.message}'.contains('ALREADY')) rethrow;
      advOk = true;
    }
    await _startDiscovery();
  }

  Future<void> _startDiscovery() async {
    try {
      await _nearby.startDiscovery(_nick, Strategy.P2P_CLUSTER,
          onEndpointFound: _onFound, onEndpointLost: _onLost, serviceId: serviceId);
      discOk = true;
    } on PlatformException catch (e) {
      if (!'${e.code} ${e.message}'.contains('ALREADY')) rethrow;
      discOk = true;
    }
  }

  /// Some phones silently stop discovering after a while: restart it.
  Future<void> _restartDiscovery() async {
    await _safe(() => _nearby.stopDiscovery());
    try {
      await _startDiscovery();
    } catch (e) {
      error = 'Discovery restart failed: $e';
    }
    notifyListeners();
  }

  Future<void> _stopNearby() async {
    await _safe(() => _nearby.stopAdvertising());
    await _safe(() => _nearby.stopDiscovery());
    await _safe(() => _nearby.stopAllEndpoints());
    for (final pr in peers.values) {
      pr.online = pr.connecting = pr.discovered = false;
      pr.hops = 0;
      pr.endpointId = null;
      pr.rtt = null;
    }
    _epToPeer.clear();
    _found.clear();
    _pending.clear();
  }

  Peer _upsert(({String name, String id, int color}) i) {
    var pr = peers[i.id];
    if (pr == null) {
      pr = Peer(id: i.id, name: i.name, color: i.color);
      peers[i.id] = pr;
    } else {
      pr.name = i.name;
      pr.color = i.color;
    }
    _safe(() => db.upsertPeer(pr!));
    return pr;
  }

  void _onFound(String id, String name, String svc) {
    foundTotal++;
    final info = _parse(name);
    if (info == null) {
      lastBadName = name;
      notifyListeners();
      return;
    }
    if (info.id == myId) return;
    final pr = _upsert(info)..discovered = true;
    final f = _Found(id, info.id);
    _found[id] = f;
    notifyListeners();
    if (!pr.online && myId.compareTo(info.id) < 0) _request(f);
  }

  void _onLost(String? id) {
    final f = _found.remove(id);
    final pr = f == null ? null : peers[f.peerId];
    if (pr != null && !pr.online) pr.discovered = false;
    notifyListeners();
  }

  void connectTo(String peerId) {
    for (final f in _found.values) {
      if (f.peerId == peerId) _request(f, force: true);
    }
  }

  Future<void> _request(_Found f, {bool force = false}) async {
    final pr = peers[f.peerId];
    if (pr == null || pr.online || _pending.contains(f.endpointId)) return;
    final nowMs = DateTime.now().millisecondsSinceEpoch;
    if (!force && nowMs - (_tryTs[f.endpointId] ?? 0) < 2500) return;
    _tryTs[f.endpointId] = nowMs;
    _pending.add(f.endpointId);
    _handshake[f.endpointId] = nowMs;
    pr.connecting = true;
    notifyListeners();
    try {
      await _nearby.requestConnection(_nick, f.endpointId,
          onConnectionInitiated: _onInit, onConnectionResult: _onResult, onDisconnected: _onDisc);
    } catch (e) {
      _pending.remove(f.endpointId);
      _handshake.remove(f.endpointId);
      pr.connecting = false;
      lastConnErr = 'request: $e';
      notifyListeners();
    }
  }

  void _onInit(String id, ConnectionInfo info) {
    final pi = _parse(info.endpointName);
    if (pi == null || pi.id == myId) {
      _safe(() => _nearby.rejectConnection(id));
      return;
    }
    _epToPeer[id] = pi.id;
    _handshake[id] = DateTime.now().millisecondsSinceEpoch;
    _upsert(pi).connecting = true;
    notifyListeners();
    _safe(() => _nearby.acceptConnection(id,
        onPayLoadRecieved: (eid, payload) => _onPayload(eid, payload),
        onPayloadTransferUpdate: (eid, u) => _onTransfer(eid, u)));
  }

  void _onResult(String id, Status s) {
    _pending.remove(id);
    _handshake.remove(id);
    if (s != Status.CONNECTED) lastConnErr = 'result $s';
    final pr = peers[_epToPeer[id]];
    if (pr == null) return;
    pr.connecting = false;
    if (s == Status.CONNECTED) {
      if (pr.online && pr.endpointId != id) {
        _safe(() => _nearby.disconnectFromEndpoint(id));
        _epToPeer.remove(id);
        return;
      }
      pr
        ..online = true
        ..hops = 0
        ..endpointId = id
        ..lastSeen = DateTime.now().millisecondsSinceEpoch;
      _safe(() => db.upsertPeer(pr));
      _safe(() => _send(id, {'t': 'p', 'ts': DateTime.now().millisecondsSinceEpoch}));
      _flush(pr.id, resend: true);          // offline queue
      _pushStatuses(pr.id);                 // my statuses this peer has not received
      _gossip();                            // tell neighbours who is reachable through me
      for (final s in statusesOf(pr.id)) {  // tell them which of theirs I already viewed
        if (s.viewed && !s.reported) _reportView(s);
      }
    } else {
      _epToPeer.remove(id);
    }
    notifyListeners();
    _updateService();
  }

  void _onDisc(String id) {
    _pending.remove(id);
    _handshake.remove(id);
    final pid = _epToPeer.remove(id);
    final pr = pid == null ? null : peers[pid];
    if (pr != null && pr.endpointId == id) {
      pr
        ..online = false
        ..connecting = false
        ..endpointId = null
        ..rtt = null;
    }
    notifyListeners();
    _updateService();
  }

  // ======================================================== receive
  void _onPayload(String eid, Payload payload) {
    if (payload.type == PayloadType.BYTES && payload.bytes != null) {
      final peerId = _epToPeer[eid];
      if (peerId == null) return;
      final raw = payload.bytes!;
      if (raw.isNotEmpty && raw[0] < 32) {
        calls.onRaw(peerId, raw); // realtime call frame (audio/video), not JSON
        return;
      }
      try {
        _handle(eid, peerId, jsonDecode(utf8.decode(payload.bytes!)) as Map<String, dynamic>);
      } catch (_) {}
    } else if (payload.type == PayloadType.FILE) {
      // Android 10+ delivers received files as a content:// uri and leaves filePath empty.
      String? loc = payload.filePath;
      if (loc == null || loc.isEmpty) {
        try {
          loc = (payload as dynamic).uri as String?;
        } catch (_) {}
      }
      if (loc != null && loc.isNotEmpty) _filePaths[payload.id] = loc;
    }
  }

  void _onTransfer(String eid, PayloadTransferUpdate u) {
    final mine = _outPid[u.id]; // outgoing file: drive the progress ring
    if (mine != null) {
      if (u.status == PayloadStatus.IN_PROGRESS) {
        if (u.totalBytes > 0) {
          final f = u.bytesTransferred / u.totalBytes;
          if (f - (progress[mine] ?? 0) >= .03) {
            progress[mine] = f;
            notifyListeners();
          }
        }
      } else {
        progress.remove(mine);
        _outPid.remove(u.id);
        notifyListeners();
      }
    }
    if (u.status == PayloadStatus.SUCCESS && _filePaths.containsKey(u.id)) {
      _fileDone.add(u.id);
      _tryFinishFile(u.id);
    }
  }

  Future<void> _handle(String eid, String peerId, Map<String, dynamic> j) async {
    final pr = peers[peerId];
    switch (j['t']) {
      case 'm':
        final id = j['id'] as String;
        if (!_ids.contains(id)) {
          var text = (j['x'] as String? ?? '');
          if (text.length > 4000) text = text.substring(0, 4000);
          await _add(Message(
              id: id, peerId: peerId, outgoing: false, type: 'text', body: text,
              ts: DateTime.now().millisecondsSinceEpoch,
              status: MsgStatus.delivered, read: openPeerId == peerId));
        }
        _safe(() => _send(eid, {'t': 'a', 'id': id}));
      case 'f':
        final fpid = j['pid'] as int;
        _pendingMeta[fpid] = {...j, '_peer': peerId, '_eid': eid};
        _tryFinishFile(fpid);
      case 'a':
        for (final m in thread(peerId)) {
          if (m.id == j['id'] && m.outgoing && m.status != MsgStatus.delivered) {
            m.status = MsgStatus.delivered;
            _safe(() => db.setStatus(m.id, MsgStatus.delivered));
          }
        }
        notifyListeners();
      case 's':
        if (j['k'] == 'text') {
          await _receiveStatus(peerId, eid, j, null);
        } else {
          final spid = j['pid'] as int;
          _pendingMeta[spid] = {...j, '_peer': peerId, '_eid': eid};
          _tryFinishFile(spid);
        }
      case 'sa':
        final key = '${j['id']}|$peerId';
        if (_sentSet.add(key)) _safe(() => db.addSent(j['id'] as String, peerId));
      case 'sv':
        final sid = j['id'] as String;
        final mineStatus = statusesOf(myId).any((s) => s.id == sid);
        if (mineStatus) {
          final ts = DateTime.now().millisecondsSinceEpoch;
          (_views[sid] ??= {})[peerId] = ts;
          _safe(() => db.addView(sid, peerId, ts));
          notifyListeners();
        }
      case 'c':
        calls.onSignal(peerId, j);
      case 'r':
      case 'ra':
        await _onRelay(eid, j);
      case 'g':
        _onGossip(peerId, j);
      case 'p':
        _safe(() => _send(eid, {'t': 'o', 'ts': j['ts']}));
      case 'o':
        if (pr != null) {
          pr.rtt = DateTime.now().millisecondsSinceEpoch - (j['ts'] as int);
          notifyListeners();
        }
      case 'n':
        if (pr != null) {
          final n = (j['x'] as String? ?? '').trim();
          if (n.isNotEmpty) pr.name = n.length > 24 ? n.substring(0, 24) : n;
          pr.color = (j['c'] as int?) ?? pr.color;
          _safe(() => db.upsertPeer(pr));
          notifyListeners();
        }
    }
  }

  String _clean(String s) => s.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');

  /// Finalises an incoming file once BOTH its meta frame and the file itself arrived.
  Future<void> _tryFinishFile(int pid) async {
    final meta = _pendingMeta[pid], src = _filePaths[pid];
    if (meta == null || src == null || !_fileDone.contains(pid)) return;
    _pendingMeta.remove(pid);
    _filePaths.remove(pid);
    _fileDone.remove(pid);
    final peerId = meta['_peer'] as String, eid = meta['_eid'] as String;
    final id = meta['id'] as String;
    final isStatus = meta['t'] == 's';
    final known = isStatus ? _statusIds.contains(id) : _ids.contains(id);

    String? dest;
    if (!known) {
      // never trust a remote file name: sanitise before touching the filesystem
      dest = p.join(_mediaDir,
          '${isStatus ? 's' : 'm'}_${_clean(id)}_${_clean(p.basename(meta['n'] as String))}');
      try {
        if (src.startsWith('content:') || src.startsWith('file:')) {
          await _native.invokeMethod('copyUri', {'uri': src, 'dest': dest});
        } else {
          await File(src).copy(dest);
          await _safe(() => File(src).delete());
        }
      } catch (_) {
        return; // unreadable: no ack, so the sender retries (see _retryMedia)
      }
    }
    if (isStatus) {
      await _receiveStatus(peerId, eid, meta, dest);
      return;
    }
    if (!known) {
      var cap = (meta['x'] as String? ?? '');
      if (cap.length > 1000) cap = cap.substring(0, 1000);
      await _add(Message(
          id: id, peerId: peerId, outgoing: false,
          type: meta['k'] == 'voice' ? 'voice' : meta['k'] == 'video' ? 'video' : 'image',
          body: cap, path: dest, dur: (meta['d'] as int?) ?? 0,
          ts: DateTime.now().millisecondsSinceEpoch,
          status: MsgStatus.delivered, read: openPeerId == peerId));
    }
    _safe(() => _send(eid, {'t': 'a', 'id': id}));
  }

  // ======================================================== send + offline queue
  Future<void> _send(String eid, Map<String, dynamic> j) =>
      _nearby.sendBytesPayload(eid, Uint8List.fromList(utf8.encode(jsonEncode(j))));

  Future<void> sendText(String peerId, String text) async {
    final t = text.trim();
    if (t.isEmpty) return;
    await _add(Message(
        id: _uuid.v4(), peerId: peerId, outgoing: true, type: 'text', body: t,
        ts: DateTime.now().millisecondsSinceEpoch));
    _flush(peerId);
    final pr = peers[peerId];
    if (pr != null && !pr.online) connectTo(peerId); // dial now instead of waiting
  }

  /// Sends the ORIGINAL file bytes: no resizing, no re-encoding.
  Future<void> sendImage(String peerId, File src, {String caption = ''}) async {
    final id = _uuid.v4();
    final dest = p.join(_mediaDir, 'm_${id}_${_clean(p.basename(src.path))}');
    await src.copy(dest);
    await _add(Message(
        id: id, peerId: peerId, outgoing: true, type: 'image', body: caption, path: dest,
        ts: DateTime.now().millisecondsSinceEpoch));
    _flush(peerId);
  }

  /// Video is sent as the ORIGINAL file (no re-encoding), as a file payload.
  Future<void> sendVideo(String peerId, File src, {String caption = ''}) async {
    final id = _uuid.v4();
    var ext = p.extension(src.path).toLowerCase();
    if (ext.isEmpty || ext.length > 6) ext = '.mp4';
    final dest = p.join(_mediaDir, 'm_${id}_video$ext');
    await src.copy(dest);
    await _add(Message(
        id: id, peerId: peerId, outgoing: true, type: 'video', body: caption, path: dest,
        ts: DateTime.now().millisecondsSinceEpoch));
    _flush(peerId);
  }

  Future<void> sendVoice(String peerId, String path, int durMs) async {
    final id = _uuid.v4();
    final dest = p.join(_mediaDir, 'v_$id.m4a');
    await File(path).copy(dest);
    await _safe(() => File(path).delete());
    await _add(Message(
        id: id, peerId: peerId, outgoing: true, type: 'voice', body: '', path: dest, dur: durMs,
        ts: DateTime.now().millisecondsSinceEpoch));
    _flush(peerId);
  }

  final Set<String> _flushAgain = {};
  final Map<String, int> _sentAt = {}; // message id -> last send time (ms)

  Future<void> _flush(String peerId, {bool resend = false}) async {
    if (!_flushing.add(peerId)) {
      _flushAgain.add(peerId); // a send was requested mid-flush: run once more afterwards
      return;
    }
    try {
      final nowMs = DateTime.now().millisecondsSinceEpoch;
      for (final m in List<Message>.of(thread(peerId))) {
        if (!m.outgoing || m.status == MsgStatus.delivered) continue;
        final staleMedia = m.status == MsgStatus.sent && m.type != 'text' && m.type != 'call' &&
            !progress.containsKey(m.id) && nowMs - (_sentAt[m.id] ?? 0) > 45000;
        if (m.status == MsgStatus.sent && !resend && !staleMedia) continue;
        if (m.type == 'call') continue;
        final pr = peers[peerId];
        if (pr == null) break;
        final direct = pr.online && pr.endpointId != null;
        final viaMesh = !direct && m.type == 'text' && pr.relayed && _neighbours.isNotEmpty;
        if (!direct && !viaMesh) continue; // media waits for a direct link
        try {
          if (m.type == 'text') {
            if (direct) {
              await _send(pr.endpointId!, {'t': 'm', 'id': m.id, 'ts': m.ts, 'x': m.body});
            } else {
              await _floodRelay({
                't': 'r', 'id': m.id, 'src': myId, 'dst': peerId, 'ttl': 6, 'ts': m.ts,
                'x': m.body, 'sn': myName, 'sc': myColor, 'k': _newK(),
              });
            }
          } else {
            final eid = pr.endpointId!;
            if (m.path == null || !await File(m.path!).exists()) continue;
            final pid = await _nearby.sendFilePayload(eid, m.path!);
            _outPid[pid] = m.id;
            await _send(eid, {
              't': 'f', 'k': m.type, 'id': m.id, 'ts': m.ts, 'pid': pid,
              'n': p.basename(m.path!), 'x': m.body, 'd': m.dur,
            });
          }
          _sentAt[m.id] = nowMs;
          if (m.status == MsgStatus.queued) {
            m.status = MsgStatus.sent;
            await db.setStatus(m.id, MsgStatus.sent);
          }
          notifyListeners();
        } catch (_) {
          break;
        }
      }
    } finally {
      _flushing.remove(peerId);
      if (_flushAgain.remove(peerId)) _flush(peerId);
    }
  }

  /// Every ~10 s: push anything still waiting to peers that are connected right now
  /// (queued items, and media that never got an ack).
  void _retryQueued() {
    for (final pr in _neighbours) {
      final waiting = thread(pr.id).any((m) => m.outgoing && m.status != MsgStatus.delivered && m.type != 'call');
      if (waiting) _flush(pr.id);
    }
  }

  // ======================================================== mesh relay (A - B - C chains)
  List<Peer> get _neighbours =>
      peers.values.where((x) => x.online && x.endpointId != null).toList();

  String _newK() => '$myId-${_floodN++}-${DateTime.now().millisecondsSinceEpoch}';

  bool _seenRelay(String k) {
    if (_relaySeen.contains(k)) return true;
    _relaySeen.add(k);
    _relayOrder.add(k);
    if (_relayOrder.length > 3000) _relaySeen.remove(_relayOrder.removeAt(0));
    return false;
  }

  /// Send straight to the destination if it is a neighbour, else to every neighbour
  /// (except the one it came from). Duplicates are dropped by the unique key "k".
  Future<void> _floodRelay(Map<String, dynamic> f, {String? exceptEid}) async {
    final d = peers[f['dst'] as String];
    if (d != null && d.online && d.endpointId != null) {
      if (d.endpointId != exceptEid) await _send(d.endpointId!, f);
      return;
    }
    for (final n in _neighbours) {
      if (n.endpointId == exceptEid) continue;
      _safe(() => _send(n.endpointId!, f));
    }
  }

  Peer _learn(String id, String? name, int? color) {
    var pr = peers[id];
    if (pr == null) {
      final nm = (name == null || name.trim().isEmpty) ? 'Node-${id.substring(0, 4)}' : name.trim();
      pr = Peer(id: id, name: nm.length > 24 ? nm.substring(0, 24) : nm, color: color ?? 0);
      peers[id] = pr;
      final created = pr;
      _safe(() => db.upsertPeer(created));
    }
    return pr;
  }

  Future<void> _onRelay(String eid, Map<String, dynamic> j) async {
    final k = j['k'] as String? ?? '';
    final src = j['src'] as String? ?? '', dst = j['dst'] as String? ?? '';
    if (k.isEmpty || src.length != 8 || dst.length != 8 || src == myId) return;
    if (_seenRelay(k)) return;
    if (dst == myId) {
      final id = j['id'] as String;
      if (j['t'] == 'r') {
        final pr = _learn(src, j['sn'] as String?, j['sc'] as int?);
        if (!_ids.contains(id)) {
          var text = (j['x'] as String? ?? '');
          if (text.length > 4000) text = text.substring(0, 4000);
          await _add(Message(
              id: id, peerId: pr.id, outgoing: false, type: 'text', body: text,
              ts: DateTime.now().millisecondsSinceEpoch,
              status: MsgStatus.delivered, read: openPeerId == pr.id));
        }
        _safe(() => _floodRelay({'t': 'ra', 'id': id, 'src': myId, 'dst': src, 'ttl': 6, 'k': _newK()}));
      } else {
        for (final m in thread(src)) {
          if (m.id == id && m.outgoing && m.status != MsgStatus.delivered) {
            m.status = MsgStatus.delivered;
            _safe(() => db.setStatus(m.id, MsgStatus.delivered));
          }
        }
        notifyListeners();
      }
      return;
    }
    final ttl = ((j['ttl'] as int?) ?? 0) - 1;
    if (ttl <= 0) return;
    await _floodRelay({...j, 'ttl': ttl}, exceptEid: eid);
  }

  /// Tell every neighbour which other phones I can reach (split horizon: never echo a route back).
  void _gossip() {
    for (final n in _neighbours) {
      final list = <List<Object>>[];
      for (final p in peers.values) {
        if (p.id == n.id) continue;
        if (p.online) {
          list.add([p.id, p.name, p.color, 1]);
        } else if (p.relayed && p.hops < 5 && p.via != n.id) {
          list.add([p.id, p.name, p.color, p.hops]);
        }
      }
      _safe(() => _send(n.endpointId!, {'t': 'g', 'n': list}));
    }
  }

  void _onGossip(String from, Map<String, dynamic> j) {
    final list = j['n'];
    if (list is! List) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    var changed = false;
    for (final e in list) {
      if (e is! List || e.length < 4) continue;
      final id = e[0], name = e[1], color = e[2], h = e[3];
      if (id is! String || id.length != 8 || id == myId) continue;
      if (name is! String || color is! int || h is! int) continue;
      if (peers[id]?.online ?? false) continue;
      final pr = _learn(id, name, color);
      final hops = h + 1;
      final wasRelayed = pr.relayed;
      if (!wasRelayed || hops <= pr.hops || pr.via == from) {
        pr.hops = hops;
        pr.hopsTs = now;
        pr.via = from;
        if (!wasRelayed) {
          changed = true;
          _flush(id); // messages that were waiting can go out through the mesh now
        }
      }
    }
    if (changed) notifyListeners();
  }

  /// Re-send undelivered texts to phones that are only reachable through the mesh.
  void _reflood() {
    for (final pr in peers.values) {
      if (pr.online || !pr.relayed) continue;
      final waiting = thread(pr.id).any((m) => m.outgoing && m.type == 'text' && m.status != MsgStatus.delivered);
      if (waiting) _flush(pr.id, resend: true);
    }
  }

  // ======================================================== statuses (24 h)
  List<StatusItem> statusesOf(String authorId) =>
      (_statuses[authorId] ?? const <StatusItem>[]).where((s) => !s.expired).toList()
        ..sort((a, b) => a.ts.compareTo(b.ts));
  bool hasUnviewed(String authorId) => statusesOf(authorId).any((s) => !s.viewed);
  List<String> get statusAuthors =>
      _statuses.keys.where((k) => k != myId && statusesOf(k).isNotEmpty).toList();
  Map<String, int> viewersOf(String statusId) => _views[statusId] ?? const {};

  Future<void> postStatusImage(File src, {String caption = ''}) async {
    final id = _uuid.v4();
    final dest = p.join(_mediaDir, 's_${id}_${_clean(p.basename(src.path))}');
    await src.copy(dest); // original quality
    await _addStatus(StatusItem(
        id: id, authorId: myId, kind: 'image', path: dest, text: caption,
        ts: DateTime.now().millisecondsSinceEpoch, viewed: true, reported: true));
    _pushAll();
  }

  Future<void> postStatusText(String text, int color) async {
    await _addStatus(StatusItem(
        id: _uuid.v4(), authorId: myId, kind: 'text', text: text.trim(), color: color,
        ts: DateTime.now().millisecondsSinceEpoch, viewed: true, reported: true));
    _pushAll();
  }

  Future<void> _addStatus(StatusItem s) async {
    (_statuses[s.authorId] ??= []).add(s);
    _statusIds.add(s.id);
    await db.insertStatus(s);
    notifyListeners();
  }

  void _pushAll() {
    for (final pr in peers.values.where((x) => x.online)) {
      _pushStatuses(pr.id);
    }
  }

  Future<void> _pushStatuses(String peerId) async {
    if (!_pushing.add(peerId)) return;
    try {
      for (final s in statusesOf(myId)) {
        final pr = peers[peerId];
        if (pr == null || !pr.online || pr.endpointId == null) break;
        if (_sentSet.contains('${s.id}|$peerId')) continue;
        try {
          final eid = pr.endpointId!;
          if (s.kind == 'text') {
            await _send(eid, {'t': 's', 'k': 'text', 'id': s.id, 'ts': s.ts, 'x': s.text, 'c': s.color});
          } else {
            final pid = await _nearby.sendFilePayload(eid, s.path!);
            _outPid[pid] = s.id;
            await _send(eid, {
              't': 's', 'k': 'image', 'id': s.id, 'ts': s.ts, 'pid': pid,
              'n': p.basename(s.path!), 'x': s.text, 'c': s.color,
            });
          }
        } catch (_) {
          break;
        }
      }
    } finally {
      _pushing.remove(peerId);
    }
  }

  Future<void> _receiveStatus(String peerId, String eid, Map<String, dynamic> j, String? path) async {
    final id = j['id'] as String;
    if (!_statusIds.contains(id)) {
      final now = DateTime.now().millisecondsSinceEpoch;
      var ts = (j['ts'] as int?) ?? now;
      if (ts > now || now - ts >= 24 * 3600 * 1000) ts = now; // wrong phone clock: count from arrival
      {
        var t = (j['x'] as String? ?? '');
        if (t.length > 700) t = t.substring(0, 700);
        await _addStatus(StatusItem(
            id: id, authorId: peerId, kind: j['k'] == 'text' ? 'text' : 'image',
            path: path, text: t, color: (j['c'] as int?) ?? 0, ts: ts));
      }
    }
    _safe(() => _send(eid, {'t': 'sa', 'id': id}));
  }

  Future<void> markStatusViewed(StatusItem s) async {
    if (s.viewed || s.authorId == myId) return;
    s.viewed = true;
    await db.setViewed(s.id);
    notifyListeners();
    await _reportView(s);
  }

  Future<void> _reportView(StatusItem s) async {
    final pr = peers[s.authorId];
    if (pr == null || !pr.online || pr.endpointId == null) return; // sent on next connect
    try {
      await _send(pr.endpointId!, {'t': 'sv', 'id': s.id});
      s.reported = true;
      await db.setReported(s.id);
    } catch (_) {}
  }

  Future<void> deleteStatus(StatusItem s) async {
    _statuses[s.authorId]?.remove(s);
    _statusIds.remove(s.id);
    _views.remove(s.id);
    if (s.path != null) await _safe(() => File(s.path!).delete());
    await _safe(() => db.deleteStatus(s.id));
    notifyListeners();
  }

  Future<void> _purgeStatuses() async {
    var changed = false;
    for (final list in _statuses.values) {
      for (final s in list.where((x) => x.expired).toList()) {
        list.remove(s);
        _statusIds.remove(s.id);
        _views.remove(s.id);
        if (s.path != null) await _safe(() => File(s.path!).delete());
        await _safe(() => db.deleteStatus(s.id));
        changed = true;
      }
    }
    _statuses.removeWhere((_, v) => v.isEmpty);
    if (changed) notifyListeners();
  }

  // ======================================================== calls support
  Future<void> sendJsonTo(String peerId, Map<String, dynamic> j) async {
    final pr = peers[peerId];
    if (pr == null || pr.endpointId == null) return;
    try {
      await _send(pr.endpointId!, j);
    } catch (_) {}
  }

  Future<void> sendRawTo(String peerId, Uint8List b) async {
    final pr = peers[peerId];
    if (pr == null || pr.endpointId == null) return;
    await _nearby.sendBytesPayload(pr.endpointId!, b);
  }

  /// Local-only chat entry such as "Voice call 02:13" or "Missed video call".
  Future<void> addCallLog(String peerId, String text, bool outgoing) => _add(Message(
      id: _uuid.v4(), peerId: peerId, outgoing: outgoing, type: 'call', body: text,
      ts: DateTime.now().millisecondsSinceEpoch, status: MsgStatus.delivered, read: true));

  // ======================================================== data access
  List<Message> thread(String peerId) => _threads[peerId] ?? const [];
  Message? lastMessage(String peerId) {
    final t = thread(peerId);
    return t.isEmpty ? null : t.last;
  }

  int unread(String peerId) => thread(peerId).where((m) => !m.outgoing && !m.read).length;
  int get unreadTotal => _threads.keys.fold(0, (a, k) => a + unread(k));
  int get onlineCount => peers.values.where((x) => x.online).length;

  Future<void> _add(Message m) async {
    (_threads[m.peerId] ??= []).add(m);
    _ids.add(m.id);
    await db.insertMessage(m);
    notifyListeners();
    _updateService();
  }

  Future<void> markRead(String peerId) async {
    var changed = false;
    for (final m in thread(peerId)) {
      if (!m.outgoing && !m.read) {
        m.read = true;
        changed = true;
      }
    }
    if (changed) {
      await db.markRead(peerId);
      notifyListeners();
      _updateService();
    }
  }

  // ======================================================== settings
  Future<void> setName(String n) async {
    final t = n.trim();
    if (t.isEmpty) return;
    myName = t.length > 24 ? t.substring(0, 24) : t;
    await _prefs.setString('name', myName);
    await _profileChanged();
  }

  Future<void> setColor(int c) async {
    myColor = c;
    await _prefs.setInt('color', c);
    await _profileChanged();
  }

  Future<void> _profileChanged() async {
    for (final pr in peers.values.where((x) => x.online && x.endpointId != null)) {
      _safe(() => _send(pr.endpointId!, {'t': 'n', 'x': myName, 'c': myColor}));
    }
    if (running) {
      await _safe(() => _nearby.stopAdvertising());
      await _safe(() => _nearby.startAdvertising(_nick, Strategy.P2P_CLUSTER,
          onConnectionInitiated: _onInit, onConnectionResult: _onResult,
          onDisconnected: _onDisc, serviceId: serviceId));
    }
    notifyListeners();
  }

  Future<void> setAutoBluetooth(bool v) async {
    autoBluetooth = v;
    await _prefs.setBool('auto_bt', v);
    notifyListeners();
    if (v && wantRunning && !running) start();
  }

  Future<void> clearHistory() async {
    await db.clearAll();
    _threads.clear();
    _ids.clear();
    _statuses.clear();
    _statusIds.clear();
    _views.clear();
    _sentSet.clear();
    final dir = Directory(_mediaDir);
    if (await dir.exists()) {
      await for (final f in dir.list()) {
        await _safe(() => f.delete(recursive: true));
      }
    }
    peers.removeWhere((_, x) => !x.online && !x.discovered);
    for (final x in peers.values) {
      await db.upsertPeer(x);
    }
    notifyListeners();
    _updateService();
  }

  // ======================================================== helpers
  String _serviceText() => '$onlineCount connected · $unreadTotal unread';

  void _updateService() {
    if (!running) return;
    final t = _serviceText();
    if (t == _lastServiceText) return;
    _lastServiceText = t;
    _safe(() => _native.invokeMethod('startService', {'text': t}));
  }

  Future<void> _safe(Future<dynamic> Function() f) async {
    try {
      await f();
    } catch (_) {}
  }

  @override
  void dispose() {
    _timer?.cancel();
    _notifyGate?.cancel();
    super.dispose();
  }
}
