import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:nearby_connections/nearby_connections.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

import 'call_service.dart';
import 'db.dart';
import 'models.dart';
import 'premium.dart';

class _Found {
  _Found(this.endpointId, this.peerId) : since = DateTime.now();
  final String endpointId, peerId;
  final DateTime since;
}

/// Core engine: permissions, Bluetooth, foreground service, Nearby Connections
/// (P2P_CLUSTER), presence, offline queue, acks, media, voice and statuses.
///
/// Wire format: JSON object per Nearby BYTES payload (<= 32 KB). Media travels as
/// FILE payloads, byte-for-byte (no re-compression), plus a small JSON "meta" frame.
///   {t:'m', id, ts, x}                          text message
///   {t:'f', k:'image'|'voice', id, ts, pid, n, x, d}   file message meta (pid = file payload id)
///   {t:'a', id}                                 message ack
///   {t:'s', k:'text'|'image', id, ts, x, c, pid, n}    status update
///   {t:'sa', id}                                status received ack
///   {t:'sv', id}                                status viewed receipt
///   {t:'p', ts} / {t:'o', ts}                   ping / pong (link latency)
///   {t:'n', x, c}                               profile update
class MeshService extends ChangeNotifier {
  static const _native = MethodChannel('pulsemesh/native');
  static const serviceId = 'com.pulsemesh.mesh';
  static const _uuid = Uuid();

  final Db db = Db();
  final Premium premium = Premium();
  late final CallService calls = CallService(this);
  final Nearby _nearby = Nearby();
  late SharedPreferences _prefs;
  late String _mediaDir;

  // ---- identity & settings
  late String myId;
  String myName = '';
  String myBio = '';
  String? myCover;
  double textScale = 1.0;
  int myColor = 0;
  bool autoBluetooth = true;

  // ---- engine state
  bool wantRunning = true, running = false, _starting = false, _btDropped = false;
  int _retryAt = 0;
  String? error;
  String? openPeerId;
  bool advOk = false, discOk = false;
  int foundTotal = 0, _tickN = 0, _floodN = 0;
  String lastBadName = '', lastConnErr = '';
  Timer? _timer;
  String _lastServiceText = '';

  // ---- data
  final Map<String, Peer> peers = {};
  final Map<String, List<Message>> _threads = {};
  final Set<String> _ids = {};
  final Map<String, List<StatusItem>> _statuses = {}; // authorId -> items
  final Set<String> _statusIds = {};
  final Map<String, Map<String, int>> _views = {}; // statusId -> {peerId: ts}
  final Set<String> _sentSet = {}; // "statusId|peerId" already delivered
  final Map<String, double> progress = {}; // outgoing file progress by message/status id

  // ---- transport bookkeeping
  final Map<String, String> _epToPeer = {};
  final Map<String, _Found> _found = {};
  final Set<String> _pending = {};
  final Set<String> _flushing = {};
  final Set<String> _pushing = {};
  final Map<int, String> _filePaths = {};
  final Set<int> _fileDone = {};
  final Map<int, Map<String, dynamic>> _pendingMeta = {};
  final Map<int, String> _outPid = {};
  final Map<String, int> _handshake = {}; // endpointId -> start ms (to time out stuck handshakes)
  final Map<String, int> _tryTs = {};
  final Set<String> _relaySeen = {};
  final List<String> _relayOrder = [];

  // ======================================================== lifecycle
  Future<void> init([void Function(String)? step]) async {
    step?.call('Loading settings');
    _prefs = await SharedPreferences.getInstance();
    myId = _prefs.getString('id') ?? _uuid.v4().substring(0, 8);
    await _prefs.setString('id', myId);
    myName = _prefs.getString('name') ?? 'Node-${myId.substring(0, 4)}';
    myColor = _prefs.getInt('color') ?? (myId.codeUnitAt(0) % 8);
    myBio = _prefs.getString('bio') ?? '';
    textScale = _prefs.getDouble('text_scale') ?? 1.0;
    autoBluetooth = _prefs.getBool('auto_bt') ?? true;
    wantRunning = _prefs.getBool('mesh_on') ?? true;

    step?.call('Preparing storage');
    final docs = await getApplicationDocumentsDirectory();
    _mediaDir = p.join(docs.path, 'media');
    await Directory(_mediaDir).create(recursive: true);

    step?.call('Opening database');
    await db.open();
    step?.call('Loading chats');
    for (final pr in await db.peers()) {
      peers[pr.id] = pr;
    }
    for (final m in await db.messages()) {
      _ids.add(m.id);
      if (m.hidden) continue; // deleted for me: kept only so a late re-delivery is ignored
      (_threads[m.peerId] ??= []).add(m);
    }
    for (final s in await db.statuses()) {
      (_statuses[s.authorId] ??= []).add(s);
      _statusIds.add(s.id);
    }
    for (final r in await db.views()) {
      (_views[r['status_id'] as String] ??= {})[r['peer_id'] as String] = r['ts'] as int;
    }
    for (final r in await db.sent()) {
      _sentSet.add('${r['status_id']}|${r['peer_id']}');
    }
    await _purgeStatuses();

    step?.call('Loading premium');
    await premium.init(_prefs);
    premium.addListener(() {
      applySecure();
      notifyListeners();
    });
    _delPending.addAll(_prefs.getStringList('pend_del') ?? const <String>[]);
    _tomb.addAll(_prefs.getStringList('tomb') ?? const <String>[]);
    await _loadAvatars(docs.path);
    _annViewed.addAll(_prefs.getStringList('ann_viewed') ?? const <String>[]);
    final raw = _prefs.getString('ann_raw');
    if (raw != null) await ingestBundle(raw);
    applySecure();
    fetchAnnouncements(); // runs in the background; needs internet only for this
  }

  Future<void> start() async {
    wantRunning = true;
    await _prefs.setBool('mesh_on', true);
    if (running || _starting) return;
    _starting = true;
    error = null;
    notifyListeners();
    try {
      if (!await _ensurePermissions()) {
        error = 'OffChat needs Bluetooth, Nearby devices and notification permissions.';
        return;
      }
      if (!await _ensureBluetooth()) return;
      if (!(await Permission.locationWhenInUse.serviceStatus).isEnabled) {
        error = 'Turn ON Location (GPS) in phone settings. Bluetooth discovery needs it.';
      }
      await Future.wait([
        _native.invokeMethod('startService', {'text': _serviceText()}),
        _startNearby(),
      ]);
      running = true;
      _btDropped = false;
      _timer ??= Timer.periodic(const Duration(seconds: 2), (_) => _maintenance());
    } catch (e) {
      final s = '$e';
      if (s.contains('8034') || s.contains('MISSING_PERMISSION')) {
        error = friendlyError(e);
      } else {
        // Wi-Fi on/off, radio busy etc.: no error, try again in a few seconds
        error = null;
        _btDropped = true;
        _retryAt = DateTime.now().millisecondsSinceEpoch + 8000;
      }
    } finally {
      _starting = false;
      notifyListeners();
    }
  }

  Future<void> stop() async {
    wantRunning = false;
    await _prefs.setBool('mesh_on', false);
    await _stopNearby();
    running = false;
    _lastServiceText = '';
    await _safe(() => _native.invokeMethod('stopService'));
    notifyListeners();
  }

  Future<void> onResume() async {
    if (!wantRunning) return;
    if (!running) {
      await start();
    } else if (!(await _btOn())) {
      await _maintenance();
    }
  }

  Future<bool> _ensurePermissions() async {
    final sdk = await _native.invokeMethod<int>('sdkInt') ?? 0;
    final req = <Permission>[
      Permission.bluetoothScan,
      Permission.bluetoothAdvertise,
      Permission.bluetoothConnect,
      Permission.notification,
      Permission.locationWhenInUse, // Nearby needs location on every Android version
      if (sdk >= 33) Permission.nearbyWifiDevices,
    ];
    final res = await req.request();
    return res.entries
        .where((e) => e.key != Permission.notification)
        .every((e) => e.value.isGranted || e.value.isLimited);
  }

  Future<bool> _btOn() async => await _native.invokeMethod<bool>('isBluetoothOn') ?? false;

  Future<bool> _ensureBluetooth() async {
    if (await _btOn()) return true;
    if (!autoBluetooth) {
      error = 'Bluetooth is off. Turn it on, or enable Auto-Bluetooth in Settings.';
      return false;
    }
    final ok = await _native.invokeMethod<bool>('requestEnableBluetooth') ?? false;
    if (!ok) error = 'Bluetooth must be on for OffChat to find nearby peers.';
    return ok;
  }

  Future<void> _maintenance() async {
    _tickN++;
    final now = DateTime.now();
    final nowMs = now.millisecondsSinceEpoch;
    final slow = _tickN % 5 == 0; // ~10 s
    if (slow) await _purgeStatuses();
    final bt = (slow || !running) ? await _btOn() : true;
    if (running && !bt) {
      await _stopNearby();
      running = false;
      _btDropped = true;
      error = 'Bluetooth turned off. OffChat resumes when it is back on.';
      notifyListeners();
      return;
    }
    if (!running && _btDropped && wantRunning && bt && !_starting && nowMs >= _retryAt) {
      await start();
      return;
    }
    if (!running) return;

    // handshakes that hang forever: drop them so the next try can start fresh
    for (final e in _handshake.entries.toList()) {
      if (nowMs - e.value > 12000) {
        _handshake.remove(e.key);
        _pending.remove(e.key);
        final pid = _epToPeer[e.key];
        final pr = pid == null ? null : peers[pid];
        if (pr != null && pr.endpointId != e.key) {
          pr.connecting = false;
          _epToPeer.remove(e.key);
        }
        _safe(() => _nearby.disconnectFromEndpoint(e.key));
        notifyListeners();
      }
    }

    if (_tickN % 15 == 0 && onlineCount == 0 && _found.isEmpty) await _restartDiscovery();

    for (final f in _found.values.toList()) {
      final pr = peers[f.peerId];
      if (pr == null || pr.online || _pending.contains(f.endpointId)) continue;
      // lower id dials at once; the other side waits only 4 s, then dials too
      if (myId.compareTo(f.peerId) < 0 || now.difference(f.since).inSeconds >= 4) _request(f);
    }
    if (_tickN % 4 == 0) {
      for (final pr in _neighbours) {
        _safe(() => _send(pr.endpointId!, {'t': 'p', 'ts': nowMs}));
      }
    }
    if (slow) {
      premium.tick();
      if (_tickN % 10800 == 0) premium.refresh(); // ask the payment backend again about every 6 h
      _gossip();
      _pushAll();
      _reflood();
      if (_tickN % 900 == 0) fetchAnnouncements(); // about every 30 min
      final e = error;
      if (e != null && e.startsWith('Turn ON Location') &&
          (await Permission.locationWhenInUse.serviceStatus).isEnabled) {
        error = null;
        notifyListeners();
      }
    }
    _updateService();
  }

  // ======================================================== Nearby: advertise + discover
  String get _nick => '${myName.replaceAll('|', '')}|$myId|$myColor';

  ({String name, String id, int color})? _parse(String s) {
    final a = s.split('|');
    if (a.length != 3 || a[1].length != 8) return null;
    return (name: a[0].isEmpty ? 'Unknown' : a[0], id: a[1], color: int.tryParse(a[2]) ?? 0);
  }

  Future<void> _startNearby() async {
    advOk = discOk = false;
    try {
      await _nearby.startAdvertising(_nick, Strategy.P2P_CLUSTER,
          onConnectionInitiated: _onInit, onConnectionResult: _onResult,
          onDisconnected: _onDisc, serviceId: serviceId);
      advOk = true;
    } on PlatformException catch (e) {
      if (!'${e.code} ${e.message}'.contains('ALREADY')) rethrow;
      advOk = true;
    }
    await _startDiscovery();
  }

  Future<void> _startDiscovery() async {
    try {
      await _nearby.startDiscovery(_nick, Strategy.P2P_CLUSTER,
          onEndpointFound: _onFound, onEndpointLost: _onLost, serviceId: serviceId);
      discOk = true;
    } on PlatformException catch (e) {
      if (!'${e.code} ${e.message}'.contains('ALREADY')) rethrow;
      discOk = true;
    }
  }

  /// Some phones silently stop discovering after a while: restart it.
  Future<void> _restartDiscovery() async {
    await _safe(() => _nearby.stopDiscovery());
    try {
      await _startDiscovery();
      final e = error;
      if (e != null && e.startsWith('Discovery restart failed')) error = null;
    } catch (_) {
      // no error banner: the next maintenance cycle simply tries again
      discOk = false;
    }
    notifyListeners();
  }

  Future<void> _stopNearby() async {
    await _safe(() => _nearby.stopAdvertising());
    await _safe(() => _nearby.stopDiscovery());
    await _safe(() => _nearby.stopAllEndpoints());
    for (final pr in peers.values) {
      if (pr.online) {
        pr.lastSeen = DateTime.now().millisecondsSinceEpoch;
        _safe(() => db.upsertPeer(pr));
      }
      pr.online = pr.connecting = pr.discovered = false;
      pr.hops = 0;
      pr.endpointId = null;
      pr.rtt = null;
    }
    _epToPeer.clear();
    _found.clear();
    _pending.clear();
  }

  Peer _upsert(({String name, String id, int color}) i) {
    var pr = peers[i.id];
    if (pr == null) {
      pr = Peer(id: i.id, name: i.name, color: i.color);
      peers[i.id] = pr;
    } else {
      pr.name = i.name;
      pr.color = i.color;
    }
    _safe(() => db.upsertPeer(pr!));
    return pr;
  }

  void _onFound(String id, String name, String svc) {
    foundTotal++;
    final info = _parse(name);
    if (info == null) {
      lastBadName = name;
      notifyListeners();
      return;
    }
    if (info.id == myId) return;
    final pr = _upsert(info)..discovered = true;
    final f = _Found(id, info.id);
    _found[id] = f;
    notifyListeners();
    if (!pr.online && myId.compareTo(info.id) < 0) _request(f);
  }

  void _onLost(String? id) {
    final f = _found.remove(id);
    final pr = f == null ? null : peers[f.peerId];
    if (pr != null && !pr.online) pr.discovered = false;
    notifyListeners();
  }

  void connectTo(String peerId) {
    for (final f in _found.values) {
      if (f.peerId == peerId) _request(f, force: true);
    }
  }

  Future<void> _request(_Found f, {bool force = false}) async {
    final pr = peers[f.peerId];
    if (pr == null || pr.online || _pending.contains(f.endpointId)) return;
    final nowMs = DateTime.now().millisecondsSinceEpoch;
    if (!force && nowMs - (_tryTs[f.endpointId] ?? 0) < 2500) return;
    _tryTs[f.endpointId] = nowMs;
    _pending.add(f.endpointId);
    _handshake[f.endpointId] = nowMs;
    pr.connecting = true;
    notifyListeners();
    try {
      await _nearby.requestConnection(_nick, f.endpointId,
          onConnectionInitiated: _onInit, onConnectionResult: _onResult, onDisconnected: _onDisc);
    } catch (e) {
      _pending.remove(f.endpointId);
      _handshake.remove(f.endpointId);
      pr.connecting = false;
      lastConnErr = 'request: $e';
      notifyListeners();
    }
  }

  void _onInit(String id, ConnectionInfo info) {
    final pi = _parse(info.endpointName);
    if (pi == null || pi.id == myId) {
      _safe(() => _nearby.rejectConnection(id));
      return;
    }
    _epToPeer[id] = pi.id;
    _handshake[id] = DateTime.now().millisecondsSinceEpoch;
    _upsert(pi).connecting = true;
    notifyListeners();
    _safe(() => _nearby.acceptConnection(id,
        onPayLoadRecieved: (eid, payload) => _onPayload(eid, payload),
        onPayloadTransferUpdate: (eid, u) => _onTransfer(eid, u)));
  }

  void _onResult(String id, Status s) {
    _pending.remove(id);
    _handshake.remove(id);
    if (s != Status.CONNECTED) lastConnErr = 'result $s';
    final pr = peers[_epToPeer[id]];
    if (pr == null) return;
    pr.connecting = false;
    if (s == Status.CONNECTED) {
      if (pr.online && pr.endpointId != id) {
        _safe(() => _nearby.disconnectFromEndpoint(id));
        _epToPeer.remove(id);
        return;
      }
      pr
        ..online = true
        ..hops = 0
        ..endpointId = id
        ..lastSeen = DateTime.now().millisecondsSinceEpoch;
      _safe(() => db.upsertPeer(pr));
      _safe(() => _send(id, {'t': 'p', 'ts': DateTime.now().millisecondsSinceEpoch}));
      _flush(pr.id, resend: true);          // offline queue
      _pushStatuses(pr.id);                 // my statuses this peer has not received
      _gossip();                            // tell neighbours who is reachable through me
      _sendDeletes(pr.id);                  // deletes that were waiting for this peer
      _shareProfile(id);                    // name, bio, photo and cover
      for (final s in statusesOf(pr.id)) {  // tell them which of theirs I already viewed
        if (s.viewed && !s.reported) _reportView(s);
      }
    } else {
      _epToPeer.remove(id);
    }
    notifyListeners();
    _updateService();
  }

  void _onDisc(String id) {
    _pending.remove(id);
    _handshake.remove(id);
    final pid = _epToPeer.remove(id);
    final pr = pid == null ? null : peers[pid];
    if (pr != null && pr.endpointId == id) {
      if (pr.online) {
        pr.lastSeen = DateTime.now().millisecondsSinceEpoch; // "last seen" = when this link dropped
        _safe(() => db.upsertPeer(pr));
      }
      pr
        ..online = false
        ..connecting = false
        ..endpointId = null
        ..rtt = null;
    }
    notifyListeners();
    _updateService();
  }

  // ======================================================== receive
  void _onPayload(String eid, Payload payload) {
    if (payload.type == PayloadType.BYTES && payload.bytes != null) {
      final peerId = _epToPeer[eid];
      if (peerId == null) return;
      final raw = payload.bytes!;
      if (raw.isNotEmpty && raw[0] < 32) {
        calls.onRaw(peerId, raw); // realtime call audio frame, not JSON
        return;
      }
      try {
        _handle(eid, peerId, jsonDecode(utf8.decode(payload.bytes!)) as Map<String, dynamic>);
      } catch (_) {}
    } else if (payload.type == PayloadType.FILE) {
      // Android 10+ hands over a content:// uri (filePath is null there)
      String? src;
      try {
        src = (payload as dynamic).uri as String?;
      } catch (_) {}
      src ??= payload.filePath;
      if (src != null && src.isNotEmpty) _filePaths[payload.id] = src;
    }
  }

  void _onTransfer(String eid, PayloadTransferUpdate u) {
    final mine = _outPid[u.id]; // outgoing file: drive the progress ring
    if (mine != null) {
      if (u.status == PayloadStatus.IN_PROGRESS) {
        if (u.totalBytes > 0) {
          final f = u.bytesTransferred / u.totalBytes;
          if (f - (progress[mine] ?? 0) >= .03) {
            progress[mine] = f;
            notifyListeners();
          }
        }
      } else {
        progress.remove(mine);
        _outPid.remove(u.id);
        notifyListeners();
      }
    }
    if (u.status == PayloadStatus.SUCCESS && _filePaths.containsKey(u.id)) {
      _fileDone.add(u.id);
      _tryFinishFile(u.id);
    }
  }

  Future<void> _handle(String eid, String peerId, Map<String, dynamic> j) async {
    final pr = peers[peerId];
    switch (j['t']) {
      case 'm':
        final id = j['id'] as String;
        if (!_ids.contains(id)) {
          var text = (j['x'] as String? ?? '');
          if (text.length > 4000) text = text.substring(0, 4000);
          await _add(Message(
              id: id, peerId: peerId, outgoing: false, type: 'text', body: text,
              ts: DateTime.now().millisecondsSinceEpoch,
              status: MsgStatus.delivered, read: openPeerId == peerId));
        }
        _safe(() => _send(eid, {'t': 'a', 'id': id}));
      case 'f':
        final fpid = j['pid'] as int;
        _pendingMeta[fpid] = {...j, '_peer': peerId, '_eid': eid};
        _tryFinishFile(fpid);
      case 'a':
        for (final m in thread(peerId)) {
          if (m.id == j['id'] && m.outgoing && m.status != MsgStatus.delivered) {
            m.status = MsgStatus.delivered;
            _safe(() => db.setStatus(m.id, MsgStatus.delivered));
          }
        }
        notifyListeners();
      case 's':
        if (j['k'] == 'text') {
          await _receiveStatus(peerId, eid, j, null);
        } else {
          final spid = j['pid'] as int;
          _pendingMeta[spid] = {...j, '_peer': peerId, '_eid': eid};
          _tryFinishFile(spid);
        }
      case 'sa':
        final key = '${j['id']}|$peerId';
        if (_sentSet.add(key)) _safe(() => db.addSent(j['id'] as String, peerId));
      case 'sv':
        final sid = j['id'] as String;
        final mineStatus = statusesOf(myId).any((s) => s.id == sid);
        if (mineStatus) {
          final ts = DateTime.now().millisecondsSinceEpoch;
          (_views[sid] ??= {})[peerId] = ts;
          _safe(() => db.addView(sid, peerId, ts));
          notifyListeners();
        }
      case 'c':
        calls.onSignal(peerId, j);
      case 'r':
      case 'ra':
        await _onRelay(eid, j);
      case 'g':
        _onGossip(peerId, j);
      case 'av':
        await _onAvatar(peerId, j['b']);
      case 'cv':
        await _onCover(peerId, j['b']);
      case 'x':
        final bx = j['b'];
        if (bx is Map) await _handleCtl(peerId, bx.cast<String, dynamic>());
      case 'p':
        _safe(() => _send(eid, {'t': 'o', 'ts': j['ts']}));
      case 'o':
        if (pr != null) {
          pr.rtt = DateTime.now().millisecondsSinceEpoch - (j['ts'] as int);
          notifyListeners();
        }
      case 'n':
        if (pr != null) {
          final n = (j['x'] as String? ?? '').trim();
          if (n.isNotEmpty) pr.name = n.length > 24 ? n.substring(0, 24) : n;
          pr.color = (j['c'] as int?) ?? pr.color;
          final bio = j['b'];
          if (bio is String) pr.bio = bio.trim().length > 140 ? bio.trim().substring(0, 140) : bio.trim();
          _safe(() => db.upsertPeer(pr));
          notifyListeners();
        }
    }
  }

  String _clean(String s) => s.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');

  /// Finalises an incoming file once BOTH its meta frame and the file itself arrived.
  Future<void> _tryFinishFile(int pid) async {
    final meta = _pendingMeta[pid], src = _filePaths[pid];
    if (meta == null || src == null || !_fileDone.contains(pid)) return;
    _pendingMeta.remove(pid);
    _filePaths.remove(pid);
    _fileDone.remove(pid);
    final peerId = meta['_peer'] as String, eid = meta['_eid'] as String;
    final id = meta['id'] as String;
    final isStatus = meta['t'] == 's';
    final known = isStatus ? _statusIds.contains(id) : _ids.contains(id);

    String? dest;
    if (!known) {
      // never trust a remote file name: sanitise before touching the filesystem
      dest = p.join(_mediaDir,
          '${isStatus ? 's' : 'm'}_${_clean(id)}_${_clean(p.basename(meta['n'] as String))}');
      try {
        if (src.startsWith('content:')) {
          await _nearby.copyFileAndDeleteOriginal(src, dest);
          if (!File(dest).existsSync()) return;
        } else {
          await File(src).copy(dest);
          await _safe(() => File(src).delete());
        }
      } catch (_) {
        return; // unreadable: no ack, so the sender retries on the next link
      }
    }
    if (isStatus) {
      await _receiveStatus(peerId, eid, meta, dest);
      return;
    }
    if (!known) {
      var cap = (meta['x'] as String? ?? '');
      if (cap.length > 1000) cap = cap.substring(0, 1000);
      await _add(Message(
          id: id, peerId: peerId, outgoing: false,
          type: meta['k'] == 'voice' ? 'voice' : meta['k'] == 'video' ? 'video' : 'image',
          body: cap, path: dest, dur: (meta['d'] as int?) ?? 0,
          ts: DateTime.now().millisecondsSinceEpoch,
          status: MsgStatus.delivered, read: openPeerId == peerId));
    }
    _safe(() => _send(eid, {'t': 'a', 'id': id}));
  }

  // ======================================================== send + offline queue
  Future<void> _send(String eid, Map<String, dynamic> j) =>
      _nearby.sendBytesPayload(eid, Uint8List.fromList(utf8.encode(jsonEncode(j))));

  Future<void> sendText(String peerId, String text) async {
    final t = text.trim();
    if (t.isEmpty) return;
    await _add(Message(
        id: _uuid.v4(), peerId: peerId, outgoing: true, type: 'text', body: t,
        ts: DateTime.now().millisecondsSinceEpoch));
    _flush(peerId);
    final pr = peers[peerId];
    if (pr != null && !pr.online) connectTo(peerId); // dial now instead of waiting
  }

  /// Sends the ORIGINAL file bytes: no resizing, no re-encoding.
  Future<void> sendImage(String peerId, File src, {String caption = ''}) async {
    final id = _uuid.v4();
    final dest = p.join(_mediaDir, 'm_${id}_${_clean(p.basename(src.path))}');
    await src.copy(dest);
    await _add(Message(
        id: id, peerId: peerId, outgoing: true, type: 'image', body: caption, path: dest,
        ts: DateTime.now().millisecondsSinceEpoch));
    _flush(peerId);
  }

  Future<void> sendVideo(String peerId, File src) async {
    final id = _uuid.v4();
    final dest = p.join(_mediaDir, 'm_${id}_${_clean(p.basename(src.path))}');
    await src.copy(dest);
    await _add(Message(
        id: id, peerId: peerId, outgoing: true, type: 'video', body: '', path: dest,
        ts: DateTime.now().millisecondsSinceEpoch));
    _flush(peerId);
  }

  Future<void> sendVoice(String peerId, String path, int durMs) async {
    final id = _uuid.v4();
    final dest = p.join(_mediaDir, 'v_$id.m4a');
    await File(path).copy(dest);
    await _safe(() => File(path).delete());
    await _add(Message(
        id: id, peerId: peerId, outgoing: true, type: 'voice', body: '', path: dest, dur: durMs,
        ts: DateTime.now().millisecondsSinceEpoch));
    _flush(peerId);
  }

  Future<void> _flush(String peerId, {bool resend = false}) async {
    if (!_flushing.add(peerId)) return;
    try {
      for (final m in List<Message>.of(thread(peerId))) {
        if (!m.outgoing || m.status == MsgStatus.delivered || m.deleted) continue;
        if (m.status == MsgStatus.sent && !resend) continue;
        final pr = peers[peerId];
        if (pr == null) break;
        final direct = pr.online && pr.endpointId != null;
        final viaMesh = !direct && m.type == 'text' && pr.relayed && _neighbours.isNotEmpty;
        if (!direct && !viaMesh) continue; // media waits for a direct link
        try {
          if (m.type == 'text') {
            if (direct) {
              await _send(pr.endpointId!, {'t': 'm', 'id': m.id, 'ts': m.ts, 'x': m.body});
            } else {
              await _floodRelay({
                't': 'r', 'id': m.id, 'src': myId, 'dst': peerId, 'ttl': 6, 'ts': m.ts,
                'x': m.body, 'sn': myName, 'sc': myColor, 'k': _newK(),
              });
            }
          } else {
            final eid = pr.endpointId!;
            final pid = await _nearby.sendFilePayload(eid, m.path!);
            _outPid[pid] = m.id;
            await _send(eid, {
              't': 'f', 'k': m.type, 'id': m.id, 'ts': m.ts, 'pid': pid,
              'n': p.basename(m.path!), 'x': m.body, 'd': m.dur,
            });
          }
          if (m.status == MsgStatus.queued) {
            m.status = MsgStatus.sent;
            await db.setStatus(m.id, MsgStatus.sent);
          }
          notifyListeners();
        } catch (_) {
          break;
        }
      }
    } finally {
      _flushing.remove(peerId);
    }
  }

  // ======================================================== mesh relay (A - B - C chains)
  List<Peer> get _neighbours =>
      peers.values.where((x) => x.online && x.endpointId != null).toList();

  String _newK() => '$myId-${_floodN++}-${DateTime.now().millisecondsSinceEpoch}';

  bool _seenRelay(String k) {
    if (_relaySeen.contains(k)) return true;
    _relaySeen.add(k);
    _relayOrder.add(k);
    if (_relayOrder.length > 3000) _relaySeen.remove(_relayOrder.removeAt(0));
    return false;
  }

  /// Send straight to the destination if it is a neighbour, else to every neighbour
  /// (except the one it came from). Duplicates are dropped by the unique key "k".
  Future<void> _floodRelay(Map<String, dynamic> f, {String? exceptEid}) async {
    final d = peers[f['dst'] as String];
    if (d != null && d.online && d.endpointId != null) {
      if (d.endpointId != exceptEid) await _send(d.endpointId!, f);
      return;
    }
    for (final n in _neighbours) {
      if (n.endpointId == exceptEid) continue;
      _safe(() => _send(n.endpointId!, f));
    }
  }

  Peer _learn(String id, String? name, int? color) {
    var pr = peers[id];
    if (pr == null) {
      final nm = (name == null || name.trim().isEmpty) ? 'Node-${id.substring(0, 4)}' : name.trim();
      pr = Peer(id: id, name: nm.length > 24 ? nm.substring(0, 24) : nm, color: color ?? 0);
      peers[id] = pr;
      final created = pr;
      _safe(() => db.upsertPeer(created));
    }
    return pr;
  }

  Future<void> _onRelay(String eid, Map<String, dynamic> j) async {
    final k = j['k'] as String? ?? '';
    final src = j['src'] as String? ?? '', dst = j['dst'] as String? ?? '';
    if (k.isEmpty || src.length != 8 || dst.length != 8 || src == myId) return;
    if (_seenRelay(k)) return;
    if (dst == myId) {
      if (j['t'] == 'rx') {
        final b = j['b'];
        if (b is Map) {
          _learn(src, null, null);
          await _handleCtl(src, b.cast<String, dynamic>());
        }
        return;
      }
      final id = j['id'] as String;
      if (j['t'] == 'r') {
        final pr = _learn(src, j['sn'] as String?, j['sc'] as int?);
        if (!_ids.contains(id)) {
          var text = (j['x'] as String? ?? '');
          if (text.length > 4000) text = text.substring(0, 4000);
          await _add(Message(
              id: id, peerId: pr.id, outgoing: false, type: 'text', body: text,
              ts: DateTime.now().millisecondsSinceEpoch,
              status: MsgStatus.delivered, read: openPeerId == pr.id));
        }
        _safe(() => _floodRelay({'t': 'ra', 'id': id, 'src': myId, 'dst': src, 'ttl': 6, 'k': _newK()}));
      } else {
        for (final m in thread(src)) {
          if (m.id == id && m.outgoing && m.status != MsgStatus.delivered) {
            m.status = MsgStatus.delivered;
            _safe(() => db.setStatus(m.id, MsgStatus.delivered));
          }
        }
        notifyListeners();
      }
      return;
    }
    final ttl = ((j['ttl'] as int?) ?? 0) - 1;
    if (ttl <= 0) return;
    await _floodRelay({...j, 'ttl': ttl}, exceptEid: eid);
  }

  /// Tell every neighbour which other phones I can reach (split horizon: never echo a route back).
  void _gossip() {
    for (final n in _neighbours) {
      final list = <List<Object>>[];
      for (final p in peers.values) {
        if (p.id == n.id) continue;
        if (p.online) {
          list.add([p.id, p.name, p.color, 1]);
        } else if (p.relayed && p.hops < 5 && p.via != n.id) {
          list.add([p.id, p.name, p.color, p.hops]);
        }
      }
      _safe(() => _send(n.endpointId!, {'t': 'g', 'n': list}));
    }
  }

  void _onGossip(String from, Map<String, dynamic> j) {
    final list = j['n'];
    if (list is! List) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    var changed = false;
    for (final e in list) {
      if (e is! List || e.length < 4) continue;
      final id = e[0], name = e[1], color = e[2], h = e[3];
      if (id is! String || id.length != 8 || id == myId) continue;
      if (name is! String || color is! int || h is! int) continue;
      if (peers[id]?.online ?? false) continue;
      final pr = _learn(id, name, color);
      final hops = h + 1;
      final wasRelayed = pr.relayed;
      if (!wasRelayed || hops <= pr.hops || pr.via == from) {
        pr.hops = hops;
        pr.hopsTs = now;
        pr.via = from;
        if (!wasRelayed) {
          changed = true;
          _flush(id); // messages that were waiting can go out through the mesh now
        }
      }
    }
    if (changed) notifyListeners();
  }

  /// Re-send undelivered texts to phones that are only reachable through the mesh.
  void _reflood() {
    for (final pr in peers.values) {
      if (pr.online || !pr.relayed) continue;
      final waiting = thread(pr.id).any((m) => m.outgoing && m.type == 'text' && m.status != MsgStatus.delivered);
      if (waiting) _flush(pr.id, resend: true);
    }
    for (final pid in _delPending.map((e) => e.split('|').first).toSet()) {
      _sendDeletes(pid);
    }
  }

  // ======================================================== statuses (24 h)
  List<StatusItem> statusesOf(String authorId) =>
      (_statuses[authorId] ?? const <StatusItem>[]).where((s) => !s.expired).toList()
        ..sort((a, b) => a.ts.compareTo(b.ts));
  bool hasUnviewed(String authorId) => statusesOf(authorId).any((s) => !s.viewed);
  List<String> get statusAuthors =>
      _statuses.keys.where((k) => k != myId && statusesOf(k).isNotEmpty).toList();
  Map<String, int> viewersOf(String statusId) => _views[statusId] ?? const {};

  Future<void> postStatusImage(File src, {String caption = ''}) async {
    final id = _uuid.v4();
    final dest = p.join(_mediaDir, 's_${id}_${_clean(p.basename(src.path))}');
    await src.copy(dest); // original quality
    await _addStatus(StatusItem(
        id: id, authorId: myId, kind: 'image', path: dest, text: caption,
        ts: DateTime.now().millisecondsSinceEpoch, viewed: true, reported: true));
    _pushAll();
  }

  Future<void> postStatusText(String text, int color) async {
    await _addStatus(StatusItem(
        id: _uuid.v4(), authorId: myId, kind: 'text', text: text.trim(), color: color,
        ts: DateTime.now().millisecondsSinceEpoch, viewed: true, reported: true));
    _pushAll();
  }

  Future<void> _addStatus(StatusItem s) async {
    (_statuses[s.authorId] ??= []).add(s);
    _statusIds.add(s.id);
    await db.insertStatus(s);
    notifyListeners();
  }

  void _pushAll() {
    for (final pr in peers.values.where((x) => x.online)) {
      _pushStatuses(pr.id);
    }
  }

  Future<void> _pushStatuses(String peerId) async {
    if (!_pushing.add(peerId)) return;
    try {
      for (final s in statusesOf(myId)) {
        final pr = peers[peerId];
        if (pr == null || !pr.online || pr.endpointId == null) break;
        if (_sentSet.contains('${s.id}|$peerId')) continue;
        try {
          final eid = pr.endpointId!;
          if (s.kind == 'text') {
            await _send(eid, {'t': 's', 'k': 'text', 'id': s.id, 'ts': s.ts, 'x': s.text, 'c': s.color});
          } else {
            final pid = await _nearby.sendFilePayload(eid, s.path!);
            _outPid[pid] = s.id;
            await _send(eid, {
              't': 's', 'k': 'image', 'id': s.id, 'ts': s.ts, 'pid': pid,
              'n': p.basename(s.path!), 'x': s.text, 'c': s.color,
            });
          }
        } catch (_) {
          break;
        }
      }
    } finally {
      _pushing.remove(peerId);
    }
  }

  Future<void> _receiveStatus(String peerId, String eid, Map<String, dynamic> j, String? path) async {
    final id = j['id'] as String;
    if (!_statusIds.contains(id)) {
      final now = DateTime.now().millisecondsSinceEpoch;
      var ts = (j['ts'] as int?) ?? now;
      if (ts > now || now - ts >= 24 * 3600 * 1000) ts = now; // wrong phone clock: count from arrival
      {
        var t = (j['x'] as String? ?? '');
        if (t.length > 700) t = t.substring(0, 700);
        await _addStatus(StatusItem(
            id: id, authorId: peerId, kind: j['k'] == 'text' ? 'text' : 'image',
            path: path, text: t, color: (j['c'] as int?) ?? 0, ts: ts));
      }
    }
    _safe(() => _send(eid, {'t': 'sa', 'id': id}));
  }

  Future<void> markStatusViewed(StatusItem s) async {
    if (s.viewed || s.authorId == myId) return;
    s.viewed = true;
    if (s.authorId == kOfficialId) {
      _annViewed.add(s.id);
      await _prefs.setStringList('ann_viewed', _annViewed.toList());
      notifyListeners();
      return;
    }
    await db.setViewed(s.id);
    notifyListeners();
    await _reportView(s);
  }

  Future<void> _reportView(StatusItem s) async {
    final pr = peers[s.authorId];
    if (pr == null || !pr.online || pr.endpointId == null) return; // sent on next connect
    try {
      await _send(pr.endpointId!, {'t': 'sv', 'id': s.id});
      s.reported = true;
      await db.setReported(s.id);
    } catch (_) {}
  }

  Future<void> deleteStatus(StatusItem s) async {
    _statuses[s.authorId]?.remove(s);
    _statusIds.remove(s.id);
    _views.remove(s.id);
    if (s.path != null) await _safe(() => File(s.path!).delete());
    await _safe(() => db.deleteStatus(s.id));
    notifyListeners();
  }

  Future<void> _purgeStatuses() async {
    var changed = false;
    for (final list in _statuses.values) {
      for (final s in list.where((x) => x.expired).toList()) {
        list.remove(s);
        _statusIds.remove(s.id);
        _views.remove(s.id);
        if (s.path != null) await _safe(() => File(s.path!).delete());
        await _safe(() => db.deleteStatus(s.id));
        changed = true;
      }
    }
    _statuses.removeWhere((_, v) => v.isEmpty);
    if (changed) notifyListeners();
  }

  // ======================================================== calls support
  Future<void> sendJsonTo(String peerId, Map<String, dynamic> j) async {
    final pr = peers[peerId];
    if (pr == null || pr.endpointId == null) return;
    try {
      await _send(pr.endpointId!, j);
    } catch (_) {}
  }

  Future<void> sendRawTo(String peerId, Uint8List b) async {
    final pr = peers[peerId];
    if (pr == null || pr.endpointId == null) return;
    await _nearby.sendBytesPayload(pr.endpointId!, b);
  }

  /// Local-only chat entry such as "Voice call 02:13" or "Missed video call".
  Future<void> addCallLog(String peerId, String text, bool outgoing) => _add(Message(
      id: _uuid.v4(), peerId: peerId, outgoing: outgoing, type: 'call', body: text,
      ts: DateTime.now().millisecondsSinceEpoch, status: MsgStatus.delivered, read: true));

  // ======================================================== data access
  List<Message> thread(String peerId) => _threads[peerId] ?? const [];
  Message? lastMessage(String peerId) {
    final t = thread(peerId);
    return t.isEmpty ? null : t.last;
  }

  int unread(String peerId) => thread(peerId).where((m) => !m.outgoing && !m.read).length;
  int get unreadTotal => _threads.keys.fold(0, (a, k) => a + unread(k));
  int get onlineCount => peers.values.where((x) => x.online).length;

  Future<void> _add(Message m) async {
    if (_tomb.remove(m.id)) {
      _saveTomb();
      // the sender's "delete for everyone" arrived before the message itself
      m.deleted = true;
      if (!premium.has(Feature.seeDeleted)) await _eraseContent(m);
    }
    (_threads[m.peerId] ??= []).add(m);
    _ids.add(m.id);
    await db.insertMessage(m);
    notifyListeners();
    _updateService();
  }

  Future<void> markRead(String peerId) async {
    var changed = false;
    for (final m in thread(peerId)) {
      if (!m.outgoing && !m.read) {
        m.read = true;
        changed = true;
      }
    }
    if (changed) {
      await db.markRead(peerId);
      notifyListeners();
      _updateService();
    }
  }

  // ======================================================== profile pictures
  final Map<String, String> _avatars = {}; // peerId -> picture file
  String? myAvatar;
  late String _avDir;

  String? avatarOf(String id) => id == myId ? myAvatar : _avatars[id];

  String _safeId(String s) => s.replaceAll(RegExp(r'[^A-Za-z0-9]'), '');

  Future<void> _loadAvatars(String docs) async {
    _wpDir = p.join(docs, 'wallpapers');
    await Directory(_wpDir).create(recursive: true);
    _cvDir = p.join(docs, 'covers');
    await Directory(_cvDir).create(recursive: true);
    _avDir = p.join(docs, 'avatars');
    await Directory(_avDir).create(recursive: true);
    myCover = await _scanPictures(_cvDir, _covers);
    final newest = <String, String>{};
    await for (final e in Directory(_avDir).list()) {
      final n = p.basename(e.path);
      if (!n.endsWith('.jpg') || n == 'me_share.jpg') continue;
      final id = n.split('_').first;
      final cur = newest[id];
      if (cur == null || n.compareTo(p.basename(cur)) > 0) {
        if (cur != null) await _safe(() => File(cur).delete());
        newest[id] = e.path;
      } else {
        await _safe(() => File(e.path).delete());
      }
    }
    myAvatar = newest.remove('me');
    _avatars.addAll(newest);
  }

  /// Keeps only the newest picture per person in [dir]; returns my own one.
  Future<String?> _scanPictures(String dir, Map<String, String> out) async {
    final newest = <String, String>{};
    await for (final e in Directory(dir).list()) {
      final n = p.basename(e.path);
      if (!n.endsWith('.jpg') || n == 'me_share.jpg') continue;
      final id = n.split('_').first;
      final cur = newest[id];
      if (cur == null || n.compareTo(p.basename(cur)) > 0) {
        if (cur != null) await _safe(() => File(cur).delete());
        newest[id] = e.path;
      } else {
        await _safe(() => File(e.path).delete());
      }
    }
    final mine = newest.remove('me');
    out.addAll(newest);
    return mine;
  }

  /// Picks a photo, makes a 256 px copy for me and a tiny 96 px copy that is sent to the people I meet.
  Future<void> setAvatar(String srcPath) async {
    final big = await _crop(srcPath, 256, 256, 85);
    var small = await _crop(srcPath, 96, 96, 70);
    for (final q in [55, 40, 28]) {
      if (small != null && base64Encode(small).length > 26000) small = await _crop(srcPath, 96, 96, q);
    }
    if (big == null || small == null) return;
    final f = File(p.join(_avDir, 'me_${DateTime.now().millisecondsSinceEpoch}.jpg'));
    await f.writeAsBytes(big);
    await File(p.join(_avDir, 'me_share.jpg')).writeAsBytes(small);
    final old = myAvatar;
    myAvatar = f.path;
    if (old != null) await _safe(() => File(old).delete());
    notifyListeners();
    _shareAvatar();
  }

  Future<void> removeAvatar() async {
    final old = myAvatar;
    myAvatar = null;
    if (old != null) await _safe(() => File(old).delete());
    await _safe(() => File(p.join(_avDir, 'me_share.jpg')).delete());
    notifyListeners();
    _shareAvatar();
  }

  Future<void> _shareAvatar({String? eid}) async {
    var b = '';
    final f = File(p.join(_avDir, 'me_share.jpg'));
    if (myAvatar != null && await f.exists()) b = base64Encode(await f.readAsBytes());
    final frame = {'t': 'av', 'b': b}; // empty = no picture
    if (eid != null) {
      _safe(() => _send(eid, frame));
    } else {
      for (final n in _neighbours) {
        _safe(() => _send(n.endpointId!, frame));
      }
    }
  }

  Future<void> _onAvatar(String peerId, Object? b) async {
    final id = _safeId(peerId);
    final old = _avatars[peerId];
    if (b is! String || b.isEmpty) {
      _avatars.remove(peerId);
      if (old != null) await _safe(() => File(old).delete());
      notifyListeners();
      return;
    }
    if (b.length > 40000 || id.isEmpty) return;
    try {
      final f = File(p.join(_avDir, '${id}_${DateTime.now().millisecondsSinceEpoch}.jpg'));
      await f.writeAsBytes(base64Decode(b));
      _avatars[peerId] = f.path;
      if (old != null) await _safe(() => File(old).delete());
      notifyListeners();
    } catch (_) {}
  }

  // ======================================================== bio, cover photo, wallpapers, text size
  final Map<String, String> _covers = {};
  late String _cvDir, _wpDir;

  String? coverOf(String id) => id == myId ? myCover : _covers[id];

  Future<Uint8List?> _crop(String path, int w, int h, int q) =>
      _native.invokeMethod<Uint8List>('crop', {'path': path, 'w': w, 'h': h, 'q': q});

  Future<void> setBio(String text) async {
    final t = text.trim();
    myBio = t.length > 140 ? t.substring(0, 140) : t;
    await _prefs.setString('bio', myBio);
    _broadcastProfile();
    notifyListeners();
  }

  void _broadcastProfile({String? eid}) {
    final frame = {'t': 'n', 'x': myName, 'c': myColor, 'b': myBio};
    if (eid != null) {
      _safe(() => _send(eid, frame));
    } else {
      for (final n in _neighbours) {
        _safe(() => _send(n.endpointId!, frame));
      }
    }
  }

  /// Name, colour, bio, photo and cover: everything a contact card shows.
  void _shareProfile(String eid) {
    _broadcastProfile(eid: eid);
    _shareAvatar(eid: eid);
    _shareCover(eid: eid);
  }

  Future<void> setCover(String srcPath) async {
    final big = await _crop(srcPath, 960, 360, 82);
    var small = await _crop(srcPath, 480, 180, 65);
    for (final q in [50, 38, 28]) {
      if (small != null && base64Encode(small).length > 26000) small = await _crop(srcPath, 480, 180, q);
    }
    if (big == null || small == null) return;
    final f = File(p.join(_cvDir, 'me_${DateTime.now().millisecondsSinceEpoch}.jpg'));
    await f.writeAsBytes(big);
    await File(p.join(_cvDir, 'me_share.jpg')).writeAsBytes(small);
    final old = myCover;
    myCover = f.path;
    if (old != null) await _safe(() => File(old).delete());
    notifyListeners();
    _shareCover();
  }

  Future<void> removeCover() async {
    final old = myCover;
    myCover = null;
    if (old != null) await _safe(() => File(old).delete());
    await _safe(() => File(p.join(_cvDir, 'me_share.jpg')).delete());
    notifyListeners();
    _shareCover();
  }

  Future<void> _shareCover({String? eid}) async {
    var b = '';
    final f = File(p.join(_cvDir, 'me_share.jpg'));
    if (myCover != null && await f.exists()) b = base64Encode(await f.readAsBytes());
    final frame = {'t': 'cv', 'b': b};
    if (eid != null) {
      _safe(() => _send(eid, frame));
    } else {
      for (final n in _neighbours) {
        _safe(() => _send(n.endpointId!, frame));
      }
    }
  }

  Future<void> _onCover(String peerId, Object? b) async {
    final id = _safeId(peerId);
    final old = _covers[peerId];
    if (b is! String || b.isEmpty) {
      _covers.remove(peerId);
      if (old != null) await _safe(() => File(old).delete());
      notifyListeners();
      return;
    }
    if (b.length > 40000 || id.isEmpty) return;
    try {
      final f = File(p.join(_cvDir, '${id}_${DateTime.now().millisecondsSinceEpoch}.jpg'));
      await f.writeAsBytes(base64Decode(b));
      _covers[peerId] = f.path;
      if (old != null) await _safe(() => File(old).delete());
      notifyListeners();
    } catch (_) {}
  }

  // wallpaper spec: '' = default | 'g:N' = preset N | 'f:/path' = my photo
  String wallpaperOf(String peerId) =>
      _prefs.getString('wp_$peerId') ?? _prefs.getString('wp_default') ?? '';

  Future<void> setWallpaper(String? peerId, String spec, {bool clearOverrides = false}) async {
    final key = peerId == null ? 'wp_default' : 'wp_$peerId';
    final old = _prefs.getString(key);
    if (spec.isEmpty) {
      await _prefs.remove(key);
    } else {
      await _prefs.setString(key, spec);
    }
    if (old != null && old.startsWith('f:') && old != spec) {
      await _safe(() => File(old.substring(2)).delete());
    }
    if (clearOverrides) {
      for (final k in _prefs.getKeys().where((k) => k.startsWith('wp_') && k != 'wp_default').toList()) {
        final v = _prefs.getString(k);
        if (v != null && v.startsWith('f:') && v != spec) await _safe(() => File(v.substring(2)).delete());
        await _prefs.remove(k);
      }
    }
    notifyListeners();
  }

  Future<void> setWallpaperPhoto(String? peerId, String src, {bool clearOverrides = false}) async {
    final bytes = await _crop(src, 720, 1280, 80);
    if (bytes == null) return;
    final f = File(p.join(_wpDir, '${peerId ?? 'default'}_${DateTime.now().millisecondsSinceEpoch}.jpg'));
    await f.writeAsBytes(bytes);
    await setWallpaper(peerId, 'f:${f.path}', clearOverrides: clearOverrides);
  }

  Future<void> setTextScale(double v) async {
    textScale = v;
    await _prefs.setDouble('text_scale', v);
    notifyListeners();
  }

  bool scanning = false;

  /// Manual "scan again": restarts discovery and dials everyone already seen.
  Future<void> rescan() async {
    if (scanning) return;
    if (!running) {
      await start();
      return;
    }
    scanning = true;
    notifyListeners();
    await _restartDiscovery();
    for (final f in _found.values.toList()) {
      _request(f, force: true);
    }
    await Future<void>.delayed(const Duration(seconds: 3));
    scanning = false;
    notifyListeners();
  }

  Future<void> _saveTomb() {
    while (_tomb.length > 300) {
      _tomb.remove(_tomb.first);
    }
    return _prefs.setStringList('tomb', _tomb.toList());
  }

  // ======================================================== premium: delete + screenshots
  bool has(Feature f) => premium.has(f);

  final Set<String> _delPending = {}; // "peerId|msgId" deletes not yet acknowledged
  final Set<String> _tomb = {};
  static const _shots = EventChannel('pulsemesh/shots');
  StreamSubscription<dynamic>? _shotSub;
  int _lastShot = 0;

  Future<void> _saveDel() => _prefs.setStringList('pend_del', _delPending.toList());

  Future<void> _eraseContent(Message m) async {
    final p = m.path;
    if (p != null) await _safe(() => File(p).delete());
    m.body = '';
    m.path = null;
  }

  /// Small control frames (delete, screenshot alert). Direct if possible, else through the mesh.
  Future<bool> _sendCtl(String peerId, Map<String, dynamic> body) async {
    final pr = peers[peerId];
    if (pr == null) return false;
    try {
      if (pr.online && pr.endpointId != null) {
        await _send(pr.endpointId!, {'t': 'x', 'b': body});
        return true;
      }
      if (pr.relayed && _neighbours.isNotEmpty) {
        await _floodRelay({'t': 'rx', 'src': myId, 'dst': peerId, 'ttl': 6, 'b': body, 'k': _newK()});
        return true;
      }
    } catch (_) {}
    return false;
  }

  Future<void> _handleCtl(String from, Map<String, dynamic> b) async {
    switch (b['c']) {
      case 'del':
        final id = b['id'] as String? ?? '';
        if (id.isEmpty) return;
        Message? hit;
        for (final m in thread(from)) {
          if (m.id == id && !m.outgoing) hit = m;
        }
        if (hit != null && !hit.deleted) {
          final keep = premium.has(Feature.seeDeleted); // Premium can still read it
          if (!keep) await _eraseContent(hit);
          hit.deleted = true;
          await _safe(() => db.markDeleted(id, wipe: !keep));
          notifyListeners();
          _updateService();
        } else if (hit == null) {
          _tomb.add(id);
          await _saveTomb();
        }
        _safe(() => _sendCtl(from, {'c': 'dack', 'id': id}));
      case 'dack':
        if (_delPending.remove('$from|${b['id']}')) await _saveDel();
      case 'ss':
        if (premium.has(Feature.screenshotAlerts)) {
          final nm = peers[from]?.name ?? 'Contact';
          await addNote(from, '$nm took a screenshot of this chat', outgoing: false);
        }
    }
  }

  Future<void> addNote(String peerId, String text, {required bool outgoing}) => _add(Message(
      id: _uuid.v4(), peerId: peerId, outgoing: outgoing, type: 'note', body: text,
      ts: DateTime.now().millisecondsSinceEpoch, status: MsgStatus.delivered,
      read: outgoing || openPeerId == peerId));

  /// Delete for me: free for everyone.
  Future<void> deleteForMe(Message m) async {
    _threads[m.peerId]?.remove(m);
    final p = m.path;
    if (p != null) await _safe(() => File(p).delete());
    await _safe(() => db.hideMessage(m.id));
    notifyListeners();
    _updateService();
  }

  /// Delete for everyone: Premium. Works through the mesh and is retried until acknowledged.
  Future<bool> deleteForEveryone(Message m) async {
    if (!m.outgoing || m.deleted || !premium.has(Feature.deleteForEveryone)) return false;
    await _eraseContent(m);
    m.deleted = true;
    await _safe(() => db.markDeleted(m.id, wipe: true));
    _delPending.add('${m.peerId}|${m.id}');
    await _saveDel();
    notifyListeners();
    _updateService();
    _sendDeletes(m.peerId);
    return true;
  }

  Future<void> _sendDeletes(String peerId) async {
    for (final e in _delPending.toList()) {
      final i = e.indexOf('|');
      if (i < 0 || e.substring(0, i) != peerId) continue;
      await _sendCtl(peerId, {'c': 'del', 'id': e.substring(i + 1)});
    }
  }

  Future<void> applySecure() => _safe(
      () => _native.invokeMethod('secure', {'on': premium.active && premium.secureOn}));

  /// Called when a chat opens: asks once for photo access so screenshots can be noticed.
  Future<void> ensureShotWatch() async {
    if (_shotSub != null) return;
    try {
      final sdk = await _native.invokeMethod<int>('sdkInt') ?? 0;
      final perm = sdk >= 33 ? Permission.photos : Permission.storage;
      var st = await perm.status;
      var ok = st.isGranted || st.isLimited;
      if (!ok && !(_prefs.getBool('shot_asked') ?? false)) {
        await _prefs.setBool('shot_asked', true);
        st = await perm.request();
        ok = st.isGranted || st.isLimited;
      }
      if (!ok) return;
      _shotSub = _shots.receiveBroadcastStream().listen((_) => _onShot());
      await _native.invokeMethod('shotWatch', {'on': true});
    } catch (_) {}
  }

  void _onShot() {
    final pid = openPeerId;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (pid == null || now - _lastShot < 3000) return;
    _lastShot = now;
    _safe(() => _sendCtl(pid, {'c': 'ss'})); // everyone's app reports; Premium users see the alert
    addNote(pid, 'You took a screenshot', outgoing: true);
  }

  // ======================================================== official OffChat updates
  int annSeq = 0;
  String _annRaw = '';
  String? updateLatest, updateUrl;
  final Set<String> _annViewed = {};
  final List<Map<String, dynamic>> _annItems = [];

  bool _newer(String a, String b) {
    final x = a.split('.').map((e) => int.tryParse(e) ?? 0).toList();
    final y = b.split('.').map((e) => int.tryParse(e) ?? 0).toList();
    for (var i = 0; i < 3; i++) {
      final p = i < x.length ? x[i] : 0, q = i < y.length ? y[i] : 0;
      if (p != q) return p > q;
    }
    return false;
  }

  /// announcements.json from your own HTTPS link. The higher "seq" wins.
  Future<bool> ingestBundle(String raw) async {
    final text = raw.trim();
    if (text.isEmpty || text.length > 60000) return false;
    try {
      final j = jsonDecode(text) as Map<String, dynamic>;
      final seq = (j['seq'] as num).toInt();
      if (seq <= annSeq) return false;
      annSeq = seq;
      _annRaw = text;
      _annItems
        ..clear()
        ..addAll((j['items'] as List? ?? const []).map((e) => Map<String, dynamic>.from(e as Map)));
      updateLatest = j['latest'] as String?;
      updateUrl = j['url'] as String?;
      await _prefs.setString('ann_raw', text);
      _rebuildOfficial();
      notifyListeners();
      return true;
    } catch (_) {
      return false;
    }
  }

  int _itemTs(Map<String, dynamic> it, int now) {
    final d = DateTime.tryParse('${it['date'] ?? ''}'); // "date": "2026-10-22"
    return d?.millisecondsSinceEpoch ?? (it['ts'] as num?)?.toInt() ?? now;
  }

  void _rebuildOfficial() {
    final now = DateTime.now().millisecondsSinceEpoch;
    for (final s in _statuses.remove(kOfficialId) ?? const <StatusItem>[]) {
      _statusIds.remove(s.id);
    }
    final list = <StatusItem>[];
    final latest = updateLatest;
    if (latest != null && _newer(latest, kAppVersion)) {
      final id = 'upd_$latest';
      list.add(StatusItem(
          id: id, authorId: kOfficialId, kind: 'text', color: 0, ts: now, ttlH: 24 * 30,
          text: 'New version v$latest is available.\n\n${updateUrl ?? ''}',
          viewed: _annViewed.contains(id), reported: true));
    }
    for (final it in _annItems) {
      final id = 'ann_${it['id']}';
      final title = (it['title'] as String? ?? '').trim();
      final body = (it['text'] as String? ?? '').trim();
      final s = StatusItem(
          id: id, authorId: kOfficialId, kind: 'text',
          text: [title, body].where((e) => e.isNotEmpty).join('\n\n'),
          color: (it['c'] as num?)?.toInt() ?? 0,
          ts: _itemTs(it, now),
          ttlH: ((it['days'] as num?)?.toInt() ?? 7) * 24,
          viewed: _annViewed.contains(id), reported: true);
      if (!s.expired && s.text.isNotEmpty) list.add(s);
    }
    if (list.isEmpty) return;
    peers[kOfficialId] ??= Peer(id: kOfficialId, name: 'OffChat ✓', color: 0); // never saved to DB
    _statuses[kOfficialId] = list;
    for (final s in list) {
      _statusIds.add(s.id);
    }
  }

  Future<void> fetchAnnouncements() async {
    if (kAnnounceUrl.isEmpty) return;
    try {
      final c = HttpClient()..connectionTimeout = const Duration(seconds: 6);
      final req = await c.getUrl(Uri.parse(kAnnounceUrl));
      final res = await req.close().timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final body = await res.transform(utf8.decoder).join();
        await ingestBundle(body);
      }
      c.close();
    } catch (_) {}
  }

  // ======================================================== settings
  Future<void> setName(String n) async {
    final t = n.trim();
    if (t.isEmpty) return;
    myName = t.length > 24 ? t.substring(0, 24) : t;
    await _prefs.setString('name', myName);
    await _profileChanged();
  }

  Future<void> setColor(int c) async {
    myColor = c;
    await _prefs.setInt('color', c);
    await _profileChanged();
  }

  Future<void> _profileChanged() async {
    for (final pr in peers.values.where((x) => x.online && x.endpointId != null)) {
      _safe(() => _send(pr.endpointId!, {'t': 'n', 'x': myName, 'c': myColor, 'b': myBio}));
    }
    if (running) {
      await _safe(() => _nearby.stopAdvertising());
      await _safe(() => _nearby.startAdvertising(_nick, Strategy.P2P_CLUSTER,
          onConnectionInitiated: _onInit, onConnectionResult: _onResult,
          onDisconnected: _onDisc, serviceId: serviceId));
    }
    notifyListeners();
  }

  Future<void> setAutoBluetooth(bool v) async {
    autoBluetooth = v;
    await _prefs.setBool('auto_bt', v);
    notifyListeners();
    if (v && wantRunning && !running) start();
  }

  Future<void> clearHistory() async {
    await db.clearAll();
    _threads.clear();
    _ids.clear();
    _statuses.clear();
    _statusIds.clear();
    _views.clear();
    _sentSet.clear();
    final dir = Directory(_mediaDir);
    if (await dir.exists()) {
      await for (final f in dir.list()) {
        await _safe(() => f.delete(recursive: true));
      }
    }
    peers.removeWhere((_, x) => !x.online && !x.discovered);
    for (final x in peers.values) {
      await db.upsertPeer(x);
    }
    _rebuildOfficial();
    notifyListeners();
    _updateService();
  }

  // ======================================================== helpers
  String _serviceText() => '$onlineCount connected · $unreadTotal unread';

  void _updateService() {
    if (!running) return;
    final t = _serviceText();
    if (t == _lastServiceText) return;
    _lastServiceText = t;
    _safe(() => _native.invokeMethod('startService', {'text': t}));
  }

  Future<void> _safe(Future<dynamic> Function() f) async {
    try {
      await f();
    } catch (_) {}
  }

  @override
  void dispose() {
    _disposed = true;
    _nt?.cancel();
    _timer?.cancel();
    _shotSub?.cancel();
    super.dispose();
  }

  // Bursts of events (pings, progress, deliveries) are merged into one rebuild: smoother UI.
  Timer? _nt;
  bool _disposed = false;
  @override
  void notifyListeners() {
    if (_disposed || _nt != null) return;
    _nt = Timer(const Duration(milliseconds: 50), () {
      _nt = null;
      if (!_disposed) super.notifyListeners();
    });
  }
}

/// Turns Nearby / platform exceptions into one plain sentence the user can act on.
String friendlyError(Object e) {
  final s = '$e';
  if (s.contains('8034') || s.contains('MISSING_PERMISSION')) {
    return 'OffChat needs Location and Nearby-devices permission. Tap App settings and allow them.';
  }
  if (s.contains('8007') || s.contains('RADIO')) {
    return 'Bluetooth or Wi-Fi had a problem. Turn Bluetooth off and on, then tap Retry.';
  }
  if (s.contains('8032') || s.contains('BLUETOOTH')) {
    return 'Bluetooth is not available right now. Turn it on and tap Retry.';
  }
  return 'OffChat could not start nearby connections. Check that Bluetooth and Location are on, then tap Retry.';
}
