import 'package:flutter/material.dart';

/// OffChat palette: deep forest green + mint (matches the logo).
class C {
  static const bg = Color(0xFF07140D);
  static const surface = Color(0xFF0E1F15);
  static const surface2 = Color(0xFF16301F);
  static const line = Color(0xFF21402C);
  static const indigo = Color(0xFF1FA155);
  static const indigoSoft = Color(0xFF86EFAC);
  static const online = Color(0xFF4ADE80);
  static const text = Color(0xFFE8F3EC);
  static const muted = Color(0xFF8DAA98);
  static const avatars = <Color>[
    Color(0xFF22A559), Color(0xFF14B8A6), Color(0xFFF59E0B), Color(0xFFEC4899),
    Color(0xFF0EA5E9), Color(0xFF84CC16), Color(0xFFF97316), Color(0xFF8B5CF6),
  ];
  static Color avatar(int i) => avatars[i.abs() % avatars.length];
}

ThemeData buildTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: C.bg,
    colorScheme: const ColorScheme.dark(
      primary: C.indigo, secondary: C.indigoSoft, surface: C.surface, onSurface: C.text,
    ),
    appBarTheme: const AppBarTheme(backgroundColor: C.bg, elevation: 0, scrolledUnderElevation: 0),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: C.surface,
      indicatorColor: C.indigo.withOpacity(.28),
      labelTextStyle: WidgetStateProperty.all(const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
    ),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
    dividerColor: C.line,
    pageTransitionsTheme: const PageTransitionsTheme(builders: {
      TargetPlatform.android: CupertinoPageTransitionsBuilder(), // slide + swipe-back
      TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
    }),
  );
}

/// Bouncy, glow-free scrolling everywhere.
class SmoothScroll extends MaterialScrollBehavior {
  const SmoothScroll();
  @override
  ScrollPhysics getScrollPhysics(BuildContext context) =>
      const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics());
  @override
  Widget buildOverscrollIndicator(BuildContext context, Widget child, ScrollableDetails details) => child;
}
