import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../call_service.dart';
import '../mesh_service.dart';
import '../theme.dart';
import '../widgets.dart';

/// Full-screen call UI. Lives above the Navigator, so no tooltips / dialogs in here.
class CallOverlay extends StatelessWidget {
  const CallOverlay({super.key});

  @override
  Widget build(BuildContext context) {
    final c = context.watch<CallService>();
    return IgnorePointer(
      ignoring: !c.active,
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 280),
        switchInCurve: Curves.easeOutCubic,
        transitionBuilder: (child, a) => FadeTransition(
          opacity: a,
          child: SlideTransition(
              position: Tween(begin: const Offset(0, .05), end: Offset.zero).animate(a), child: child)),
        child: c.active ? const _CallView(key: ValueKey('call')) : const SizedBox.shrink(key: ValueKey('none')),
      ),
    );
  }
}

class _CallView extends StatelessWidget {
  const _CallView({super.key});

  String _mmss(int s) => '${(s ~/ 60).toString().padLeft(2, '0')}:${(s % 60).toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final c = context.watch<CallService>();
    final mesh = context.read<MeshService>();
    final peer = mesh.peers[c.peerId];
    final name = peer?.name ?? 'Unknown';
    final color = peer?.color ?? 0;
    final liveVideo = c.video && c.state == CallState.connected && c.remoteFrame != null && !c.remoteCamOff;
    final status = switch (c.state) {
      CallState.calling => 'Calling…',
      CallState.incoming => 'Incoming ${c.video ? 'video' : 'voice'} call',
      CallState.connected => c.video && c.remoteFrame == null && !c.remoteCamOff ? 'Connecting video…' : _mmss(c.seconds),
      _ => c.endNote,
    };

    return Material(
      color: C.bg,
      child: Stack(fit: StackFit.expand, children: [
        if (liveVideo)
          _Frame(bytes: c.remoteFrame!, rot: c.remoteRot)
        else
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter, end: Alignment.bottomCenter,
                colors: [Color.lerp(C.avatar(color), C.bg, .7)!, C.bg]),
            ),
          ),
        if (liveVideo) // soft top/bottom shade so text stays readable on bright video
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter, end: Alignment.bottomCenter,
                colors: [Colors.black54, Colors.transparent, Colors.transparent, Colors.black54],
                stops: [0, .25, .7, 1]))),
        SafeArea(
          child: Column(children: [
            const SizedBox(height: 24),
            if (liveVideo) ...[
              Text(name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
              const SizedBox(height: 2),
              Text(status, style: const TextStyle(color: Colors.white70)),
              const Spacer(),
            ] else ...[
              const Spacer(flex: 2),
              _Pulse(
                active: c.state == CallState.calling || c.state == CallState.incoming || c.state == CallState.connected,
                color: C.avatar(color),
                child: PeerAvatar(name: name, color: color, size: 124)),
              const SizedBox(height: 26),
              Text(name, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800, letterSpacing: -.5)),
              const SizedBox(height: 6),
              Text(status, style: const TextStyle(fontSize: 16, color: C.muted)),
              if (c.video && c.camErr.isNotEmpty)
                Padding(padding: const EdgeInsets.fromLTRB(24, 8, 24, 0), child: Text('Camera: ${c.camErr}', textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFFF87171), fontSize: 12))),
              if (c.state == CallState.connected && c.video && c.remoteCamOff)
                const Padding(padding: EdgeInsets.only(top: 6), child: Text('Camera is off', style: TextStyle(color: C.muted))),
              const Spacer(flex: 3),
            ],
            _controls(c),
            const SizedBox(height: 28),
          ]),
        ),
        if (c.video && c.state == CallState.connected && c.localFrame != null && !c.cameraOff)
          Positioned(
            top: MediaQuery.of(context).padding.top + 14, right: 14, width: 104, height: 150,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(18),
              child: DecoratedBox(
                position: DecorationPosition.foreground,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white24, width: 1.5)),
                child: _Frame(bytes: c.localFrame!, rot: c.localRot, mirror: c.frontCam)),
            ),
          ),
      ]),
    );
  }

  Widget _controls(CallService c) {
    if (c.state == CallState.incoming) {
      return Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
        _Btn(icon: Icons.call_end_rounded, label: 'Decline', color: const Color(0xFFEF4444), big: true, onTap: c.reject),
        _Btn(icon: c.video ? Icons.videocam_rounded : Icons.call_rounded, label: 'Accept',
            color: C.online, big: true, onTap: c.accept),
      ]);
    }
    if (c.state == CallState.ended) return const SizedBox(height: 90);
    return Wrap(alignment: WrapAlignment.center, spacing: 18, runSpacing: 18, children: [
      _Btn(icon: c.muted ? Icons.mic_off_rounded : Icons.mic_rounded, label: c.muted ? 'Unmute' : 'Mute',
          on: c.muted, onTap: c.toggleMute),
      _Btn(icon: c.speaker ? Icons.volume_up_rounded : Icons.volume_down_rounded, label: 'Speaker',
          on: c.speaker, onTap: c.toggleSpeaker),
      if (c.video) ...[
        _Btn(icon: c.cameraOff ? Icons.videocam_off_rounded : Icons.videocam_rounded, label: 'Camera',
            on: c.cameraOff, onTap: c.toggleCamera),
        _Btn(icon: Icons.cameraswitch_rounded, label: 'Flip', onTap: c.flipCamera),
      ],
      _Btn(icon: Icons.call_end_rounded, label: 'End', color: const Color(0xFFEF4444), onTap: c.end),
    ]);
  }
}

class _Btn extends StatelessWidget {
  const _Btn({required this.icon, required this.label, required this.onTap, this.color, this.on = false, this.big = false});
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color? color;
  final bool on, big;

  @override
  Widget build(BuildContext context) {
    final size = big ? 76.0 : 62.0;
    final bg = color ?? (on ? Colors.white : Colors.white.withOpacity(.14));
    final fg = color != null ? Colors.white : (on ? C.bg : Colors.white);
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          width: size, height: size,
          decoration: BoxDecoration(color: bg, shape: BoxShape.circle),
          child: Icon(icon, color: fg, size: big ? 34 : 28)),
        const SizedBox(height: 8),
        Text(label, style: const TextStyle(fontSize: 12.5, color: Colors.white70)),
      ]),
    );
  }
}

class _Frame extends StatelessWidget {
  const _Frame({required this.bytes, required this.rot, this.mirror = false});
  final Uint8List bytes;
  final int rot;
  final bool mirror;
  @override
  Widget build(BuildContext context) => ClipRect(
        child: SizedBox.expand(
          child: FittedBox(
            fit: BoxFit.cover,
            child: Transform(
              alignment: Alignment.center,
              transform: Matrix4.diagonal3Values(mirror ? -1.0 : 1.0, 1.0, 1.0),
              child: RotatedBox(
                quarterTurns: rot,
                child: Image.memory(bytes, gaplessPlayback: true, filterQuality: FilterQuality.low)),
            ),
          ),
        ),
      );
}

/// Soft expanding rings behind the avatar while ringing / talking.
class _Pulse extends StatefulWidget {
  const _Pulse({required this.child, required this.color, required this.active});
  final Widget child;
  final Color color;
  final bool active;
  @override
  State<_Pulse> createState() => _PulseState();
}

class _PulseState extends State<_Pulse> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 2400))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => SizedBox(
        width: 260, height: 260,
        child: Stack(alignment: Alignment.center, children: [
          if (widget.active)
            AnimatedBuilder(
              animation: _c,
              builder: (_, __) => Stack(alignment: Alignment.center, children: [
                for (var i = 0; i < 3; i++) _ring((_c.value + i / 3) % 1),
              ]),
            ),
          widget.child,
        ]),
      );

  Widget _ring(double t) => Container(
        width: 124 + 136 * t, height: 124 + 136 * t,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: widget.color.withOpacity((1 - t) * .55), width: 2)),
      );
}
