import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../mesh_service.dart';
import '../premium.dart';
import '../theme.dart';

void openPremium(BuildContext context, {String? reason}) => Navigator.push(
    context, MaterialPageRoute(builder: (_) => PremiumScreen(reason: reason)));

class PremiumScreen extends StatefulWidget {
  const PremiumScreen({super.key, this.reason});
  final String? reason;
  @override
  State<PremiumScreen> createState() => _PremiumScreenState();
}

class _PremiumScreenState extends State<PremiumScreen> {
  String _sel = kYearlyId;

  static const _features = <(IconData, String, String)>[
    (Icons.camera_alt_outlined, 'Screenshot alerts', 'Get told when someone takes a screenshot of your chat.'),
    (Icons.lock_outline_rounded, 'Block screenshots', 'Nobody can screenshot or screen-record OffChat on your phone.'),
    (Icons.delete_forever_outlined, 'Delete for everyone', 'Remove a message from the other phone too, even through the mesh.'),
    (Icons.history_rounded, 'See deleted messages', 'Read messages the sender deleted for everyone.'),
  ];

  @override
  Widget build(BuildContext context) {
    final pr = context.watch<MeshService>().premium;
    return Scaffold(
      appBar: AppBar(title: const Text('OffChat Premium')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: const LinearGradient(colors: [Color(0xFF16A34A), Color(0xFF166534)]),
          ),
          child: Row(children: [
            const Icon(Icons.workspace_premium_rounded, size: 40, color: Colors.white),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(pr.active ? 'Premium is active' : 'Go Premium',
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Text(pr.active ? pr.planLabel : 'Pick a plan below',
                    style: const TextStyle(color: Colors.white70)),
              ]),
            ),
          ]),
        ),
        if (widget.reason != null) ...[
          const SizedBox(height: 12),
          Text(widget.reason!, style: const TextStyle(color: C.indigoSoft)),
        ],
        const SizedBox(height: 14),
        for (final f in _features)
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Icon(f.$1, color: C.indigoSoft),
            title: Text(f.$2, style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text(f.$3, style: const TextStyle(color: C.muted)),
          ),
        if (pr.active)
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Block screenshots on this phone'),
            subtitle: const Text('Also hides OffChat in the recent-apps screen.'),
            value: pr.secureOn,
            onChanged: (v) => pr.setSecure(v),
          ),
        const Divider(height: 28),
        if (!pr.active) ...[
          _plan(pr, kYearlyId, 'Yearly', 'per year', badge: 'BEST VALUE · SAVE 37%'),
          _plan(pr, kMonthlyId, 'Monthly', 'per month'),
          _plan(pr, kLifetimeId, 'Lifetime pass', 'one payment, no renewals'),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: pr.busy ? null : () => pr.buy(_sel),
            icon: pr.busy
                ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.workspace_premium_rounded),
            label: Text(_sel == kLifetimeId ? 'Get lifetime pass · ${pr.price(_sel)}' : 'Subscribe · ${pr.price(_sel)}'),
          ),
        ],
        if (pr.message != null) ...[
          const SizedBox(height: 10),
          Text(pr.message!, style: const TextStyle(color: Color(0xFFFBBF24))),
        ],
        const SizedBox(height: 6),
        TextButton(onPressed: pr.busy ? null : pr.restore, child: const Text('Restore purchase')),
        const SizedBox(height: 6),
        const Text(
            'Billed by Google Play. Cancel a subscription any time in Google Play → Payments & subscriptions → Subscriptions. '
            'Premium follows your Google account, so it also works after reinstalling.',
            style: TextStyle(color: C.muted, fontSize: 12.5, height: 1.4)),
      ]),
    );
  }

  Widget _plan(Premium pr, String id, String title, String sub, {String? badge}) {
    final on = _sel == id;
    return GestureDetector(
      onTap: () => setState(() => _sel = id),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: C.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: on ? C.indigoSoft : C.line, width: on ? 2 : 1),
        ),
        child: Row(children: [
          Icon(on ? Icons.radio_button_checked : Icons.radio_button_off, color: on ? C.indigoSoft : C.muted),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              if (badge != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 3),
                  child: Text(badge, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800, color: Color(0xFFFBBF24)))),
              Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              Text(sub, style: const TextStyle(color: C.muted, fontSize: 12.5)),
            ]),
          ),
          Text(pr.price(id), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
        ]),
      ),
    );
  }
}
