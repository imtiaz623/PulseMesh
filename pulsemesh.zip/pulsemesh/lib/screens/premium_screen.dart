import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../mesh_service.dart';
import '../premium.dart';
import '../theme.dart';

void openPremium(BuildContext context, {String? reason}) => Navigator.push(
    context, MaterialPageRoute(builder: (_) => PremiumScreen(reason: reason)));

class PremiumScreen extends StatelessWidget {
  const PremiumScreen({super.key, this.reason});
  final String? reason;

  static const _features = <(IconData, String, String)>[
    (Icons.camera_alt_outlined, 'Screenshot alerts', 'Get told when someone takes a screenshot of your chat.'),
    (Icons.lock_outline_rounded, 'Block screenshots', 'Nobody can screenshot or screen-record OffChat on your phone.'),
    (Icons.delete_forever_outlined, 'Delete for everyone', 'Remove a message from the other phone too, even through the mesh.'),
    (Icons.history_rounded, 'See deleted messages', 'Read messages the sender deleted for everyone.'),
  ];

  @override
  Widget build(BuildContext context) {
    final pr = context.watch<MeshService>().premium;
    return Scaffold(
      appBar: AppBar(title: const Text('OffChat Premium')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: const LinearGradient(colors: [Color(0xFF16A34A), Color(0xFF166534)]),
          ),
          child: Row(children: [
            const Icon(Icons.workspace_premium_rounded, size: 40, color: Colors.white),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(pr.active ? 'Premium is active' : 'Go Premium',
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Text(pr.active ? 'Renews monthly through Google Play' : pr.priceText,
                    style: const TextStyle(color: Colors.white70)),
              ]),
            ),
          ]),
        ),
        if (reason != null) ...[
          const SizedBox(height: 12),
          Text(reason!, style: const TextStyle(color: C.indigoSoft)),
        ],
        const SizedBox(height: 16),
        for (final f in _features)
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Icon(f.$1, color: C.indigoSoft),
            title: Text(f.$2, style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text(f.$3, style: const TextStyle(color: C.muted)),
          ),
        if (pr.active)
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Block screenshots on this phone'),
            subtitle: const Text('Also hides OffChat in the recent-apps screen.'),
            value: pr.secureOn,
            onChanged: (v) => pr.setSecure(v),
          ),
        const Divider(height: 28),
        if (!pr.active)
          FilledButton.icon(
            onPressed: pr.busy ? null : pr.buy,
            icon: pr.busy
                ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.workspace_premium_rounded),
            label: Text('Subscribe · ${pr.priceText}'),
          ),
        if (pr.message != null) ...[
          const SizedBox(height: 10),
          Text(pr.message!, style: const TextStyle(color: Color(0xFFFBBF24))),
        ],
        const SizedBox(height: 6),
        TextButton(
          onPressed: pr.busy ? null : pr.restore,
          child: const Text('Restore purchase'),
        ),
        const SizedBox(height: 6),
        const Text(
            'Billed monthly by Google Play. Cancel any time in Google Play → Payments & subscriptions → Subscriptions. '
            'Your subscription follows your Google account, so it also works after reinstalling.',
            style: TextStyle(color: C.muted, fontSize: 12.5, height: 1.4)),
      ]),
    );
  }
}
