import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../mesh_service.dart';
import '../models.dart';
import '../theme.dart';

/// Asks for confirmation, then floods an SOS to every phone in reach (or stops a running one).
Future<void> showSosDialog(BuildContext context) async {
  final mesh = context.read<MeshService>();
  final ctl = TextEditingController();
  final res = await showDialog<String>(
    context: context,
    builder: (d) => AlertDialog(
      backgroundColor: C.surface,
      title: const Row(children: [
        Icon(Icons.warning_amber_rounded, color: Color(0xFFF87171)),
        SizedBox(width: 8),
        Text('Emergency SOS'),
      ]),
      content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(
            mesh.sosActive
                ? 'Your SOS is being sent to everyone nearby, again every 10 seconds.'
                : 'This alerts every OffChat phone in range, and the phones they are connected to, even without internet. Use it only in a real emergency.',
            style: const TextStyle(color: C.muted, height: 1.35)),
        if (!mesh.sosActive) ...[
          const SizedBox(height: 12),
          TextField(
            controller: ctl, maxLength: 120,
            decoration: const InputDecoration(hintText: 'What is happening? (optional)'),
          ),
        ],
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')),
        if (mesh.sosActive)
          FilledButton(
            onPressed: () => Navigator.pop(d, 'stop'),
            child: const Text('Stop SOS'))
        else
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFFDC2626)),
            onPressed: () => Navigator.pop(d, 'send'),
            child: const Text('Send SOS')),
      ],
    ),
  );
  if (res == 'send') mesh.startSos(ctl.text);
  if (res == 'stop') mesh.stopSos();
  ctl.dispose();
}

/// Full-screen alert shown on top of everything when an SOS arrives.
class SosOverlay extends StatelessWidget {
  const SosOverlay({super.key});
  @override
  Widget build(BuildContext context) {
    final a = context.select<MeshService, SosAlert?>((m) => m.incomingSos);
    if (a == null) return const SizedBox.shrink();
    return _SosCard(key: ValueKey(a.id), alert: a);
  }
}

class _SosCard extends StatefulWidget {
  const _SosCard({super.key, required this.alert});
  final SosAlert alert;
  @override
  State<_SosCard> createState() => _SosCardState();
}

class _SosCardState extends State<_SosCard> {
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _buzz();
    _t = Timer.periodic(const Duration(seconds: 2), (_) => _buzz());
  }

  void _buzz() {
    HapticFeedback.heavyImpact();
    SystemSound.play(SystemSoundType.alert);
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final a = widget.alert;
    final d = DateTime.fromMillisecondsSinceEpoch(a.ts);
    final time = '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
    return Material(
      color: const Color(0xF2450A0A),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.warning_amber_rounded, size: 92, color: Color(0xFFFF6B6B)),
            const SizedBox(height: 10),
            const Text('EMERGENCY SOS',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, letterSpacing: 1.5, color: Colors.white)),
            const SizedBox(height: 22),
            Text(a.name,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800, color: Colors.white)),
            const SizedBox(height: 10),
            Text(a.text.isEmpty ? 'needs help!' : a.text,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 18, color: Colors.white70, height: 1.35)),
            const SizedBox(height: 14),
            Text('${a.hops == 1 ? 'Directly connected' : '${a.hops} hops away'} · $time',
                style: const TextStyle(color: Colors.white54)),
            const SizedBox(height: 34),
            FilledButton(
              style: FilledButton.styleFrom(
                  backgroundColor: Colors.white, foregroundColor: const Color(0xFF7F1D1D),
                  padding: const EdgeInsets.symmetric(horizontal: 44, vertical: 14)),
              onPressed: () => context.read<MeshService>().dismissSos(),
              child: const Text('I saw it', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            ),
          ]),
        ),
      ),
    );
  }
}
