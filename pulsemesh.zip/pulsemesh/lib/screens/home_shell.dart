import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../mesh_service.dart';
import '../models.dart';
import '../theme.dart';
import '../widgets.dart';
import 'chat_screen.dart';
import 'radar_screen.dart';
import 'settings_screen.dart';
import 'status_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  final _pc = PageController();
  int _tab = 0;

  @override
  void initState() {
    super.initState();
    // Startup: ask permissions, prompt for Bluetooth, start service + discovery. No taps needed.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final mesh = context.read<MeshService>();
      if (mesh.wantRunning) mesh.start();
    });
  }

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  void _go(int i) {
    if (i == _tab) return;
    HapticFeedback.selectionClick();
    setState(() => _tab = i);
    _pc.animateToPage(i, duration: const Duration(milliseconds: 320), curve: Curves.easeOutCubic);
  }

  @override
  Widget build(BuildContext context) {
    final unread = context.select<MeshService, int>((m) => m.unreadTotal);
    final newStatus = context.select<MeshService, int>(
        (m) => m.statusAuthors.where(m.hasUnviewed).length);
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: PageView(
          controller: _pc,
          onPageChanged: (i) {
            if (i != _tab) {
              HapticFeedback.selectionClick();
              setState(() => _tab = i);
            }
          },
          children: [
            _Keep(child: ChatsTab(onGoRadar: () => _go(2))),
            const _Keep(child: StatusTab()),
            const _Keep(child: RadarTab()),
            const _Keep(child: SettingsTab()),
          ],
        ),
      ),
      bottomNavigationBar: _PillNav(index: _tab, onTap: _go, badges: [unread, newStatus, 0, 0]),
    );
  }
}

/// Keeps each swipe-able tab alive so scroll position and animations survive.
class _Keep extends StatefulWidget {
  const _Keep({required this.child});
  final Widget child;
  @override
  State<_Keep> createState() => _KeepState();
}

class _KeepState extends State<_Keep> with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;
  @override
  Widget build(BuildContext context) {
    super.build(context);
    return widget.child;
  }
}

/// Floating pill navigation: the selected tab grows and shows its label.
class _PillNav extends StatelessWidget {
  const _PillNav({required this.index, required this.onTap, required this.badges});
  final int index;
  final ValueChanged<int> onTap;
  final List<int> badges;

  static const _items = <(IconData, String)>[
    (Icons.forum_rounded, 'Chats'),
    (Icons.motion_photos_on_rounded, 'Status'),
    (Icons.radar_rounded, 'Radar'),
    (Icons.person_rounded, 'Profile'),
  ];

  @override
  Widget build(BuildContext context) => SafeArea(
        top: false,
        child: Container(
          margin: const EdgeInsets.fromLTRB(14, 6, 14, 10),
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: C.surface,
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: C.line),
            boxShadow: const [BoxShadow(color: Colors.black45, blurRadius: 18, offset: Offset(0, 6))]),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            for (var i = 0; i < _items.length; i++)
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => onTap(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 280),
                  curve: Curves.easeOutCubic,
                  width: i == index ? 112 : 52, height: 48,
                  decoration: BoxDecoration(
                    color: i == index ? C.indigo.withOpacity(.22) : Colors.transparent,
                    borderRadius: BorderRadius.circular(24)),
                  child: ClipRect(
                    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Badge(
                        isLabelVisible: badges[i] > 0,
                        label: badges[i] > 9 ? null : Text('${badges[i]}'),
                        smallSize: badges[i] > 9 ? 9 : null,
                        child: Icon(_items[i].$1, size: 24, color: i == index ? C.indigoSoft : C.muted)),
                      if (i == index)
                        Padding(
                          padding: const EdgeInsets.only(left: 7),
                          child: Text(_items[i].$2, softWrap: false, overflow: TextOverflow.clip,
                              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5, color: C.indigoSoft))),
                    ]),
                  ),
                ),
              ),
          ]),
        ),
      );
}

// ============================================================ Tab 1: Chats
class ChatsTab extends StatelessWidget {
  const ChatsTab({super.key, required this.onGoRadar});
  final VoidCallback onGoRadar;

  @override
  Widget build(BuildContext context) {
    final mesh = context.watch<MeshService>();
    final list = mesh.peers.values
        .where((p) => mesh.thread(p.id).isNotEmpty || p.online || p.relayed)
        .toList()
      ..sort((a, b) => (mesh.lastMessage(b.id)?.ts ?? b.lastSeen)
          .compareTo(mesh.lastMessage(a.id)?.ts ?? a.lastSeen));

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 16, 8),
        child: Row(children: [
          Image.asset('assets/logo.png', width: 34, height: 34, cacheWidth: 102),
          const SizedBox(width: 10),
          const Expanded(
            child: Text('OffChat',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, letterSpacing: -.5))),
          const MeshChip(),
        ]),
      ),
      const MeshBanner(),
      Expanded(
        child: list.isEmpty
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(32),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Container(
                      width: 84, height: 84,
                      decoration: const BoxDecoration(color: C.surface, shape: BoxShape.circle),
                      child: const Icon(Icons.hub_outlined, size: 40, color: C.indigoSoft)),
                    const SizedBox(height: 16),
                    const Text('No conversations yet',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 6),
                    const Text('Nearby OffChat users connect automatically.\nOpen Radar to see who is in range.',
                        textAlign: TextAlign.center, style: TextStyle(color: C.muted)),
                    const SizedBox(height: 16),
                    FilledButton.icon(
                      onPressed: onGoRadar, icon: const Icon(Icons.radar), label: const Text('Open Radar')),
                  ]),
                ),
              )
            : ListView.builder(
                itemCount: list.length,
                itemBuilder: (_, i) => _ChatTile(peer: list[i]),
              ),
      ),
    ]);
  }
}

class _ChatTile extends StatelessWidget {
  const _ChatTile({required this.peer});
  final Peer peer;

  @override
  Widget build(BuildContext context) {
    final mesh = context.watch<MeshService>();
    final last = mesh.lastMessage(peer.id);
    final unread = mesh.unread(peer.id);
    return InkWell(
      onTap: () => Navigator.push(
          context, MaterialPageRoute(builder: (_) => ChatScreen(peerId: peer.id))),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Row(children: [
          PeerAvatar(name: peer.name, color: peer.color, online: peer.online, size: 52, heroTag: 'av_${peer.id}'),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(peer.name,
                  maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              const SizedBox(height: 3),
              Row(children: [
                if (last != null && last.outgoing && last.type != 'call') ...[
                  Ticks(last.status), const SizedBox(width: 4)],
                if (last?.type == 'image' || last?.type == 'voice' || last?.type == 'video' || last?.type == 'call') ...[
                  Icon(last!.type == 'voice' ? Icons.mic : last.type == 'video' ? Icons.videocam : last.type == 'call' ? Icons.call : Icons.photo, size: 15, color: C.muted),
                  const SizedBox(width: 4)],
                Expanded(
                  child: Text(
                    last == null
                        ? (peer.online ? 'Connected — say hello' : peer.relayed ? 'Reachable via mesh' : 'Offline')
                        : (last.type == 'voice' ? 'Voice message' : last.type == 'video' ? 'Video' : last.body.isEmpty && last.type == 'image' ? 'Photo' : last.body),
                    maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: C.muted, fontSize: 13.5)),
                ),
              ]),
            ]),
          ),
          const SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(last == null ? '' : hm(last.ts),
                style: TextStyle(fontSize: 12, color: unread > 0 ? C.indigoSoft : C.muted)),
            const SizedBox(height: 6),
            if (unread > 0)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                decoration: BoxDecoration(color: C.indigo, borderRadius: BorderRadius.circular(99)),
                child: Text('$unread',
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)))
            else
              const SizedBox(height: 20),
          ]),
        ]),
      ),
    );
  }
}
