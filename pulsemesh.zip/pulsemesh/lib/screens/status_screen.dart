import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../mesh_service.dart';
import '../models.dart';
import '../premium.dart';
import '../theme.dart';
import '../widgets.dart';

// ============================================================ Tab: Status (24-hour updates)
class StatusTab extends StatelessWidget {
  const StatusTab({super.key});

  @override
  Widget build(BuildContext context) {
    final mesh = context.watch<MeshService>();
    final mine = mesh.statusesOf(mesh.myId);
    int lastTs(String a) => mesh.statusesOf(a).last.ts;
    final authors = mesh.statusAuthors.where((a) => a != kOfficialId).toList()
      ..sort((a, b) => lastTs(b).compareTo(lastTs(a)));
    final official = mesh.statusesOf(kOfficialId).isNotEmpty;
    final unseen = authors.where(mesh.hasUnviewed).toList();
    final seen = authors.where((a) => !mesh.hasUnviewed(a)).toList();

    return ListView(padding: const EdgeInsets.only(bottom: 24), children: [
      const Padding(
        padding: EdgeInsets.fromLTRB(20, 16, 16, 8),
        child: Text('Status',
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, letterSpacing: -.5))),
      const MeshBanner(),
      // ---- my status
      InkWell(
        onTap: () => mine.isEmpty ? _add(context) : _open(context, mesh.myId),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Row(children: [
            Stack(clipBehavior: Clip.none, children: [
              StatusRing(
                count: mine.length, unseen: mine.length,
                child: PeerAvatar(name: mesh.myName, color: mesh.myColor, size: 50)),
              Positioned(
                right: 0, bottom: 0,
                child: Container(
                  width: 22, height: 22,
                  decoration: BoxDecoration(
                      color: C.indigo, shape: BoxShape.circle, border: Border.all(color: C.bg, width: 2)),
                  child: const Icon(Icons.add, size: 15)),
              ),
            ]),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('My status', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                Text(
                  mine.isEmpty ? 'Tap to add a status update' : '${mine.length} update${mine.length > 1 ? 's' : ''} · ${ago(mine.last.ts)}',
                  style: const TextStyle(color: C.muted, fontSize: 13.5)),
              ]),
            ),
            if (mine.isNotEmpty)
              IconButton(onPressed: () => _add(context), icon: const Icon(Icons.add_circle_outline, color: C.indigoSoft)),
          ]),
        ),
      ),
      if (official) ...[_section('From OffChat'), const _Row(authorId: kOfficialId)],
      if (unseen.isNotEmpty) ...[_section('Recent updates'), for (final a in unseen) _Row(authorId: a)],
      if (seen.isNotEmpty) ...[_section('Viewed updates'), for (final a in seen) _Row(authorId: a)],
      if (authors.isEmpty && !official)
        const Padding(
          padding: EdgeInsets.fromLTRB(24, 32, 24, 8),
          child: Text('No updates from nearby people yet.\nStatuses appear here when connected peers post them.',
              textAlign: TextAlign.center, style: TextStyle(color: C.muted))),
      const Padding(
        padding: EdgeInsets.fromLTRB(24, 20, 24, 0),
        child: Text(
          'Your status is shared with people currently connected to you over Bluetooth/Wi-Fi, and disappears after 24 hours. Photos are sent in original quality.',
          textAlign: TextAlign.center, style: TextStyle(color: C.muted, fontSize: 12))),
    ]);
  }

  Widget _section(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 4),
        child: Text(t, style: const TextStyle(color: C.muted, fontWeight: FontWeight.w700, fontSize: 13)));
}

void _open(BuildContext context, String authorId) => Navigator.push(
    context, MaterialPageRoute(fullscreenDialog: true, builder: (_) => StatusViewer(authorId: authorId)));

Future<void> _add(BuildContext context) async {
  final choice = await showModalBottomSheet<String>(
    context: context,
    backgroundColor: C.surface,
    builder: (_) => SafeArea(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        ListTile(leading: const Icon(Icons.text_fields), title: const Text('Text'),
            onTap: () => Navigator.pop(context, 'text')),
        ListTile(leading: const Icon(Icons.photo_library_outlined), title: const Text('Photo from gallery'),
            subtitle: const Text('Original quality'), onTap: () => Navigator.pop(context, 'gallery')),
        ListTile(leading: const Icon(Icons.photo_camera_outlined), title: const Text('Camera'),
            onTap: () => Navigator.pop(context, 'camera')),
      ]),
    ),
  );
  if (choice == null || !context.mounted) return;
  File? img;
  if (choice != 'text') {
    final x = await ImagePicker()
        .pickImage(source: choice == 'camera' ? ImageSource.camera : ImageSource.gallery); // untouched original
    if (x == null || !context.mounted) return;
    img = File(x.path);
  }
  if (!context.mounted) return;
  await Navigator.push(
      context, MaterialPageRoute(fullscreenDialog: true, builder: (_) => StatusComposer(image: img)));
}

class _Row extends StatelessWidget {
  const _Row({required this.authorId});
  final String authorId;
  @override
  Widget build(BuildContext context) {
    final mesh = context.watch<MeshService>();
    final peer = mesh.peers[authorId];
    final items = mesh.statusesOf(authorId);
    if (peer == null || items.isEmpty) return const SizedBox.shrink();
    final unseenCount = items.where((s) => !s.viewed).length;
    return InkWell(
      onTap: () => _open(context, authorId),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Row(children: [
          StatusRing(
              count: items.length, unseen: unseenCount,
              child: authorId == kOfficialId
                  ? ClipOval(child: Image.asset('assets/logo.png', width: 50, height: 50))
                  : PeerAvatar(name: peer.name, color: peer.color, size: 50)),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(peer.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              Text(ago(items.last.ts), style: const TextStyle(color: C.muted, fontSize: 13.5)),
            ]),
          ),
        ]),
      ),
    );
  }
}

/// Segmented ring: one arc per update; unseen arcs are indigo, seen ones grey.
class StatusRing extends StatelessWidget {
  const StatusRing({super.key, required this.count, required this.unseen, required this.child});
  final int count, unseen;
  final Widget child;
  @override
  Widget build(BuildContext context) => SizedBox(
        width: 62, height: 62,
        child: CustomPaint(
          painter: _RingPainter(count, unseen),
          child: Center(child: child),
        ),
      );
}

class _RingPainter extends CustomPainter {
  _RingPainter(this.n, this.unseen);
  final int n, unseen;
  @override
  void paint(Canvas canvas, Size size) {
    if (n == 0) return;
    final rect = Rect.fromLTWH(2, 2, size.width - 4, size.height - 4);
    final gap = n == 1 ? 0.0 : .22;
    final sweep = 2 * math.pi / n - gap;
    for (var i = 0; i < n; i++) {
      // the newest `unseen` segments are highlighted
      final isNew = i >= n - unseen;
      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..strokeCap = StrokeCap.round
        ..color = isNew ? C.indigo : C.line;
      canvas.drawArc(rect, -math.pi / 2 + i * (sweep + gap) + gap / 2, n == 1 ? 2 * math.pi : sweep, false, paint);
    }
  }

  @override
  bool shouldRepaint(_RingPainter o) => o.n != n || o.unseen != unseen;
}

// ============================================================ Full-screen viewer
class StatusViewer extends StatefulWidget {
  const StatusViewer({super.key, required this.authorId});
  final String authorId;
  @override
  State<StatusViewer> createState() => _StatusViewerState();
}

class _StatusViewerState extends State<StatusViewer> with SingleTickerProviderStateMixin {
  late final MeshService _mesh;
  late final List<StatusItem> _items;
  late final AnimationController _ctl = AnimationController(vsync: this);
  int _i = 0;

  @override
  void initState() {
    super.initState();
    _mesh = context.read<MeshService>();
    _items = _mesh.statusesOf(widget.authorId);
    if (_items.isEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) => Navigator.pop(context));
      return;
    }
    final firstNew = _items.indexWhere((s) => !s.viewed);
    _i = firstNew < 0 ? 0 : firstNew; // like WhatsApp: resume at first unseen
    _ctl.addStatusListener((s) {
      if (s == AnimationStatus.completed) _next();
    });
    _play();
  }

  @override
  void dispose() {
    _ctl.dispose();
    super.dispose();
  }

  void _play() {
    final s = _items[_i];
    WidgetsBinding.instance.addPostFrameCallback((_) => _mesh.markStatusViewed(s)); // sends "seen" receipt
    _ctl.duration = Duration(seconds: s.kind == 'text' ? 6 : 5);
    _ctl.forward(from: 0);
    setState(() {});
  }

  void _next() {
    if (_i < _items.length - 1) {
      _i++;
      _play();
    } else if (mounted) {
      Navigator.pop(context);
    }
  }

  void _prev() {
    if (_i > 0) _i--;
    _play();
  }

  Future<void> _viewers(StatusItem s) async {
    _ctl.stop();
    final v = _mesh.viewersOf(s.id);
    await showModalBottomSheet(
      context: context,
      backgroundColor: C.surface,
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Viewed by ${v.length}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            if (v.isEmpty)
              const Text('Nobody yet. Views arrive when the person is connected.', style: TextStyle(color: C.muted)),
            for (final e in v.entries)
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: PeerAvatar(
                    name: _mesh.peers[e.key]?.name ?? '?', color: _mesh.peers[e.key]?.color ?? 0, size: 40),
                title: Text(_mesh.peers[e.key]?.name ?? 'Unknown'),
                subtitle: Text(ago(e.value), style: const TextStyle(color: C.muted)),
              ),
          ]),
        ),
      ),
    );
    if (mounted) _ctl.forward();
  }

  @override
  Widget build(BuildContext context) {
    if (_items.isEmpty) return const Scaffold(backgroundColor: Colors.black);
    final s = _items[_i];
    final own = s.authorId == _mesh.myId;
    final peer = _mesh.peers[s.authorId];
    final name = own ? 'My status' : (peer?.name ?? 'Unknown');
    final w = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapUp: (d) => d.localPosition.dx < w / 3 ? _prev() : _next(),
        onLongPressStart: (_) => _ctl.stop(),   // hold to pause
        onLongPressEnd: (_) => _ctl.forward(),
        onVerticalDragEnd: (d) {
          if ((d.primaryVelocity ?? 0) > 300) Navigator.pop(context);
        },
        child: Stack(fit: StackFit.expand, children: [
          _content(s),
          Positioned(
            top: 0, left: 0, right: 0,
            child: Container(
              decoration: const BoxDecoration(
                  gradient: LinearGradient(
                      begin: Alignment.topCenter, end: Alignment.bottomCenter,
                      colors: [Colors.black54, Colors.transparent])),
              child: SafeArea(
                bottom: false,
                child: Column(children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
                    child: AnimatedBuilder(
                      animation: _ctl,
                      builder: (_, __) => Row(children: [
                        for (var k = 0; k < _items.length; k++)
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 2),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(2),
                                child: LinearProgressIndicator(
                                  value: k < _i ? 1 : k == _i ? _ctl.value : 0,
                                  minHeight: 3, color: Colors.white, backgroundColor: Colors.white30),
                              ),
                            ),
                          ),
                      ]),
                    ),
                  ),
                  Row(children: [
                    IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => Navigator.pop(context)),
                    PeerAvatar(
                        name: own ? _mesh.myName : (peer?.name ?? '?'),
                        color: own ? _mesh.myColor : (peer?.color ?? 0), size: 36),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(name, style: const TextStyle(fontWeight: FontWeight.w700)),
                        Text(ago(s.ts), style: const TextStyle(fontSize: 12, color: Colors.white70)),
                      ]),
                    ),
                    if (own)
                      IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () async {
                          _ctl.stop();
                          await _mesh.deleteStatus(s);
                          if (mounted) Navigator.pop(context);
                        }),
                  ]),
                ]),
              ),
            ),
          ),
          if (s.kind == 'image' && s.text.isNotEmpty)
            Positioned(
              left: 0, right: 0, bottom: own ? 64 : 0,
              child: Container(
                color: Colors.black54,
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
                child: SafeArea(top: false,
                    child: Text(s.text, textAlign: TextAlign.center, style: const TextStyle(fontSize: 17))))),
          if (own)
            Positioned(
              left: 0, right: 0, bottom: 0,
              child: SafeArea(
                child: Center(
                  child: TextButton.icon(
                    onPressed: () => _viewers(s),
                    icon: const Icon(Icons.visibility_outlined, color: Colors.white),
                    label: Text('${_mesh.viewersOf(s.id).length}', style: const TextStyle(color: Colors.white)))),
              ),
            ),
        ]),
      ),
    );
  }

  Widget _content(StatusItem s) {
    if (s.kind == 'text') {
      return Container(
        color: Color.lerp(C.avatar(s.color), Colors.black, .25),
        alignment: Alignment.center,
        padding: const EdgeInsets.all(32),
        child: Text(s.text,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w600, height: 1.3)),
      );
    }
    return Container(
      color: Colors.black,
      alignment: Alignment.center,
      // original file, shown at full resolution
      child: Image.file(File(s.path!),
          fit: BoxFit.contain, filterQuality: FilterQuality.high,
          errorBuilder: (_, __, ___) => const Icon(Icons.broken_image, size: 48, color: C.muted)),
    );
  }
}

// ============================================================ Composer (photo + caption, or colored text)
class StatusComposer extends StatefulWidget {
  const StatusComposer({super.key, this.image});
  final File? image;
  @override
  State<StatusComposer> createState() => _StatusComposerState();
}

class _StatusComposerState extends State<StatusComposer> {
  final _text = TextEditingController();
  int _color = 0;

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  Future<void> _post() async {
    final mesh = context.read<MeshService>();
    final t = _text.text.trim();
    if (widget.image != null) {
      await mesh.postStatusImage(widget.image!, caption: t);
    } else {
      if (t.isEmpty) return;
      await mesh.postStatusText(t, _color);
    }
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final isImg = widget.image != null;
    return Scaffold(
      backgroundColor: isImg ? Colors.black : Color.lerp(C.avatar(_color), Colors.black, .25),
      body: SafeArea(
        child: Column(children: [
          Row(children: [
            IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(context)),
            const Spacer(),
            if (!isImg)
              IconButton(
                icon: const Icon(Icons.palette_outlined),
                onPressed: () => setState(() => _color = (_color + 1) % C.avatars.length)),
          ]),
          Expanded(
            child: isImg
                ? Center(child: Image.file(widget.image!, fit: BoxFit.contain, filterQuality: FilterQuality.high))
                : Padding(
                    padding: const EdgeInsets.all(28),
                    child: Center(
                      child: TextField(
                        controller: _text, autofocus: true, maxLines: null, maxLength: 700,
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w600),
                        decoration: const InputDecoration(
                            border: InputBorder.none, counterText: '', hintText: 'Type a status',
                            hintStyle: TextStyle(color: Colors.white54)),
                      ),
                    ),
                  ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
            child: Row(children: [
              if (isImg)
                Expanded(
                  child: TextField(
                    controller: _text, maxLength: 300,
                    decoration: InputDecoration(
                      counterText: '', hintText: 'Add a caption…', filled: true, fillColor: Colors.white12,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none)),
                  ),
                )
              else
                const Spacer(),
              const SizedBox(width: 10),
              FloatingActionButton(
                onPressed: _post, backgroundColor: C.indigo, foregroundColor: Colors.white,
                child: const Icon(Icons.send_rounded)),
            ]),
          ),
        ]),
      ),
    );
  }
}
