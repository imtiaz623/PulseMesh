import 'package:flutter/material.dart';

import '../premium.dart';
import '../theme.dart';
import 'privacy_screen.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  static const _points = <(IconData, String, String)>[
    (Icons.wifi_off_rounded, 'Works without internet', 'Bluetooth and Wi-Fi connect nearby phones directly.'),
    (Icons.hub_rounded, 'Mesh relay', 'Texts hop through other phones to reach people out of range.'),
    (Icons.lock_outline_rounded, 'Private by design', 'No account, no phone number, no server. Chats stay on your phone.'),
    (Icons.call_rounded, 'Calls and media', 'Voice calls, photos, videos and voice notes.'),
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('About OffChat')),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          const SizedBox(height: 10),
          Center(
            child: ClipOval(child: Image.asset('assets/logo.png', width: 110, height: 110)),
          ),
          const SizedBox(height: 14),
          const Center(child: Text('OffChat', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: -.5))),
          const SizedBox(height: 2),
          const Center(child: Text('Version $kAppVersion', style: TextStyle(color: C.muted))),
          const SizedBox(height: 6),
          const Center(child: Text('Chat and call without internet', style: TextStyle(color: C.muted))),
          const SizedBox(height: 22),
          for (final p in _points)
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Container(
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(color: C.surface, borderRadius: BorderRadius.circular(12)),
                child: Icon(p.$1, color: C.indigoSoft, size: 22),
              ),
              title: Text(p.$2, style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(p.$3, style: const TextStyle(color: C.muted, height: 1.3)),
            ),
          const SizedBox(height: 10),
          const Divider(),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.privacy_tip_outlined),
            title: const Text('Privacy & data'),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PrivacyScreen())),
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.description_outlined),
            title: const Text('Open-source licences'),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => showLicensePage(
              context: context,
              applicationName: 'OffChat',
              applicationVersion: kAppVersion,
              applicationIcon: Padding(
                padding: const EdgeInsets.all(8),
                child: ClipOval(child: Image.asset('assets/logo.png', width: 56, height: 56))),
            ),
          ),
          const SizedBox(height: 14),
          const Center(
            child: Text('Your messages never leave the phones in the conversation.',
                textAlign: TextAlign.center, style: TextStyle(color: C.muted, fontSize: 12.5)),
          ),
        ]),
      );
}
