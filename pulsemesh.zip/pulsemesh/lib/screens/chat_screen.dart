import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:record/record.dart';

import '../call_service.dart';
import '../mesh_service.dart';
import '../models.dart';
import '../premium.dart';
import '../theme.dart';
import '../wallpapers.dart';
import '../widgets.dart';
import 'contact_screen.dart';
import 'wallpaper_picker.dart';
import 'premium_screen.dart';
import 'video_screen.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.peerId});
  final String peerId;
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _ctl = TextEditingController();
  final _rec = AudioRecorder();
  late final MeshService _mesh;
  bool _hasText = false, _recording = false, _cancel = false;
  DateTime? _recStart;
  Timer? _tick;
  int _secs = 0;
  Future<void>? _startFuture;

  @override
  void initState() {
    super.initState();
    _mesh = context.read<MeshService>();
    _mesh.openPeerId = widget.peerId;
    _ctl.addListener(() {
      final h = _ctl.text.trim().isNotEmpty;
      if (h != _hasText) setState(() => _hasText = h);
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _mesh.markRead(widget.peerId);
      _mesh.ensureShotWatch(); // so screenshots of this chat can be reported
    });
  }

  @override
  void dispose() {
    _mesh.openPeerId = null;
    _tick?.cancel();
    _rec.dispose();
    _ctl.dispose();
    super.dispose();
  }

  void _toast(String t) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));
  }

  void _send() {
    final t = _ctl.text;
    if (t.trim().isEmpty) return;
    _ctl.clear();
    _mesh.sendText(widget.peerId, t);
  }

  // ---------------------------------------------------------------- photos (original quality)
  Future<void> _attach() async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: C.surface,
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.photo_library_outlined),
            title: const Text('Photos'),
            subtitle: const Text('Sent in original quality, no compression'),
            onTap: () => Navigator.pop(context, 'photos')),
          ListTile(
            leading: const Icon(Icons.photo_camera_outlined),
            title: const Text('Camera'),
            onTap: () => Navigator.pop(context, 'camera')),
          ListTile(
            leading: const Icon(Icons.video_library_outlined),
            title: const Text('Video'),
            subtitle: const Text('Pick a video from your gallery'),
            onTap: () => Navigator.pop(context, 'video')),
          ListTile(
            leading: const Icon(Icons.videocam_outlined),
            title: const Text('Record video'),
            onTap: () => Navigator.pop(context, 'record')),
        ]),
      ),
    );
    if (choice == null) return;
    try {
      await _pick(choice);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Could not open the camera or gallery. Check the app permissions.')));
      }
    }
  }

  Future<void> _pick(String choice) async {
    final picker = ImagePicker();
    // no maxWidth / imageQuality => the file is picked untouched
    if (choice == 'photos') {
      for (final x in await picker.pickMultiImage()) {
        await _mesh.sendImage(widget.peerId, File(x.path));
      }
    } else if (choice == 'camera') {
      final x = await picker.pickImage(source: ImageSource.camera);
      if (x != null) await _mesh.sendImage(widget.peerId, File(x.path));
    } else if (choice == 'video') {
      final v = await picker.pickVideo(source: ImageSource.gallery);
      if (v != null) await _mesh.sendVideo(widget.peerId, File(v.path));
    } else {
      final v = await picker.pickVideo(source: ImageSource.camera, maxDuration: const Duration(minutes: 2));
      if (v != null) await _mesh.sendVideo(widget.peerId, File(v.path));
    }
  }

  // ---------------------------------------------------------------- voice (hold to record)
  Future<void> _startRec() async {
    if (!await _rec.hasPermission()) {
      _toast('Allow microphone access to send voice messages.');
      return;
    }
    final dir = await getTemporaryDirectory();
    final path = p.join(dir.path, 'rec_${DateTime.now().millisecondsSinceEpoch}.m4a');
    HapticFeedback.mediumImpact();
    await _rec.start(
      const RecordConfig(
        encoder: AudioEncoder.aacLc, bitRate: 128000, sampleRate: 44100, numChannels: 1,
        autoGain: true, echoCancel: true, noiseSuppress: true, // clearer speech
      ),
      path: path,
    );
    _recStart = DateTime.now();
    _cancel = false;
    _secs = 0;
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _secs = DateTime.now().difference(_recStart!).inSeconds);
    });
    setState(() => _recording = true);
  }

  Future<void> _endRec() async {
    await _startFuture; // finger lifted before recording had fully started
    if (!_recording) return;
    _tick?.cancel();
    final ms = DateTime.now().difference(_recStart!).inMilliseconds;
    setState(() => _recording = false);
    final path = await _rec.stop();
    if (path == null) return;
    if (_cancel || ms < 800) {
      try {
        File(path).deleteSync();
      } catch (_) {}
      if (!_cancel) _toast('Hold the mic button to record.');
      return;
    }
    HapticFeedback.lightImpact();
    await _mesh.sendVoice(widget.peerId, path, ms);
  }

  String _mmss(int s) => '${(s ~/ 60).toString().padLeft(2, '0')}:${(s % 60).toString().padLeft(2, '0')}';

  Widget _inputBar() {
    final mic = GestureDetector(
      onLongPressStart: (_) => _startFuture = _startRec(),
      onLongPressMoveUpdate: (d) {
        final c = d.offsetFromOrigin.dx < -90;
        if (c != _cancel) setState(() => _cancel = c);
      },
      onLongPressEnd: (_) => _endRec(),
      child: AnimatedScale(
        scale: _recording ? 1.35 : 1,
        duration: const Duration(milliseconds: 150),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
              color: _recording ? const Color(0xFFEF4444) : C.indigo, shape: BoxShape.circle),
          child: const Icon(Icons.mic, size: 22)),
      ),
    );
    return Container(
      color: C.surface,
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
      child: SafeArea(
        top: false,
        child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          if (_recording)
            Expanded(
              child: Container(
                height: 48,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(color: C.bg, borderRadius: BorderRadius.circular(24)),
                child: Row(children: [
                  const Icon(Icons.fiber_manual_record, size: 14, color: Color(0xFFEF4444)),
                  const SizedBox(width: 8),
                  Text(_mmss(_secs), style: const TextStyle(fontWeight: FontWeight.w600)),
                  const Spacer(),
                  Text(_cancel ? 'Release to cancel' : '‹  Slide to cancel',
                      style: TextStyle(color: _cancel ? const Color(0xFFEF4444) : C.muted)),
                ]),
              ),
            )
          else ...[
            IconButton(onPressed: _attach, icon: const Icon(Icons.attach_file, color: C.muted)),
            Expanded(
              child: TextField(
                controller: _ctl, minLines: 1, maxLines: 5, maxLength: 1000,
                textCapitalization: TextCapitalization.sentences,
                style: const TextStyle(fontSize: 16.5),
                decoration: InputDecoration(
                  counterText: '', hintText: 'Message', filled: true, fillColor: C.bg,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none)),
              ),
            ),
          ],
          const SizedBox(width: 6),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 180),
            transitionBuilder: (child, a) => ScaleTransition(scale: a, child: FadeTransition(opacity: a, child: child)),
            child: (_hasText && !_recording)
                ? Material(
                    key: const ValueKey('send'),
                    color: C.indigo, shape: const CircleBorder(),
                    child: InkWell(
                      customBorder: const CircleBorder(), onTap: _send,
                      child: const Padding(padding: EdgeInsets.all(12), child: Icon(Icons.send_rounded, size: 22))),
                  )
                : KeyedSubtree(key: const ValueKey('mic'), child: mic),
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final mesh = context.watch<MeshService>();
    final peer = mesh.peers[widget.peerId];
    if (peer == null) return const Scaffold(body: Center(child: Text('Peer removed')));
    final msgs = mesh.thread(peer.id);
    if (mesh.unread(peer.id) > 0) {
      WidgetsBinding.instance.addPostFrameCallback((_) => mesh.markRead(peer.id));
    }
    final (statusText, statusColor) = peer.online
        ? ('Active now', C.online)
        : peer.relayed
            ? ('Via mesh · ${peer.hops} hops', C.indigoSoft)
            : peer.connecting
            ? ('Connecting…', C.indigoSoft)
            : peer.discovered
                ? ('In range', C.indigoSoft)
                : peer.lastSeen > 0
                    ? ('Last seen ${lastSeenText(peer.lastSeen)}', C.muted)
                    : ('Offline', C.muted);

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.call_rounded),
            onPressed: peer.online ? () => context.read<CallService>().start(peer.id) : null),
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert_rounded),
            color: C.surface2,
            onSelected: (v) {
              if (v == 'contact') {
                Navigator.push(context, MaterialPageRoute(builder: (_) => ContactScreen(peerId: peer.id, fromChat: true)));
              } else if (v == 'wallpaper') {
                showWallpaperPicker(context, peerId: peer.id);
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'contact', child: Text('Contact info')),
              PopupMenuItem(value: 'wallpaper', child: Text('Wallpaper')),
            ],
          ),
        ],
        title: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => Navigator.push(
              context, MaterialPageRoute(builder: (_) => ContactScreen(peerId: peer.id, fromChat: true))),
          child: Row(children: [
          PeerAvatar(name: peer.name, color: peer.color, photo: _mesh.avatarOf(peer.id), online: peer.online, size: 40, heroTag: 'av_${peer.id}'),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(peer.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
              Text(statusText, style: TextStyle(fontSize: 12.5, color: statusColor)),
            ]),
          ),
        ])),
      ),
      body: Stack(children: [
        Positioned.fill(
          child: RepaintBoundary(
            child: wallpaperLayer(_mesh.wallpaperOf(widget.peerId),
                fallback: const CustomPaint(painter: DotsPainter())))),
        Positioned.fill(child: Column(children: [
        _SecureBadge(peer: peer),
        if (!peer.online)
          Container(
            width: double.infinity, color: C.surface,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text(
              peer.relayed
                  ? 'Reaching this person through nearby phones (${peer.hops} hops). Text is relayed; photos, voice and calls need a direct link.'
                  : 'Out of range. Messages wait in the queue and are delivered automatically when this peer reconnects.',
              style: const TextStyle(fontSize: 12.5, color: C.muted)),
          ),
        Expanded(
          child: msgs.isEmpty
              ? const Center(child: Text('No messages yet', style: TextStyle(color: C.muted)))
              : ListView.builder(
                  reverse: true,
                  padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
                  itemCount: msgs.length,
                  itemBuilder: (_, i) {
                    final m = msgs[msgs.length - 1 - i];
                    return _Bubble(m: m, progress: mesh.progress[m.id]);
                  },
                ),
        ),
        _inputBar(),
        ])),
      ]),
    );
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble({required this.m, this.progress});
  final Message m;
  final double? progress;

  @override
  Widget build(BuildContext context) {
    if (m.type == 'call' || m.type == 'note') return _callChip();
    final gone = m.deleted && m.body.isEmpty && m.path == null;
    final fresh = DateTime.now().millisecondsSinceEpoch - m.ts < 1500; // animate only brand-new bubbles
    final Widget w = gone
        ? _deletedBubble()
        : !fresh
            ? _body(context)
            : TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: 1),
                duration: const Duration(milliseconds: 240),
                curve: Curves.easeOutCubic,
                builder: (_, t, child) => Opacity(
                    opacity: t, child: Transform.translate(offset: Offset(0, (1 - t) * 12), child: child)),
                child: _body(context),
              );
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onLongPress: () => _menu(context),
      child: w,
    );
  }

  Widget _deletedBubble() => Align(
        alignment: m.outgoing ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 3),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
              color: C.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: C.line)),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.block_rounded, size: 15, color: C.muted),
            const SizedBox(width: 6),
            Text(m.outgoing ? 'You deleted this message' : 'This message was deleted',
                style: const TextStyle(fontSize: 14, fontStyle: FontStyle.italic, color: C.muted)),
          ]),
        ),
      );

  /// Long-press menu: copy, delete for me (free), delete for everyone (Premium).
  void _menu(BuildContext context) {
    final mesh = context.read<MeshService>();
    final canAll = m.outgoing && !m.deleted;
    final premium = mesh.premium.has(Feature.deleteForEveryone);
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: C.surface,
      builder: (sheet) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          if (m.type == 'text' && m.body.isNotEmpty)
            ListTile(
              leading: const Icon(Icons.copy_rounded),
              title: const Text('Copy'),
              onTap: () {
                Clipboard.setData(ClipboardData(text: m.body));
                Navigator.pop(sheet);
              }),
          ListTile(
            leading: const Icon(Icons.delete_outline_rounded),
            title: const Text('Delete for me'),
            onTap: () {
              Navigator.pop(sheet);
              mesh.deleteForMe(m);
            }),
          if (canAll)
            ListTile(
              leading: const Icon(Icons.delete_forever_outlined, color: Color(0xFFF87171)),
              title: const Text('Delete for everyone'),
              trailing: premium ? null : const Icon(Icons.lock_rounded, size: 18, color: C.indigoSoft),
              onTap: () {
                Navigator.pop(sheet);
                if (premium) {
                  mesh.deleteForEveryone(m);
                } else {
                  openPremium(context, reason: 'Delete for everyone is a Premium feature.');
                }
              }),
        ]),
      ),
    );
  }

  Widget _callChip() {
    final missed = m.body.startsWith('Missed');
    return Center(
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
            color: C.surface, borderRadius: BorderRadius.circular(99), border: Border.all(color: C.line)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(
              m.type == 'note'
                  ? Icons.camera_alt_outlined
                  : Icons.call_rounded,
              size: 15,
              color: m.type == 'note'
                  ? const Color(0xFFFBBF24)
                  : (missed ? const Color(0xFFF87171) : C.indigoSoft)),
          const SizedBox(width: 6),
          Text('${m.body} · ${hm(m.ts)}', style: const TextStyle(fontSize: 12.5, color: C.muted)),
        ]),
      ),
    );
  }

  Widget _body(BuildContext context) {
    final out = m.outgoing;
    final uploading = out && m.status != MsgStatus.delivered && progress != null;
    return Align(
      alignment: out ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 3),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .8),
        padding: const EdgeInsets.fromLTRB(12, 8, 10, 6),
        decoration: BoxDecoration(
          color: out ? null : C.surface2,
          gradient: out
              ? const LinearGradient(
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                  colors: [Color(0xFF7C83FF), Color(0xFF5457E8)])
              : null,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(18), topRight: const Radius.circular(18),
            bottomLeft: Radius.circular(out ? 18 : 4), bottomRight: Radius.circular(out ? 4 : 18)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          if (m.deleted)
            const Padding(
              padding: EdgeInsets.only(bottom: 4),
              child: Text('Deleted by sender', style: TextStyle(fontSize: 11, color: Color(0xFFFCA5A5)))),
          if (m.type == 'image' && m.path != null) _image(context),
          if (m.type == 'video' && m.path != null) _video(context),
          if (m.type == 'voice' && m.path != null)
            VoicePlayer(key: ValueKey(m.id), path: m.path!, durMs: m.dur, out: out),
          if (uploading)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                SizedBox(
                  width: 120,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                        value: progress, minHeight: 4, color: Colors.white, backgroundColor: Colors.white24)),
                ),
                const SizedBox(width: 8),
                Text('${((progress ?? 0) * 100).round()}%',
                    style: const TextStyle(fontSize: 11, color: Colors.white70)),
              ]),
            ),
          if (m.body.isNotEmpty)
            Padding(
              padding: EdgeInsets.only(top: m.type == 'text' ? 0 : 6),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(m.body, style: const TextStyle(fontSize: 16.5, height: 1.35)),
              ),
            ),
          const SizedBox(height: 3),
          Row(mainAxisSize: MainAxisSize.min, children: [
            if (out && m.status == MsgStatus.queued)
              const Padding(
                padding: EdgeInsets.only(right: 5),
                child: Text('Sending…', style: TextStyle(fontSize: 11, color: Colors.white70))),
            Text(hm(m.ts), style: TextStyle(fontSize: 11, color: out ? Colors.white70 : C.muted)),
            if (out) ...[const SizedBox(width: 4), Ticks(m.status)],
          ]),
        ]),
      ),
    );
  }

  String _size(int b) =>
      b >= 1048576 ? '${(b / 1048576).toStringAsFixed(1)} MB' : '${(b / 1024).round()} KB';

  Widget _video(BuildContext context) {
    var size = 0;
    try {
      size = File(m.path!).lengthSync();
    } catch (_) {}
    return GestureDetector(
      onTap: () => Navigator.push(
          context, MaterialPageRoute(builder: (_) => VideoScreen(path: m.path!))),
      child: Container(
        width: 230, height: 140,
        decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(12)),
        child: Stack(alignment: Alignment.center, children: [
          const Icon(Icons.play_circle_fill_rounded, size: 54, color: Colors.white),
          Positioned(
            left: 10, bottom: 8,
            child: Row(children: [
              const Icon(Icons.videocam_rounded, size: 14, color: Colors.white70),
              const SizedBox(width: 4),
              Text(_size(size), style: const TextStyle(fontSize: 12, color: Colors.white70)),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _image(BuildContext context) => GestureDetector(
        onTap: () => showDialog(
          context: context,
          builder: (_) => Dialog.fullscreen(
            backgroundColor: Colors.black,
            child: Stack(children: [
              // full-resolution original, pinch to zoom
              Center(child: InteractiveViewer(
                  maxScale: 8, child: Image.file(File(m.path!), filterQuality: FilterQuality.high))),
              SafeArea(child: IconButton(
                  icon: const Icon(Icons.close), onPressed: () => Navigator.pop(context))),
            ]),
          ),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Image.file(File(m.path!),
              width: 250, fit: BoxFit.cover, cacheWidth: 600, filterQuality: FilterQuality.high,
              errorBuilder: (_, __, ___) => const SizedBox(
                  width: 250, height: 120, child: Icon(Icons.broken_image, color: C.muted))),
        ),
      );
}

/// WhatsApp-style voice bubble: play/pause, waveform scrubber, duration, 1x/1.5x/2x speed.
class VoicePlayer extends StatefulWidget {
  const VoicePlayer({super.key, required this.path, required this.durMs, required this.out});
  final String path;
  final int durMs;
  final bool out;
  @override
  State<VoicePlayer> createState() => _VoicePlayerState();
}

class _VoicePlayerState extends State<VoicePlayer> {
  static AudioPlayer? _current; // only one voice plays at a time
  static const _w = 117.0;
  final _p = AudioPlayer();
  bool _playing = false;
  Duration _pos = Duration.zero;
  late Duration _dur = Duration(milliseconds: widget.durMs);
  double _rate = 1;
  late final List<double> _bars = () {
    final r = math.Random(widget.path.hashCode);
    return List<double>.generate(26, (_) => 6 + r.nextInt(20).toDouble());
  }();

  @override
  void initState() {
    super.initState();
    _p.onPlayerStateChanged.listen((s) {
      if (mounted) setState(() => _playing = s == PlayerState.playing);
    });
    _p.onPositionChanged.listen((d) {
      if (mounted) setState(() => _pos = d);
    });
    _p.onDurationChanged.listen((d) {
      if (mounted && d > Duration.zero) setState(() => _dur = d);
    });
    _p.onPlayerComplete.listen((_) {
      if (mounted) setState(() { _pos = Duration.zero; _playing = false; });
    });
  }

  @override
  void dispose() {
    if (_current == _p) _current = null;
    _p.dispose();
    super.dispose();
  }

  Future<void> _toggle() async {
    if (_playing) {
      await _p.pause();
      return;
    }
    if (_current != null && _current != _p) await _current!.pause();
    _current = _p;
    if (_pos == Duration.zero || _pos >= _dur) {
      await _p.play(DeviceFileSource(widget.path));
    } else {
      await _p.resume();
    }
    await _p.setPlaybackRate(_rate);
  }

  Future<void> _seek(double frac) async {
    final to = _dur * frac.clamp(0.0, 1.0);
    setState(() => _pos = to);
    try {
      await _p.seek(to);
    } catch (_) {}
  }

  Future<void> _cycleRate() async {
    setState(() => _rate = _rate == 1 ? 1.5 : _rate == 1.5 ? 2 : 1);
    try {
      await _p.setPlaybackRate(_rate);
    } catch (_) {}
  }

  String _fmt(Duration d) =>
      '${d.inMinutes}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final prog = _dur.inMilliseconds == 0
        ? 0.0 : (_pos.inMilliseconds / _dur.inMilliseconds).clamp(0.0, 1.0);
    final fg = widget.out ? Colors.white : C.indigoSoft;
    final bg = widget.out ? Colors.white38 : C.line;
    return Row(mainAxisSize: MainAxisSize.min, children: [
      GestureDetector(
        onTap: _toggle,
        child: Icon(_playing ? Icons.pause_circle_filled : Icons.play_circle_fill, size: 40, color: fg)),
      const SizedBox(width: 8),
      GestureDetector(
        onTapDown: (d) => _seek(d.localPosition.dx / _w),
        child: SizedBox(
          width: _w, height: 30,
          child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
            for (var i = 0; i < _bars.length; i++)
              Container(
                width: 3, height: _bars[i], margin: const EdgeInsets.only(right: 1.5),
                decoration: BoxDecoration(
                    color: i / _bars.length < prog ? fg : bg, borderRadius: BorderRadius.circular(2))),
          ]),
        ),
      ),
      const SizedBox(width: 8),
      Text(_fmt(_playing || _pos > Duration.zero ? _pos : _dur),
          style: TextStyle(fontSize: 12, color: widget.out ? Colors.white70 : C.muted)),
      const SizedBox(width: 6),
      GestureDetector(
        onTap: _cycleRate,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
          decoration: BoxDecoration(
              color: Colors.black26, borderRadius: BorderRadius.circular(10)),
          child: Text('${_rate == _rate.roundToDouble() ? _rate.toInt() : _rate}x',
              style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700)))),
    ]);
  }
}

/// Honest privacy indicator: shows what protects THIS conversation right now.
class _SecureBadge extends StatelessWidget {
  const _SecureBadge({required this.peer});
  final Peer peer;

  @override
  Widget build(BuildContext context) {
    final (icon, text, color) = peer.online
        ? (Icons.lock_rounded, 'Encrypted link · no internet, no server', C.online)
        : peer.relayed
            ? (Icons.lock_open_rounded, 'Relayed through other phones', const Color(0xFFFBBF24))
            : (Icons.lock_outline_rounded, 'Encrypted when connected', C.muted);
    return InkWell(
      onTap: () => showDialog<void>(
        context: context,
        builder: (d) => AlertDialog(
          backgroundColor: C.surface,
          title: const Text('How is this chat protected?'),
          content: const SingleChildScrollView(
            child: Text(
                'Direct chat: every Bluetooth / Wi-Fi link between two OffChat phones is encrypted and '
                'authenticated by Google Nearby Connections. Messages never touch the internet or any server.\n\n'
                'Relayed chat: when a text hops through another phone (A → B → C), that middle phone can '
                'technically read it. True end-to-end encryption for relayed messages is planned, so OffChat '
                'does not claim it yet.\n\n'
                'Stored messages live only in a local database on each phone.',
                style: TextStyle(height: 1.4)),
          ),
          actions: [TextButton(onPressed: () => Navigator.pop(d), child: const Text('OK'))],
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, size: 13, color: color),
          const SizedBox(width: 6),
          Text(text, style: TextStyle(fontSize: 11.5, color: color)),
        ]),
      ),
    );
  }
}
