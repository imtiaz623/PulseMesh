import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../call_service.dart';
import '../mesh_service.dart';
import '../models.dart';
import '../theme.dart';
import '../widgets.dart';
import 'chat_screen.dart';

/// WhatsApp-style contact card: cover photo, profile photo, name, bio, last seen.
class ContactScreen extends StatelessWidget {
  const ContactScreen({super.key, required this.peerId, this.fromChat = false});
  final String peerId;
  final bool fromChat;

  @override
  Widget build(BuildContext context) {
    final mesh = context.watch<MeshService>();
    final Peer? peer = mesh.peers[peerId];
    if (peer == null) return const Scaffold(body: Center(child: Text('Contact not found')));
    final cover = mesh.coverOf(peerId);
    final status = peer.online
        ? 'Active now'
        : peer.relayed
            ? 'Via mesh · ${peer.hops} hops'
            : peer.discovered ? 'In range' : 'Last seen ${lastSeenText(peer.lastSeen)}';
    final base = C.avatar(peer.color);
    return Scaffold(
      body: ListView(padding: EdgeInsets.zero, children: [
        SizedBox(
          height: 250,
          child: Stack(clipBehavior: Clip.none, children: [
            Positioned.fill(
              bottom: 50,
              child: cover != null && File(cover).existsSync()
                  ? Image.file(File(cover), fit: BoxFit.cover, cacheWidth: 960)
                  : Container(
                      decoration: BoxDecoration(
                          gradient: LinearGradient(colors: [base, Color.lerp(base, Colors.black, .65)!]))),
            ),
            SafeArea(child: IconButton(icon: const Icon(Icons.arrow_back_rounded), onPressed: () => Navigator.pop(context))),
            Positioned(
              left: 0, right: 0, bottom: 0,
              child: Center(
                child: Container(
                  decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: C.bg, width: 5)),
                  child: PeerAvatar(name: peer.name, color: peer.color, photo: mesh.avatarOf(peerId), size: 104),
                ),
              ),
            ),
          ]),
        ),
        const SizedBox(height: 10),
        Center(child: Text(peer.name, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800))),
        const SizedBox(height: 4),
        Center(
          child: Text(status, style: TextStyle(color: peer.online ? C.online : C.muted, fontSize: 13.5))),
        Padding(
          padding: const EdgeInsets.fromLTRB(24, 18, 24, 0),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            _action(Icons.chat_bubble_rounded, 'Message', () {
              if (fromChat) {
                Navigator.pop(context);
              } else {
                Navigator.pushReplacement(
                    context, MaterialPageRoute(builder: (_) => ChatScreen(peerId: peerId)));
              }
            }),
            _action(Icons.call_rounded, 'Voice', peer.online
                ? () {
                    context.read<CallService>().start(peerId, withVideo: false);
                    Navigator.pop(context);
                  }
                : null),
            _action(Icons.videocam_rounded, 'Video', peer.online
                ? () {
                    context.read<CallService>().start(peerId, withVideo: true);
                    Navigator.pop(context);
                  }
                : null),
          ]),
        ),
        const SizedBox(height: 20),
        _section('About', peer.bio.isEmpty ? 'Hey there! I am using OffChat.' : peer.bio),
        _section('Device ID', peer.id, mono: true),
        _section(
            'Privacy',
            peer.online
                ? 'Messages on this direct link are encrypted by Google Nearby Connections. Nothing goes through the internet or a server.'
                : 'Messages are encrypted when you are directly connected. Relayed messages can be read by the phones that pass them on.'),
        const SizedBox(height: 30),
      ]),
    );
  }

  Widget _action(IconData i, String label, VoidCallback? onTap) => Opacity(
        opacity: onTap == null ? .4 : 1,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 8),
            child: Column(children: [
              Icon(i, color: C.indigoSoft),
              const SizedBox(height: 4),
              Text(label, style: const TextStyle(fontSize: 12.5, color: C.indigoSoft)),
            ]),
          ),
        ),
      );

  Widget _section(String title, String body, {bool mono = false}) => Container(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 10),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: C.surface, borderRadius: BorderRadius.circular(16)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 12, color: C.muted, fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          SelectableText(body, style: TextStyle(fontSize: 15.5, height: 1.35, fontFamily: mono ? 'monospace' : null)),
        ]),
      );
}
