import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../mesh_service.dart';
import '../theme.dart';
import '../widgets.dart';
import 'about_screen.dart';
import 'premium_screen.dart';
import 'privacy_screen.dart';
import 'sos.dart';
import 'wallpaper_picker.dart';

// ============================================================ Tab 3: Settings & Profile
class SettingsTab extends StatefulWidget {
  const SettingsTab({super.key});
  @override
  State<SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends State<SettingsTab> {
  late final TextEditingController _name =
      TextEditingController(text: context.read<MeshService>().myName);

  late final TextEditingController _bio =
      TextEditingController(text: context.read<MeshService>().myBio);

  @override
  void dispose() {
    _name.dispose();
    _bio.dispose();
    super.dispose();
  }

  Future<void> _pickCover(MeshService mesh) async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: C.surface,
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.photo_library_outlined),
            title: const Text('Choose cover from gallery'),
            onTap: () => Navigator.pop(context, 'gallery')),
          ListTile(
            leading: const Icon(Icons.photo_camera_outlined),
            title: const Text('Take a photo'),
            onTap: () => Navigator.pop(context, 'camera')),
          if (mesh.myCover != null)
            ListTile(
              leading: const Icon(Icons.delete_outline_rounded, color: Color(0xFFF87171)),
              title: const Text('Remove cover'),
              onTap: () => Navigator.pop(context, 'remove')),
        ]),
      ),
    );
    if (choice == null) return;
    if (choice == 'remove') {
      await mesh.removeCover();
      return;
    }
    try {
      final x = await ImagePicker().pickImage(source: choice == 'camera' ? ImageSource.camera : ImageSource.gallery);
      if (x != null) await mesh.setCover(x.path);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not use that photo')));
      }
    }
  }

  Future<void> _save(MeshService mesh) async {
    FocusScope.of(context).unfocus();
    await mesh.setBio(_bio.text);
    await mesh.setName(_name.text);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Profile updated')));
    }
  }

  Future<void> _pickPhoto(MeshService mesh) async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: C.surface,
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.photo_library_outlined),
            title: const Text('Choose from gallery'),
            onTap: () => Navigator.pop(context, 'gallery')),
          ListTile(
            leading: const Icon(Icons.photo_camera_outlined),
            title: const Text('Take a photo'),
            onTap: () => Navigator.pop(context, 'camera')),
          if (mesh.myAvatar != null)
            ListTile(
              leading: const Icon(Icons.delete_outline_rounded, color: Color(0xFFF87171)),
              title: const Text('Remove photo'),
              onTap: () => Navigator.pop(context, 'remove')),
        ]),
      ),
    );
    if (choice == null) return;
    if (choice == 'remove') {
      await mesh.removeAvatar();
      return;
    }
    final x = await ImagePicker().pickImage(source: choice == 'camera' ? ImageSource.camera : ImageSource.gallery);
    if (x == null) return;
    try {
      await mesh.setAvatar(x.path);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not use that photo')));
      }
    }
  }

  Future<void> _clear(MeshService mesh) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: C.surface,
        title: const Text('Clear local data?'),
        content: const Text('All chats, media and saved peers on this phone will be deleted. This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete', style: TextStyle(color: Color(0xFFF87171)))),
        ],
      ),
    );
    if (ok == true) await mesh.clearHistory();
  }

  @override
  Widget build(BuildContext context) {
    final mesh = context.watch<MeshService>();
    return ListView(padding: const EdgeInsets.fromLTRB(16, 16, 16, 24), children: [
      const Padding(
        padding: EdgeInsets.fromLTRB(4, 0, 4, 12),
        child: Text('Profile',
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, letterSpacing: -.5))),
      _Card(children: [
        // cover photo with the profile photo overlapping its lower edge
        SizedBox(
          height: 196,
          child: Stack(clipBehavior: Clip.none, children: [
            Positioned.fill(
              bottom: 52,
              child: GestureDetector(
                onTap: () => _pickCover(mesh),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: mesh.myCover != null && File(mesh.myCover!).existsSync()
                      ? Image.file(File(mesh.myCover!), fit: BoxFit.cover, cacheWidth: 900)
                      : Container(
                          decoration: BoxDecoration(
                              gradient: LinearGradient(colors: [
                            C.avatar(mesh.myColor),
                            Color.lerp(C.avatar(mesh.myColor), Colors.black, .65)!
                          ])),
                          alignment: Alignment.center,
                          child: const Text('Tap to add a cover photo',
                              style: TextStyle(color: Colors.white70, fontSize: 13)),
                        ),
                ),
              ),
            ),
            Positioned(
              right: 10, top: 10,
              child: GestureDetector(
                onTap: () => _pickCover(mesh),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
                  child: const Icon(Icons.camera_alt_rounded, size: 17, color: Colors.white)),
              ),
            ),
            Positioned(
              left: 0, right: 0, bottom: 0,
              child: Center(
                child: GestureDetector(
                  onTap: () => _pickPhoto(mesh),
                  child: Stack(children: [
                    Container(
                      decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: C.surface, width: 5)),
                      child: PeerAvatar(name: mesh.myName, color: mesh.myColor, photo: mesh.myAvatar, size: 104)),
                    Positioned(
                      right: 2, bottom: 2,
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                            color: C.indigo, shape: BoxShape.circle, border: Border.all(color: C.surface, width: 3)),
                        child: const Icon(Icons.camera_alt_rounded, size: 17, color: Colors.white)),
                    ),
                  ]),
                ),
              ),
            ),
          ]),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _name, maxLength: 24,
          textInputAction: TextInputAction.next,
          decoration: InputDecoration(
            labelText: 'Display name', filled: true, fillColor: C.bg, counterText: '',
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _bio, maxLength: 140, minLines: 1, maxLines: 3,
          decoration: InputDecoration(
            labelText: 'About', hintText: 'Hey there! I am using OffChat', filled: true, fillColor: C.bg,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)),
        ),
        const SizedBox(height: 8),
        FilledButton.icon(
          onPressed: () => _save(mesh),
          icon: const Icon(Icons.check_rounded),
          label: const Text('Save profile'),
        ),
        const SizedBox(height: 14),
        const Text('Colour (shown when you have no photo)', style: TextStyle(color: C.muted, fontSize: 13)),
        const SizedBox(height: 10),
        Wrap(spacing: 12, runSpacing: 12, children: [
          for (var i = 0; i < C.avatars.length; i++)
            GestureDetector(
              onTap: () => mesh.setColor(i),
              child: Container(
                width: 38, height: 38,
                decoration: BoxDecoration(
                  color: C.avatars[i], shape: BoxShape.circle,
                  border: Border.all(color: mesh.myColor % 8 == i ? Colors.white : Colors.transparent, width: 2.5)),
                child: mesh.myColor % 8 == i ? const Icon(Icons.check, size: 20) : null),
            ),
        ]),
      ]),
      const SizedBox(height: 16),
      _Card(children: [
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.workspace_premium_rounded, color: Color(0xFFFBBF24)),
          title: const Text('OffChat Premium'),
          subtitle: Text(
              mesh.premium.active
                  ? 'Active · ${mesh.premium.planLabel}'
                  : 'Screenshot alerts, delete for everyone and more',
              style: const TextStyle(color: C.muted, fontSize: 12.5)),
          trailing: const Icon(Icons.chevron_right_rounded),
          onTap: () => openPremium(context),
        ),
        const Divider(height: 1, color: C.line),
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.warning_amber_rounded, color: Color(0xFFF87171)),
          title: const Text('Emergency SOS'),
          subtitle: const Text('Alert everyone nearby, even without internet',
              style: TextStyle(color: C.muted, fontSize: 12.5)),
          trailing: const Icon(Icons.chevron_right_rounded),
          onTap: () => showSosDialog(context),
        ),
      ]),
      const SizedBox(height: 16),
      _Card(children: [
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.wallpaper_rounded),
          title: const Text('Chat wallpaper'),
          subtitle: const Text('Default for all chats. Change one chat from its menu.',
              style: TextStyle(color: C.muted, fontSize: 12.5)),
          trailing: const Icon(Icons.chevron_right_rounded),
          onTap: () => showWallpaperPicker(context),
        ),
        const Divider(height: 1, color: C.line),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Row(children: [
            const Icon(Icons.text_fields_rounded, color: C.muted),
            const SizedBox(width: 16),
            const Expanded(child: Text('Text size')),
            SegmentedButton<double>(
              showSelectedIcon: false,
              style: const ButtonStyle(visualDensity: VisualDensity.compact),
              segments: const [
                ButtonSegment(value: 0.9, label: Text('A', style: TextStyle(fontSize: 12))),
                ButtonSegment(value: 1.0, label: Text('A', style: TextStyle(fontSize: 15))),
                ButtonSegment(value: 1.15, label: Text('A', style: TextStyle(fontSize: 19))),
              ],
              selected: {mesh.textScale},
              onSelectionChanged: (v) => mesh.setTextScale(v.first),
            ),
          ]),
        ),
        const Divider(height: 1, color: C.line),
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.privacy_tip_outlined),
          title: const Text('Privacy & data'),
          trailing: const Icon(Icons.chevron_right_rounded),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PrivacyScreen())),
        ),
        const Divider(height: 1, color: C.line),
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.info_outline_rounded),
          title: const Text('About OffChat'),
          trailing: const Icon(Icons.chevron_right_rounded),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AboutScreen())),
        ),
      ]),
      const SizedBox(height: 16),
      _Card(children: [
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Mesh active'),
          subtitle: const Text('Advertise and discover nearby OffChat users',
              style: TextStyle(color: C.muted, fontSize: 12.5)),
          value: mesh.wantRunning,
          onChanged: (v) => v ? mesh.start() : mesh.stop(),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Auto-Bluetooth'),
          subtitle: const Text('Ask to turn Bluetooth on whenever it is off',
              style: TextStyle(color: C.muted, fontSize: 12.5)),
          value: mesh.autoBluetooth,
          onChanged: mesh.setAutoBluetooth,
        ),
      ]),
      const SizedBox(height: 16),
      _Card(children: [
        const Text('Storage', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        const Text('Everything lives in a local SQLite database on this phone. Nothing is uploaded.',
            style: TextStyle(color: C.muted, fontSize: 13)),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          onPressed: () => _clear(mesh),
          icon: const Icon(Icons.delete_outline, color: Color(0xFFF87171)),
          label: const Text('Clear chats, media and peers', style: TextStyle(color: Color(0xFFF87171))),
          style: OutlinedButton.styleFrom(side: const BorderSide(color: C.line)),
        ),
      ]),
      const SizedBox(height: 16),
      Center(
        child: Text('OffChat 1.0 · device ${mesh.myId}',
            style: const TextStyle(color: C.muted, fontSize: 12))),
    ]);
  }
}

class _Card extends StatelessWidget {
  const _Card({required this.children});
  final List<Widget> children;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: C.surface, borderRadius: BorderRadius.circular(20)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: children),
      );
}
