import 'dart:async';
import 'dart:io';
import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';

import 'call_service.dart';
import 'mesh_service.dart';
import 'screens/call_screen.dart';
import 'screens/home_shell.dart';
import 'screens/sos.dart';
import 'theme.dart';

void main() {
  runZonedGuarded(() async {
    WidgetsFlutterBinding.ensureInitialized();
    // If any widget ever throws, show the reason on a dark screen instead of a blank/white one.
    // A broken widget must never show a red/technical screen to a user: quiet message in release.
    ErrorWidget.builder = (d) => Directionality(
          textDirection: TextDirection.ltr,
          child: Container(
            color: C.bg, padding: const EdgeInsets.all(20), alignment: Alignment.center,
            child: Text(
                kReleaseMode ? 'This part could not load.\nGo back and try again.' : d.exceptionAsString(),
                textAlign: TextAlign.center,
                style: const TextStyle(color: C.muted, fontSize: 13, decoration: TextDecoration.none)),
          ),
        );
    // Errors that escape everything else are logged, never crash the app.
    FlutterError.onError = (d) => debugPrint('Flutter error: ${d.exceptionAsString()}');
    PlatformDispatcher.instance.onError = (e, s) {
      debugPrint('Platform error: $e');
      return true;
    };
    await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent, statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: C.surface));
    runApp(const BootApp());
  }, (e, s) => debugPrint('Uncaught: $e\n$s'));
}

/// Draws a dark splash IMMEDIATELY, then loads storage. A failure shows on screen with
/// Retry / Reset buttons, so the app can never sit on a blank white screen again.
class BootApp extends StatefulWidget {
  const BootApp({super.key});
  @override
  State<BootApp> createState() => _BootAppState();
}

class _BootAppState extends State<BootApp> {
  MeshService? _mesh;
  String _step = 'Starting';
  String? _error;

  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    setState(() {
      _error = null;
      _step = 'Starting';
    });
    final m = MeshService();
    try {
      await m.init((s) {
        if (mounted) setState(() => _step = s);
      }).timeout(const Duration(seconds: 20));
      if (mounted) setState(() => _mesh = m);
    } catch (e, s) {
      if (mounted) setState(() => _error = 'Stopped at: $_step\n\n$e\n\n$s');
    }
  }

  Future<void> _reset() async {
    try {
      // keep the old chats as a backup file instead of destroying them
      final path = p.join(await getDatabasesPath(), 'pulsemesh.db');
      final f = File(path);
      if (await f.exists()) await f.rename('$path.backup_${DateTime.now().millisecondsSinceEpoch}');
    } catch (_) {}
    await _boot();
  }

  @override
  Widget build(BuildContext context) {
    final mesh = _mesh;
    if (mesh != null) {
      return MultiProvider(
        providers: [
          ChangeNotifierProvider<MeshService>.value(value: mesh),
          ChangeNotifierProvider<CallService>.value(value: mesh.calls),
        ],
        child: const PulseApp(),
      );
    }
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: _Splash(step: _step, error: _error, onRetry: _boot, onReset: _reset),
    );
  }
}

class _Splash extends StatelessWidget {
  const _Splash({required this.step, required this.error, required this.onRetry, required this.onReset});
  final String step;
  final String? error;
  final VoidCallback onRetry, onReset;

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: C.bg,
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(46),
                  child: Image.asset('assets/logo.png', width: 92, height: 92)),
                const SizedBox(height: 22),
                const Text('OffChat', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, letterSpacing: -.5)),
                const SizedBox(height: 4),
                const Text('Chat and call without internet', style: TextStyle(color: C.muted)),
                const SizedBox(height: 30),
                if (error == null) ...[
                  const SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 3)),
                  const SizedBox(height: 14),
                  Text('$step…', style: const TextStyle(color: C.muted, fontSize: 13)),
                ] else ...[
                  const Text('OffChat could not start.\nYour chats are safe on this phone.',
                      textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 12),
                  Container(
                    constraints: const BoxConstraints(maxWidth: 380, maxHeight: 160),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: C.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: C.line)),
                    child: SingleChildScrollView(
                      child: SelectableText(error!, style: const TextStyle(fontSize: 11.5, color: C.muted))),
                  ),
                  const SizedBox(height: 16),
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    FilledButton(onPressed: onRetry, child: const Text('Retry')),
                    const SizedBox(width: 12),
                    OutlinedButton(onPressed: onReset, child: const Text('Start fresh')),
                  ]),
                ],
              ]),
            ),
          ),
        ),
      );
}

class PulseApp extends StatefulWidget {
  const PulseApp({super.key});
  @override
  State<PulseApp> createState() => _PulseAppState();
}

class _PulseAppState extends State<PulseApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) context.read<MeshService>().onResume();
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'OffChat',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        scrollBehavior: const SmoothScroll(),
        builder: (context, child) {
          // user-chosen text size (Profile > Text size) on top of the system font size
          final scale = context.select<MeshService, double>((m) => m.textScale);
          final mq = MediaQuery.of(context);
          return MediaQuery(
            data: mq.copyWith(textScaler: TextScaler.linear(mq.textScaler.scale(1.0) * scale)),
            child: Stack(children: [
              Positioned.fill(child: child ?? const SizedBox.shrink()),
              const Positioned.fill(child: CallOverlay()),
              const Positioned.fill(child: SosOverlay()),
            ]),
          );
        },
        home: const HomeShell(),
      );
}
