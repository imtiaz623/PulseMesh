import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'call_service.dart';
import 'mesh_service.dart';
import 'screens/home_shell.dart';
import 'theme.dart';

void main() {
  runZonedGuarded(() {
    WidgetsFlutterBinding.ensureInitialized();
    // Release builds hide errors (white/grey screen). Show them on screen instead.
    ErrorWidget.builder = (d) => Material(
          color: C.bg,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: SafeArea(
              child: Text('UI error:\n${d.exceptionAsString()}\n\n${d.stack}',
                  style: const TextStyle(color: Colors.redAccent, fontSize: 12)),
            ),
          ),
        );
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
        systemNavigationBarColor: C.surface));
    runApp(const Boot());
  }, (e, s) => debugPrint('Uncaught: $e\n$s'));
}

/// Starts the UI immediately, then initialises the mesh engine. If init fails
/// or hangs, the error is shown on screen instead of a blank white screen.
class Boot extends StatefulWidget {
  const Boot({super.key});
  @override
  State<Boot> createState() => _BootState();
}

class _BootState extends State<Boot> {
  MeshService? _mesh;
  CallService? _call;
  String? _error;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      final mesh = MeshService();
      await mesh.init().timeout(const Duration(seconds: 20));
      final call = CallService(mesh);
      if (mounted) {
        setState(() {
          _mesh = mesh;
          _call = call;
        });
      }
    } catch (e, s) {
      if (mounted) setState(() => _error = '$e\n\n$s');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_mesh != null) {
      return MultiProvider(providers: [
        ChangeNotifierProvider<MeshService>.value(value: _mesh!),
        ChangeNotifierProvider<CallService>.value(value: _call!),
      ], child: const PulseApp());
    }
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: Scaffold(
        body: SafeArea(
          child: _error != null
              ? SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: SelectableText('Startup error:\n\n$_error',
                      style: const TextStyle(color: Colors.redAccent, fontSize: 12)))
              : const Center(child: CircularProgressIndicator()),
        ),
      ),
    );
  }
}

class PulseApp extends StatefulWidget {
  const PulseApp({super.key});
  @override
  State<PulseApp> createState() => _PulseAppState();
}

class _PulseAppState extends State<PulseApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) context.read<MeshService>().onResume();
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'PulseMesh',
        navigatorKey: navKey,
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        home: const HomeShell(),
      );
}
