enum MsgStatus { queued, sent, delivered }

class Peer {
  Peer({required this.id, required this.name, required this.color, this.lastSeen = 0});

  final String id; // stable 8-char device id (survives Nearby endpoint rotation)
  String name;
  int color;
  int lastSeen;

  // runtime-only state
  String? endpointId;
  bool online = false;
  bool discovered = false;
  bool connecting = false;
  int? rtt; // round-trip ms, measured by ping/pong
  int hops = 0, hopsTs = 0; // >0: reachable through other phones (mesh relay)
  String? via;
  bool get relayed =>
      !online && hops > 0 && DateTime.now().millisecondsSinceEpoch - hopsTs < 45000;

  Map<String, Object?> toMap() =>
      {'id': id, 'name': name, 'color': color, 'last_seen': lastSeen};

  factory Peer.fromMap(Map<String, Object?> m) => Peer(
        id: m['id'] as String,
        name: m['name'] as String,
        color: m['color'] as int,
        lastSeen: m['last_seen'] as int,
      );
}

class Message {
  Message({
    required this.id,
    required this.peerId,
    required this.outgoing,
    required this.type, // 'text' | 'image' | 'voice' | 'video'
    required this.body,
    this.path,
    required this.ts,
    this.status = MsgStatus.queued,
    this.read = true,
    this.dur = 0,
  });

  final String id, peerId, type, body;
  final String? path;
  final bool outgoing;
  final int ts, dur; // dur = voice length in ms
  MsgStatus status;
  bool read;

  Map<String, Object?> toMap() => {
        'dur': dur,
        'id': id, 'peer_id': peerId, 'outgoing': outgoing ? 1 : 0, 'type': type,
        'body': body, 'path': path, 'ts': ts, 'status': status.index, 'is_read': read ? 1 : 0,
      };

  factory Message.fromMap(Map<String, Object?> m) => Message(
        id: m['id'] as String,
        peerId: m['peer_id'] as String,
        outgoing: (m['outgoing'] as int) == 1,
        type: m['type'] as String,
        body: m['body'] as String,
        path: m['path'] as String?,
        ts: m['ts'] as int,
        status: MsgStatus.values[m['status'] as int],
        read: (m['is_read'] as int) == 1,
        dur: (m['dur'] as int?) ?? 0,
      );
}

/// A 24-hour status update (image or colored text), like WhatsApp Status.
class StatusItem {
  StatusItem({
    required this.id, required this.authorId, required this.kind, this.path,
    this.text = '', this.color = 0, required this.ts, this.viewed = false, this.reported = false,
  });

  final String id, authorId, kind, text; // kind: 'image' | 'text'
  final String? path;
  final int color, ts;
  bool viewed;   // I have seen it (statuses from others)
  bool reported; // the author has been told I saw it

  bool get expired => DateTime.now().millisecondsSinceEpoch - ts > 24 * 3600 * 1000;

  Map<String, Object?> toMap() => {
        'id': id, 'author_id': authorId, 'kind': kind, 'path': path, 'text': text,
        'color': color, 'ts': ts, 'viewed': viewed ? 1 : 0, 'reported': reported ? 1 : 0,
      };

  factory StatusItem.fromMap(Map<String, Object?> m) => StatusItem(
        id: m['id'] as String, authorId: m['author_id'] as String, kind: m['kind'] as String,
        path: m['path'] as String?, text: m['text'] as String, color: m['color'] as int,
        ts: m['ts'] as int, viewed: (m['viewed'] as int) == 1, reported: (m['reported'] as int) == 1,
      );
}
