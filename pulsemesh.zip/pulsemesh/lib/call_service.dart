import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';

import 'mesh_service.dart';

enum CallState { idle, calling, incoming, connected, ended }

/// 1-to-1 voice calls over the existing Nearby link.
///
/// Signalling: JSON {t:'c', a:'ring'|'acc'|'rej'|'busy'|'end', id}.
/// Media frames are raw payloads whose first byte is a type (JSON starts with '{' = 123):
///   [1, ...40 ms of mu-law audio]
class CallService extends ChangeNotifier {
  CallService(this.mesh) {
    mesh.addListener(_watch);
  }

  final MeshService mesh;
  static const _native = MethodChannel('pulsemesh/native');
  static const _mic = EventChannel('pulsemesh/mic');

  CallState state = CallState.idle;
  String? peerId;
  String? _callId;
  bool outgoing = false, muted = false, speaker = false;
  String endNote = '';
  int seconds = 0;
  DateTime? _connectedAt;

  Timer? _ticker, _ringTimer, _tone;
  StreamSubscription<dynamic>? _micSub;
  int _aInflight = 0;

  bool get active => state != CallState.idle;

  // ------------------------------------------------------------ outgoing
  Future<void> start(String pid) async {
    if (active) return;
    final pr = mesh.peers[pid];
    if (pr == null || !pr.online) {
      _flash(pid, 'Peer is offline');
      return;
    }
    if (!await _perms()) {
      _flash(pid, 'Microphone access needed');
      return;
    }
    _begin(pid, outgoing: true, id: DateTime.now().microsecondsSinceEpoch.toString());
    state = CallState.calling;
    notifyListeners();
    mesh.sendJsonTo(pid, {'t': 'c', 'a': 'ring', 'id': _callId});
    _ringTimer = Timer(const Duration(seconds: 40), () => _finish('No answer', why: 'No answer', tell: true));
  }

  // ------------------------------------------------------------ incoming
  void onSignal(String from, Map<String, dynamic> j) {
    final id = j['id'] as String?;
    switch (j['a']) {
      case 'ring':
        if (active) {
          mesh.sendJsonTo(from, {'t': 'c', 'a': 'busy', 'id': id});
          return;
        }
        _begin(from, outgoing: false, id: id);
        state = CallState.incoming;
        notifyListeners();
        _ring();
        _ringTimer = Timer(const Duration(seconds: 40), () => _finish('Missed call', why: 'Missed'));
      case 'acc':
        if (id == _callId && state == CallState.calling) _connect();
      case 'rej':
        if (id == _callId) _finish('Declined', why: 'Declined');
      case 'busy':
        if (id == _callId) _finish('Busy', why: 'Busy');
      case 'end':
        if (id == _callId && active) {
          _finish(state == CallState.connected ? 'Call ended' : 'Cancelled',
              why: state == CallState.incoming ? 'Missed' : 'Cancelled');
        }
    }
  }

  Future<void> accept() async {
    if (state != CallState.incoming) return;
    if (!await _perms()) {
      mesh.sendJsonTo(peerId!, {'t': 'c', 'a': 'rej', 'id': _callId});
      _finish('Permission needed', why: 'Declined');
      return;
    }
    mesh.sendJsonTo(peerId!, {'t': 'c', 'a': 'acc', 'id': _callId});
    await _connect();
  }

  void reject() {
    if (peerId == null) return;
    mesh.sendJsonTo(peerId!, {'t': 'c', 'a': 'rej', 'id': _callId});
    _finish('Declined', why: 'Declined');
  }

  Future<void> end() async {
    if (state == CallState.incoming) {
      reject();
      return;
    }
    await _finish(state == CallState.connected ? 'Call ended' : 'Cancelled', why: 'Cancelled', tell: true);
  }

  // ------------------------------------------------------------ controls
  void toggleMute() {
    muted = !muted;
    notifyListeners();
  }

  void toggleSpeaker() {
    speaker = !speaker;
    _native.invokeMethod('audioSpeaker', {'on': speaker}).catchError((_) {});
    notifyListeners();
  }

  // ------------------------------------------------------------ internals
  void _begin(String pid, {required bool outgoing, String? id}) {
    peerId = pid;
    this.outgoing = outgoing;
    _callId = id;
    muted = false;
    speaker = false;
    seconds = 0;
    _connectedAt = null;
    endNote = '';
  }

  Future<bool> _perms() async => (await Permission.microphone.request()).isGranted;

  void _ring() {
    _tone?.cancel();
    if (outgoing) return;
    HapticFeedback.vibrate();
    _tone = Timer.periodic(const Duration(milliseconds: 1400), (_) {
      HapticFeedback.vibrate();
      SystemSound.play(SystemSoundType.alert);
    });
  }

  Future<void> _connect() async {
    _ringTimer?.cancel();
    _tone?.cancel();
    state = CallState.connected;
    _connectedAt = DateTime.now();
    seconds = 0;
    notifyListeners();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      seconds = DateTime.now().difference(_connectedAt!).inSeconds;
      notifyListeners();
    });
    await _startMedia();
  }

  Future<void> _startMedia() async {
    try {
      await _native.invokeMethod('keepAwake', {'on': true});
      await _native.invokeMethod('audioStart', {'speaker': speaker});
      _micSub = _mic.receiveBroadcastStream().listen(_onMic);
    } catch (e) {
      _finish('Could not start the call ($e)', why: 'Failed', tell: true);
    }
  }

  Future<void> _stopMedia() async {
    await _micSub?.cancel();
    _micSub = null;
    try {
      await _native.invokeMethod('audioStop');
      await _native.invokeMethod('keepAwake', {'on': false});
    } catch (_) {}
  }

  void _onMic(dynamic f) {
    if (muted || f is! Uint8List || peerId == null || state != CallState.connected) return;
    if (_aInflight > 12) return; // link is behind: drop instead of building latency
    _aInflight++;
    final b = Uint8List(f.length + 1)
      ..[0] = 1
      ..setRange(1, f.length + 1, f);
    mesh.sendRawTo(peerId!, b).whenComplete(() => _aInflight--).catchError((_) {});
  }

  void onRaw(String from, Uint8List b) {
    if (state != CallState.connected || from != peerId || b.length < 2) return;
    if (b[0] == 1) {
      _native.invokeMethod('audioPlay', Uint8List.sublistView(b, 1)).catchError((_) {});
    }
  }

  // ---- finish
  String _mmss(int s) => '${(s ~/ 60).toString().padLeft(2, '0')}:${(s % 60).toString().padLeft(2, '0')}';

  String _logFor(String why) {
    if (_connectedAt != null) return 'Voice call · ${_mmss(seconds)}';
    if (outgoing) return 'Voice call · ${why.isEmpty ? 'Ended' : why}';
    return why == 'Declined' ? 'Voice call · Declined' : 'Missed voice call';
  }

  Future<void> _finish(String note, {String why = '', bool tell = false}) async {
    if (state == CallState.idle || state == CallState.ended) return;
    final pid = peerId;
    if (tell && pid != null) mesh.sendJsonTo(pid, {'t': 'c', 'a': 'end', 'id': _callId});
    final log = _logFor(why);
    _ticker?.cancel();
    _ringTimer?.cancel();
    _tone?.cancel();
    state = CallState.ended;
    endNote = note;
    notifyListeners();
    await _stopMedia();
    if (pid != null) mesh.addCallLog(pid, log, outgoing);
    Timer(const Duration(milliseconds: 1500), () {
      if (state == CallState.ended) {
        state = CallState.idle;
        peerId = null;
        notifyListeners();
      }
    });
  }

  void _flash(String pid, String note) {
    peerId = pid;
    endNote = note;
    state = CallState.ended;
    notifyListeners();
    Timer(const Duration(milliseconds: 1800), () {
      if (state == CallState.ended) {
        state = CallState.idle;
        peerId = null;
        notifyListeners();
      }
    });
  }

  void _watch() {
    if (state == CallState.idle || state == CallState.ended || peerId == null) return;
    final p = mesh.peers[peerId];
    if (p == null || !p.online) {
      _finish('Connection lost', why: state == CallState.incoming ? 'Missed' : 'Lost');
    }
  }

  @override
  void dispose() {
    mesh.removeListener(_watch);
    super.dispose();
  }
}
