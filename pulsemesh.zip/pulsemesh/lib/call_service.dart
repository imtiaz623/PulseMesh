import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_pcm_sound/flutter_pcm_sound.dart';
import 'package:provider/provider.dart';
import 'package:record/record.dart';

import 'mesh_service.dart';
import 'theme.dart';
import 'widgets.dart';

final GlobalKey<NavigatorState> navKey = GlobalKey<NavigatorState>();

enum CallState { idle, outgoing, incoming, active }

/// Live voice calls over the existing Nearby link.
/// Frames: {t:'c', a:'ring'|'acc'|'rej'|'end'|'d', d:<base64 PCM16 16 kHz mono>}
class CallService extends ChangeNotifier {
  CallService(this.mesh) {
    mesh.callHandler = _onFrame;
  }
  final MeshService mesh;
  final AudioRecorder _rec = AudioRecorder();
  StreamSubscription<Uint8List>? _sub;
  Timer? _tick, _ringTimeout;

  CallState state = CallState.idle;
  String? peerId;
  bool muted = false;
  int seconds = 0;
  String? note;
  bool _screenOpen = false;

  static const _rate = 16000;
  static const _chunk = 3200; // 100 ms

  Future<void> startCall(String id) async {
    if (state != CallState.idle) return;
    if (!await _rec.hasPermission()) {
      note = 'Microphone permission is needed for calls.';
      notifyListeners();
      return;
    }
    peerId = id;
    state = CallState.outgoing;
    note = null;
    notifyListeners();
    _openScreen();
    await mesh.sendCall(id, {'a': 'ring'});
    _ringTimeout = Timer(const Duration(seconds: 40), () => end(reason: 'No answer'));
  }

  Future<void> accept() async {
    if (state != CallState.incoming || peerId == null) return;
    if (!await _rec.hasPermission()) {
      reject();
      return;
    }
    await mesh.sendCall(peerId!, {'a': 'acc'});
    await _begin();
  }

  void reject() {
    if (peerId != null) mesh.sendCall(peerId!, {'a': 'rej'});
    _reset('Call declined');
  }

  void end({String? reason}) {
    if (peerId != null && state != CallState.idle) mesh.sendCall(peerId!, {'a': 'end'});
    _reset(reason ?? 'Call ended');
  }

  void toggleMute() {
    muted = !muted;
    notifyListeners();
  }

  void _onFrame(String from, Map<String, dynamic> j) {
    switch (j['a']) {
      case 'ring':
        if (state != CallState.idle) {
          mesh.sendCall(from, {'a': 'rej'});
          return;
        }
        peerId = from;
        state = CallState.incoming;
        notifyListeners();
        _openScreen();
      case 'acc':
        if (state == CallState.outgoing && from == peerId) _begin();
      case 'rej':
        if (from == peerId) _reset('Call declined');
      case 'end':
        if (from == peerId) _reset('Call ended');
      case 'd':
        if (state == CallState.active && from == peerId && j['d'] is String) {
          try {
            final b = base64Decode(j['d'] as String);
            FlutterPcmSound.feed(PcmArrayInt16(bytes: b.buffer.asByteData(b.offsetInBytes, b.length)));
          } catch (_) {}
        }
    }
  }

  Future<void> _begin() async {
    _ringTimeout?.cancel();
    try {
      await FlutterPcmSound.setup(sampleRate: _rate, channelCount: 1);
      final stream = await _rec.startStream(const RecordConfig(
          encoder: AudioEncoder.pcm16bits, sampleRate: _rate, numChannels: 1));
      final buf = BytesBuilder();
      _sub = stream.listen((data) {
        if (muted || peerId == null) return;
        buf.add(data);
        while (buf.length >= _chunk) {
          final all = buf.takeBytes();
          final out = all.sublist(0, _chunk);
          buf.add(all.sublist(_chunk));
          mesh.sendCall(peerId!, {'a': 'd', 'd': base64Encode(out)});
        }
      });
    } catch (e) {
      end(reason: 'Audio error: $e');
      return;
    }
    state = CallState.active;
    seconds = 0;
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      seconds++;
      if (peerId != null && mesh.peers[peerId]?.online != true) {
        _reset('Connection lost');
        return;
      }
      notifyListeners();
    });
    notifyListeners();
  }

  Future<void> _reset(String why) async {
    _tick?.cancel();
    _ringTimeout?.cancel();
    await _sub?.cancel();
    _sub = null;
    try {
      if (await _rec.isRecording()) await _rec.stop();
    } catch (_) {}
    try {
      await FlutterPcmSound.release();
    } catch (_) {}
    state = CallState.idle;
    muted = false;
    note = why;
    notifyListeners();
    if (_screenOpen) {
      await Future<void>.delayed(const Duration(milliseconds: 900));
      if (state == CallState.idle) navKey.currentState?.maybePop();
    }
    if (state == CallState.idle) peerId = null;
  }

  void _openScreen() {
    if (_screenOpen) return;
    _screenOpen = true;
    navKey.currentState
        ?.push(MaterialPageRoute(builder: (_) => const CallScreen(), fullscreenDialog: true))
        .whenComplete(() => _screenOpen = false);
  }

  @override
  void dispose() {
    mesh.callHandler = null;
    _rec.dispose();
    super.dispose();
  }
}

class CallScreen extends StatelessWidget {
  const CallScreen({super.key});

  String _t(int s) =>
      '${(s ~/ 60).toString().padLeft(2, '0')}:${(s % 60).toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final c = context.watch<CallService>();
    final peer = c.peerId == null ? null : c.mesh.peers[c.peerId];
    final name = peer?.name ?? 'Unknown';
    final status = switch (c.state) {
      CallState.outgoing => 'Calling…',
      CallState.incoming => 'Incoming voice call',
      CallState.active => _t(c.seconds),
      CallState.idle => c.note ?? 'Call ended',
    };
    return PopScope(
      canPop: c.state == CallState.idle,
      child: Scaffold(
        backgroundColor: C.bg,
        body: SafeArea(
          child: Column(children: [
            const Spacer(flex: 2),
            PeerAvatar(name: name, color: peer?.color ?? 0, online: true, size: 120),
            const SizedBox(height: 20),
            Text(name, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text(status, style: const TextStyle(fontSize: 16, color: C.muted)),
            const Spacer(flex: 3),
            Padding(
              padding: const EdgeInsets.only(bottom: 40),
              child: c.state == CallState.incoming
                  ? Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                      _Btn(Icons.call_end, Colors.red, c.reject),
                      _Btn(Icons.call, C.online, c.accept),
                    ])
                  : Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                      _Btn(c.muted ? Icons.mic_off : Icons.mic,
                          c.muted ? C.indigo : C.surface2, c.toggleMute),
                      _Btn(Icons.call_end, Colors.red, () => c.end()),
                    ]),
            ),
          ]),
        ),
      ),
    );
  }
}

class _Btn extends StatelessWidget {
  const _Btn(this.icon, this.color, this.onTap);
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => InkResponse(
        onTap: onTap,
        child: CircleAvatar(
            radius: 34, backgroundColor: color, child: Icon(icon, size: 30, color: Colors.white)),
      );
}
