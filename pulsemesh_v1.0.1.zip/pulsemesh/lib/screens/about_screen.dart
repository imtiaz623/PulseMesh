import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../mesh_service.dart';
import '../premium.dart';
import '../theme.dart';
import 'premium_screen.dart';
import 'privacy_screen.dart';

/// About OffChat: what the app is, what it does with your data (honestly), what Premium gives,
/// and who built it. Every statement here matches what the code actually does.
class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  static const _gold = Color(0xFFFBBF24);

  static const _highlights = <(IconData, String, String)>[
    (Icons.wifi_off_rounded, 'Works without internet',
        'Bluetooth and Wi-Fi connect nearby phones directly. No SIM balance or data needed to chat.'),
    (Icons.hub_rounded, 'Mesh relay for text',
        'Text messages can hop through other OffChat phones to reach someone who is out of your direct range.'),
    (Icons.perm_media_rounded, 'Photos, videos, voice notes',
        'Send original-quality photos and videos, record voice notes, and post 24-hour statuses.'),
    (Icons.call_rounded, 'Voice calls',
        'One-to-one voice calls over the same link. Both phones must be in range with the app open.'),
  ];

  static const _premiumPerks = <(IconData, String, String)>[
    (Icons.camera_alt_outlined, 'Screenshot alerts',
        'Get notified when someone screenshots your chat.'),
    (Icons.screenshot_outlined, 'Block screenshots on your phone',
        'Also hides OffChat in the recent-apps screen.'),
    (Icons.delete_forever_outlined, 'Delete for everyone',
        'Ask the other phone to remove a message you sent.'),
    (Icons.visibility_outlined, 'See deleted messages',
        'Keep reading messages others delete for everyone.'),
  ];

  @override
  Widget build(BuildContext context) {
    final pr = context.read<MeshService>().premium;
    return Scaffold(
      appBar: AppBar(title: const Text('About OffChat')),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 28), children: [
        _hero(),
        const SizedBox(height: 14),
        _card(children: [
          _title(Icons.info_outline_rounded, 'About the app'),
          const SizedBox(height: 8),
          const Text(
            'OffChat enables secure peer-to-peer communication via Bluetooth and Wi-Fi mesh technology '
            'without requiring an internet connection.',
            style: TextStyle(height: 1.5, fontSize: 14.5),
          ),
          const SizedBox(height: 12),
          for (final p in _highlights) _row(p.$1, p.$2, p.$3),
        ]),
        const SizedBox(height: 14),
        _dataCard(context),
        const SizedBox(height: 14),
        _premiumCard(context),
        const SizedBox(height: 14),
        _developerCard(context, pr),
        const SizedBox(height: 18),
        const Center(
          child: Text('Made with care in Pakistan',
              textAlign: TextAlign.center, style: TextStyle(color: C.muted, fontSize: 12.5)),
        ),
        const SizedBox(height: 4),
        const Center(
          child: Text('OffChat v$kAppVersion', style: TextStyle(color: C.muted, fontSize: 12)),
        ),
      ]),
    );
  }

  // ------------------------------------------------------------------ pieces
  Widget _hero() => Container(
        padding: const EdgeInsets.fromLTRB(20, 26, 20, 24),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF16A34A), Color(0xFF0F5132), Color(0xFF0A130E)],
          ),
          boxShadow: [BoxShadow(color: C.indigo.withOpacity(.25), blurRadius: 26, offset: const Offset(0, 10))],
        ),
        child: Column(children: [
          Container(
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(.25)),
            child: ClipOval(child: Image.asset('assets/logo.png', width: 96, height: 96, fit: BoxFit.cover)),
          ),
          const SizedBox(height: 14),
          const Text('OffChat',
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, letterSpacing: -.5, color: Colors.white)),
          const SizedBox(height: 4),
          const Text('Secure Offline Mesh Messaging App',
              textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, fontSize: 14.5)),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(.28),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white24),
            ),
            child: const Text('Version $kAppVersion',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: Colors.white)),
          ),
        ]),
      );

  Widget _card({required List<Widget> children, Color? border}) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: C.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: border ?? C.line),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children),
      );

  Widget _title(IconData icon, String text, {Color color = C.indigoSoft}) => Row(children: [
        Icon(icon, color: color, size: 22),
        const SizedBox(width: 10),
        Expanded(child: Text(text, style: const TextStyle(fontSize: 16.5, fontWeight: FontWeight.w800))),
      ]);

  Widget _row(IconData icon, String title, String sub) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 7),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: C.surface2, borderRadius: BorderRadius.circular(11)),
            child: Icon(icon, color: C.indigoSoft, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14.5)),
              const SizedBox(height: 2),
              Text(sub, style: const TextStyle(color: C.muted, height: 1.35, fontSize: 13)),
            ]),
          ),
        ]),
      );

  Widget _bullet(String text) => Padding(
        padding: const EdgeInsets.only(top: 7),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Padding(
            padding: EdgeInsets.only(top: 2),
            child: Icon(Icons.check_circle_rounded, size: 16, color: C.online),
          ),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(height: 1.4, fontSize: 13.5))),
        ]),
      );

  Widget _dataCard(BuildContext context) => _card(children: [
        _title(Icons.shield_outlined, 'Your data stays with you'),
        const SizedBox(height: 4),
        _bullet('Your chats, photos, videos, voice notes and contacts are stored only on your phone. '
            'They are not saved on any server or cloud by OffChat.'),
        _bullet('No account, no phone number, no ads and no analytics.'),
        _bullet('Messages go straight to the people you chat with over Bluetooth / Wi-Fi, '
            'encrypted by Google Nearby Connections.'),
        _bullet('The internet is used only for Premium: when you submit a payment or check its status, the '
            'transaction ID, plan, amount and a random device ID are sent to the developer\'s verification sheet. '
            'Your chats are never sent.'),
        _bullet('When a text is relayed through another phone, that phone can technically read it. '
            'End-to-end encryption for relayed messages is planned, not available today.'),
        const SizedBox(height: 6),
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton.icon(
            style: TextButton.styleFrom(padding: EdgeInsets.zero, minimumSize: const Size(0, 36)),
            onPressed: () =>
                Navigator.push(context, MaterialPageRoute(builder: (_) => const PrivacyScreen())),
            icon: const Icon(Icons.privacy_tip_outlined, size: 18),
            label: const Text('Read the full Privacy & data page'),
          ),
        ),
      ]);

  Widget _premiumCard(BuildContext context) => _card(border: _gold.withOpacity(.45), children: [
        _title(Icons.workspace_premium_rounded, 'What you get with Premium', color: _gold),
        const SizedBox(height: 4),
        const Text('Chatting, media, voice notes, calls and statuses are free. Premium adds:',
            style: TextStyle(color: C.muted, height: 1.4, fontSize: 13)),
        const SizedBox(height: 6),
        for (final p in _premiumPerks) _row(p.$1, p.$2, p.$3),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final id in kPlans) _planChip(id),
        ]),
        const SizedBox(height: 8),
        const Text('Payment is by Easypaisa and is checked manually, so approval can take a few hours.',
            style: TextStyle(color: C.muted, fontSize: 12.5, height: 1.4)),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: FilledButton.icon(
            onPressed: () => openPremium(context),
            icon: const Icon(Icons.workspace_premium_rounded, size: 20),
            label: const Text('View Premium plans'),
          ),
        ),
      ]);

  Widget _planChip(String id) {
    final detail = id == kMonthly ? '30 days' : id == kYearly ? '365 days' : 'one time';
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: C.surface2,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: C.line),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
        Text(planTitle(id), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5)),
        const SizedBox(height: 2),
        Text('Rs ${kPlanPrice[id]} · $detail', style: const TextStyle(color: C.muted, fontSize: 12)),
      ]),
    );
  }

  Widget _developerCard(BuildContext context, Premium pr) => _card(children: [
        _title(Icons.code_rounded, 'Developer'),
        const SizedBox(height: 16),
        Center(
          child: Container(
            padding: const EdgeInsets.all(3.5),
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [C.indigoSoft, C.indigo, Color(0xFF166534)],
              ),
            ),
            child: Container(
              padding: const EdgeInsets.all(3),
              decoration: const BoxDecoration(shape: BoxShape.circle, color: C.surface),
              child: ClipOval(
                child: Image.asset('assets/developer.jpg', width: 112, height: 112, fit: BoxFit.cover),
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        const Center(
          child: Text(kDeveloperName, style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
        ),
        const SizedBox(height: 2),
        const Center(child: Text('App Developer', style: TextStyle(color: C.muted, fontSize: 13))),
        const SizedBox(height: 14),
        const Divider(height: 1),
        _info(Icons.person_outline_rounded, 'Father name', kDeveloperFather),
        const Divider(height: 1),
        _info(
          Icons.mail_outline_rounded,
          'Contact email',
          kDeveloperEmail,
          trailing: const Icon(Icons.copy_rounded, size: 18, color: C.muted),
          onTap: () async {
            await Clipboard.setData(const ClipboardData(text: kDeveloperEmail));
            if (context.mounted) {
              ScaffoldMessenger.of(context)
                ..hideCurrentSnackBar()
                ..showSnackBar(const SnackBar(content: Text('Email copied')));
            }
          },
        ),
        const SizedBox(height: 14),
        SizedBox(
          width: double.infinity,
          child: FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFF25D366),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
            onPressed: pr.openSupport,
            icon: const Icon(Icons.chat_rounded, size: 20),
            label: const Text('WhatsApp Support', style: TextStyle(fontWeight: FontWeight.w800)),
          ),
        ),
      ]);

  Widget _info(IconData icon, String label, String value, {Widget? trailing, VoidCallback? onTap}) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Row(children: [
            Icon(icon, color: C.indigoSoft, size: 21),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(label, style: const TextStyle(color: C.muted, fontSize: 12)),
                const SizedBox(height: 2),
                Text(value, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14.5)),
              ]),
            ),
            if (trailing != null) trailing,
          ]),
        ),
      );
}
