package com.pulsemesh.pulsemesh

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.YuvImage
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream

/** Native bridge: Bluetooth prompt, foreground service, call audio, video JPEG encoding. */
class MainActivity : FlutterActivity() {

    private val reqEnableBt = 7301
    private var btResult: MethodChannel.Result? = null
    private var micSink: EventChannel.EventSink? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var audio: CallAudio? = null

    private fun adapter(): BluetoothAdapter? =
        (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val messenger = flutterEngine.dartExecutor.binaryMessenger

        EventChannel(messenger, "pulsemesh/mic").setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(arguments: Any?, events: EventChannel.EventSink?) { micSink = events }
            override fun onCancel(arguments: Any?) { micSink = null }
        })

        MethodChannel(messenger, "pulsemesh/native").setMethodCallHandler { call, result ->
            when (call.method) {
                "sdkInt" -> result.success(Build.VERSION.SDK_INT)
                "isBluetoothOn" -> result.success(adapter()?.isEnabled == true)
                "requestEnableBluetooth" -> {
                    val a = adapter()
                    when {
                        a == null -> result.success(false)
                        a.isEnabled -> result.success(true)
                        btResult != null -> result.error("busy", "Request in progress", null)
                        else -> {
                            btResult = result
                            @Suppress("DEPRECATION")
                            startActivityForResult(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), reqEnableBt)
                        }
                    }
                }
                "startService" -> {
                    val i = Intent(this, MeshService::class.java)
                        .putExtra("text", call.argument<String>("text"))
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                    result.success(true)
                }
                "stopService" -> {
                    stopService(Intent(this, MeshService::class.java))
                    result.success(true)
                }
                "audioStart" -> {
                    try {
                        audio?.stop()
                        val a = CallAudio(this) { f -> mainHandler.post { micSink?.success(f) } }
                        audio = a
                        a.start(call.argument<Boolean>("speaker") ?: false)
                        result.success(true)
                    } catch (e: Exception) {
                        audio = null
                        result.error("audio", e.message, null)
                    }
                }
                "audioStop" -> { audio?.stop(); audio = null; result.success(true) }
                "audioPlay" -> {
                    (call.arguments as? ByteArray)?.let { audio?.play(it) }
                    result.success(null)
                }
                "audioSpeaker" -> {
                    audio?.setSpeaker(call.argument<Boolean>("on") ?: false)
                    result.success(null)
                }
                "keepAwake" -> {
                    val on = call.argument<Boolean>("on") ?: false
                    if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    result.success(null)
                }
                "jpeg" -> {
                    try {
                        val nv21 = call.argument<ByteArray>("nv21")!!
                        val w = call.argument<Int>("w")!!
                        val h = call.argument<Int>("h")!!
                        val q = call.argument<Int>("q") ?: 40
                        val out = ByteArrayOutputStream()
                        YuvImage(nv21, ImageFormat.NV21, w, h, null).compressToJpeg(Rect(0, 0, w, h), q, out)
                        result.success(out.toByteArray())
                    } catch (e: Exception) {
                        result.error("jpeg", e.message, null)
                    }
                }
                else -> result.notImplemented()
            }
        }
    }

    override fun onDestroy() {
        audio?.stop()
        audio = null
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == reqEnableBt) {
            btResult?.success(resultCode == RESULT_OK)
            btResult = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }
}
